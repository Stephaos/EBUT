@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.opentrans.org/XMLSchema/1.0")
package de.htwg_konstanz.ebus.wholesaler.ws.order;
