# --------------------------------------------------------
# Host:                         127.0.0.1
# Server version:               5.1.41-log
# Server OS:                    Win32
# HeidiSQL version:             6.0.0.3654
# Date/time:                    2011-02-28 05:41:39
# --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

# Dumping structure for table ebus.activeconfig_internal
CREATE TABLE IF NOT EXISTS `activeconfig_internal` (
  `config` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`config`),
  CONSTRAINT `actconfigint_configint_fk` FOREIGN KEY (`config`) REFERENCES `config_internal` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.activeconfig_internal: ~1 rows (approximately)
/*!40000 ALTER TABLE `activeconfig_internal` DISABLE KEYS */;
INSERT INTO `activeconfig_internal` (`config`) VALUES
	(1);
/*!40000 ALTER TABLE `activeconfig_internal` ENABLE KEYS */;


# Dumping structure for table ebus.address
CREATE TABLE IF NOT EXISTS `address` (
  `id` char(40) NOT NULL DEFAULT '',
  `street` varchar(256) NOT NULL,
  `zipcode` char(16) NOT NULL,
  `city` varchar(256) NOT NULL,
  `country` char(5) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `address_country_fk` (`country`),
  CONSTRAINT `address_country_fk` FOREIGN KEY (`country`) REFERENCES `country` (`isocode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.address: ~12 rows (approximately)
/*!40000 ALTER TABLE `address` DISABLE KEYS */;
INSERT INTO `address` (`id`, `street`, `zipcode`, `city`, `country`) VALUES
	('10', 'Brauneggerstr. 55', '78462', 'Konstanz', 'DE'),
	('100', 'Brauneggerstr. 55', '78462', 'Konstanz', 'DE'),
	('110', 'Brauneggerstr. 55', '78462', 'Konstanz', 'DE'),
	('1296528656680', 'TestUserCustomerStreet', '123456', 'TestUserCustomerStreetCity', 'DE'),
	('20', 'Brauneggerstr. 55', '78462', 'Konstanz', 'DE'),
	('30', 'Brauneggerstr. 55', '78462', 'Konstanz', 'DE'),
	('40', 'Brauneggerstr. 55', '78462', 'Konstanz', 'DE'),
	('50', 'Brauneggerstr. 55', '78462', 'Konstanz', 'DE'),
	('60', 'Brauneggerstr. 55', '78462', 'Konstanz', 'DE'),
	('70', 'Brauneggerstr. 55', '78462', 'Konstanz', 'DE'),
	('80', 'Brauneggerstr. 55', '78462', 'Konstanz', 'DE'),
	('90', 'Brauneggerstr. 55', '78462', 'Konstanz', 'DE');
/*!40000 ALTER TABLE `address` ENABLE KEYS */;


# Dumping structure for table ebus.articlenumber
CREATE TABLE IF NOT EXISTS `articlenumber` (
  `anumber` char(64) NOT NULL,
  `articlenumbertype` char(8) NOT NULL DEFAULT '',
  `product` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`product`,`articlenumbertype`),
  UNIQUE KEY `artno_u1` (`anumber`,`articlenumbertype`),
  KEY `artno_anrtyp_fk` (`articlenumbertype`),
  CONSTRAINT `artno_anrtyp_fk` FOREIGN KEY (`articlenumbertype`) REFERENCES `articlenumbertype` (`articlenumbertype`),
  CONSTRAINT `artno_product_fk` FOREIGN KEY (`product`) REFERENCES `product` (`materialnumber`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.articlenumber: ~0 rows (approximately)
/*!40000 ALTER TABLE `articlenumber` DISABLE KEYS */;
/*!40000 ALTER TABLE `articlenumber` ENABLE KEYS */;


# Dumping structure for table ebus.articlenumbertype
CREATE TABLE IF NOT EXISTS `articlenumbertype` (
  `articlenumbertype` char(8) NOT NULL DEFAULT '',
  `description` varchar(256) NOT NULL,
  PRIMARY KEY (`articlenumbertype`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.articlenumbertype: ~3 rows (approximately)
/*!40000 ALTER TABLE `articlenumbertype` DISABLE KEYS */;
INSERT INTO `articlenumbertype` (`articlenumbertype`, `description`) VALUES
	('EAN', 'Europäische Artikelnummer'),
	('HerstNr', 'Herstellerspezifisches Artikelnummer'),
	('UPC', 'Universal Product Code');
/*!40000 ALTER TABLE `articlenumbertype` ENABLE KEYS */;


# Dumping structure for table ebus.companyidenttype
CREATE TABLE IF NOT EXISTS `companyidenttype` (
  `companyidenttype` char(8) NOT NULL DEFAULT '',
  `description` varchar(256) NOT NULL,
  PRIMARY KEY (`companyidenttype`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.companyidenttype: ~2 rows (approximately)
/*!40000 ALTER TABLE `companyidenttype` DISABLE KEYS */;
INSERT INTO `companyidenttype` (`companyidenttype`, `description`) VALUES
	('DUNS', 'Data Universal Numbering System '),
	('ILN', 'Internationale Lokationsnummer ');
/*!40000 ALTER TABLE `companyidenttype` ENABLE KEYS */;


# Dumping structure for table ebus.config_internal
CREATE TABLE IF NOT EXISTS `config_internal` (
  `id` int(11) NOT NULL DEFAULT '0',
  `wholesaleraddress` char(40) NOT NULL,
  `margin_on_sales` int(11) NOT NULL,
  `threshold_reorder` int(11) NOT NULL,
  `number_to_reorder` int(11) NOT NULL,
  `multimedia_docroot` varchar(256) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `configint_adress_fk` (`wholesaleraddress`),
  CONSTRAINT `configint_adress_fk` FOREIGN KEY (`wholesaleraddress`) REFERENCES `address` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.config_internal: ~1 rows (approximately)
/*!40000 ALTER TABLE `config_internal` DISABLE KEYS */;
INSERT INTO `config_internal` (`id`, `wholesaleraddress`, `margin_on_sales`, `threshold_reorder`, `number_to_reorder`, `multimedia_docroot`) VALUES
	(1, '70', 10, 100, 50, 'C:');
/*!40000 ALTER TABLE `config_internal` ENABLE KEYS */;


# Dumping structure for table ebus.contentunit
CREATE TABLE IF NOT EXISTS `contentunit` (
  `code` char(8) NOT NULL DEFAULT '',
  `description` varchar(256) NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.contentunit: ~1.029 rows (approximately)
/*!40000 ALTER TABLE `contentunit` DISABLE KEYS */;
INSERT INTO `contentunit` (`code`, `description`) VALUES
	('05', 'lift'),
	('06', 'small spray'),
	('08', 'heat lot'),
	('10', 'group'),
	('11', 'outfit'),
	('13', 'ration'),
	('14', 'shot'),
	('15', 'stick, military'),
	('16', 'hundred fifteen kg drum'),
	('17', 'hundred lb drum'),
	('18', 'fiftyfive gallon (US) drum'),
	('19', 'tank truck'),
	('1A', 'car mile'),
	('1B', 'car count'),
	('1C', 'locomotive count'),
	('1D', 'caboose count'),
	('1E', 'empty car'),
	('1F', 'train mile'),
	('1G', 'fuel usage gallon (US)'),
	('1H', 'caboose mile'),
	('1I', 'fixed rate'),
	('1J', 'ton mile'),
	('1K', 'locomotive mile'),
	('1L', 'total car count'),
	('1M', 'total car mile'),
	('1X', 'quarter mile'),
	('20', 'twenty foot container'),
	('21', 'forty foot container'),
	('22', 'decilitre per gram'),
	('23', 'gram per cubic centimetre'),
	('24', 'theoretical pound'),
	('25', 'gram per square centimetre'),
	('26', 'actual ton'),
	('27', 'theoretical ton'),
	('28', 'kilogram per square metre'),
	('29', 'pound per thousand square feet'),
	('2A', 'radian per second'),
	('2B', 'radian per second squared'),
	('2C', 'roentgen'),
	('2I', 'British thermal unit per hour'),
	('2J', 'cubic centimetre per second'),
	('2K', 'cubic foot per hour'),
	('2L', 'cubic foot per minute'),
	('2M', 'centimetre per second'),
	('2N', 'decibel'),
	('2P', 'kilobyte'),
	('2Q', 'kilobecquerel'),
	('2R', 'kilocurie'),
	('2U', 'megagram'),
	('2V', 'megagram per hour'),
	('2W', 'bin'),
	('2X', 'metre per minute'),
	('2Y', 'milliroentgen'),
	('2Z', 'millivolt'),
	('30', 'horse power day per air dry metric ton'),
	('31', 'catch weight'),
	('32', 'kilogram per air dry metric ton'),
	('33', 'kilopascal square metres per gram'),
	('34', 'kilopascals per millimetre'),
	('35', 'millilitres per square centimetre second'),
	('36', 'cubic feet per minute per square foot'),
	('37', 'ounce per square foot'),
	('38', 'ounces per square foot per 0,01inch'),
	('3B', 'megajoule'),
	('3C', 'manmonth'),
	('3E', 'pound per pound of product'),
	('3G', 'pound per piece of product'),
	('3H', 'kilogram per kilogram of product'),
	('3I', 'kilogram per piece of product'),
	('40', 'millilitre per second'),
	('41', 'millilitre per minute'),
	('43', 'super bulk bag'),
	('44', 'fivehundred kg bulk bag'),
	('45', 'threehundred kg bulk bag'),
	('46', 'fifty lb bulk bag'),
	('47', 'fifty lb bag'),
	('48', 'bulk car load'),
	('4A', 'bobbin'),
	('4B', 'cap'),
	('4C', 'centistokes'),
	('4E', 'twenty pack'),
	('4G', 'microlitre'),
	('4H', 'micrometre (micron)'),
	('4K', 'milliampere'),
	('4L', 'megabyte'),
	('4M', 'milligram per hour'),
	('4N', 'megabecquerel'),
	('4O', 'microfarad'),
	('4P', 'newton per metre'),
	('4Q', 'ounce inch'),
	('4R', 'ounce foot'),
	('4T', 'picofarad'),
	('4U', 'pound per hour'),
	('4W', 'ton (US) per hour'),
	('4X', 'kilolitre per hour'),
	('53', 'theoretical kilograms'),
	('54', 'theoretical tonne'),
	('56', 'sitas'),
	('57', 'mesh'),
	('58', 'net kilogram'),
	('59', 'part per million'),
	('5A', 'barrel (US) per minute'),
	('5B', 'batch'),
	('5C', 'gallon(US) per thousand'),
	('5E', 'MMSCF/day'),
	('5F', 'pounds per thousand'),
	('5G', 'pump'),
	('5H', 'stage'),
	('5I', 'standard cubic foot'),
	('5J', 'hydraulic horse power'),
	('5K', 'count per minute'),
	('5P', 'seismic level'),
	('5Q', 'seismic line'),
	('60', 'percent weight'),
	('61', 'part per billion (US)'),
	('62', 'percent per 1000 hour'),
	('63', 'failure rate in time'),
	('64', 'pound per square inch, gauge'),
	('66', 'oersted'),
	('69', 'test specific scale'),
	('71', 'volt ampere per pound'),
	('72', 'watt per pound'),
	('73', 'ampere tum per centimetre'),
	('74', 'millipascal'),
	('76', 'gauss'),
	('77', 'milli-inch'),
	('78', 'kilogauss'),
	('80', 'pounds per square inch absolute'),
	('81', 'henry'),
	('84', 'kilopound per square inch'),
	('85', 'foot pound-force'),
	('87', 'pound per cubic foot'),
	('89', 'poise'),
	('90', 'Saybold universal second'),
	('91', 'stokes'),
	('92', 'calorie per cubic centimetre'),
	('93', 'calorie per gram'),
	('94', 'curl unit'),
	('95', 'twenty thousand gallon (US) tankcar'),
	('96', 'ten thousand gallon (US) tankcar'),
	('97', 'ten kg drum'),
	('98', 'fifteen kg drum'),
	('A1', '15 °C calorie'),
	('A10', 'ampere square metre per joule second'),
	('A11', 'angstrom'),
	('A12', 'astronomical unit'),
	('A13', 'attojoule'),
	('A14', 'barn'),
	('A15', 'barn per electron volt'),
	('A16', 'barn per steradian electronvolt'),
	('A17', 'barn per steradian'),
	('A18', 'becquerel per kilogram'),
	('A19', 'becquerel per metre cubed'),
	('A2', 'ampere per centimetre'),
	('A20', 'British thermal unit per second square foot degree Rankin'),
	('A21', 'British thermal unit per pound degree Rankin'),
	('A22', 'British thermal unit per second foot degree Rankin'),
	('A23', 'British thermal unit per hour square foot degree Rankin'),
	('A24', 'candela per square metre'),
	('A25', 'cheval vapeur'),
	('A26', 'coulomb metre'),
	('A27', 'coulomb metre squared per volt'),
	('A28', 'coulomb per cubic centimetre'),
	('A29', 'coulomb per cubic metre'),
	('A3', 'ampere per millimetre'),
	('A30', 'coulomb per cubic millimetre'),
	('A31', 'coulomb per kilogram second'),
	('A32', 'coulomb per mole'),
	('A33', 'coulomb per square centimetre'),
	('A34', 'coulomb per square metre'),
	('A35', 'coulomb per square millimetre'),
	('A36', 'cubic centimetre per mole'),
	('A37', 'cubic decimetre per mole'),
	('A38', 'cubic metre per coulomb'),
	('A39', 'cubic metre per kilogram'),
	('A4', 'ampere per square centimetre'),
	('A40', 'cubic metre per mole'),
	('A41', 'ampere per square metre'),
	('A42', 'curie per kilogram'),
	('A43', 'deadweight tonnage'),
	('A44', 'decalitre'),
	('A45', 'decametre'),
	('A47', 'decitex'),
	('A48', 'degree Rankin'),
	('A49', 'denier'),
	('A5', 'ampere square metre'),
	('A50', 'dyne second per cubic centimetre'),
	('A51', 'dyne second per centimetre'),
	('A52', 'dyne second per centimetre to the fifth power'),
	('A53', 'electronvolt'),
	('A54', 'electronvolt per metre'),
	('A55', 'electronvolt square metre'),
	('A56', 'electronvolt square metre per kilogram'),
	('A57', 'erg'),
	('A58', 'erg per centimetre'),
	('A59', '8-part cloud cover'),
	('A6', 'ampere per square metre kelvin squared'),
	('A60', 'erg per cubic centimetre'),
	('A61', 'erg per gram'),
	('A62', 'erg per gram second'),
	('A63', 'erg per second'),
	('A64', 'erg per second square centimetre'),
	('A65', 'erg per square centimetre second'),
	('A66', 'erg square centimetre'),
	('A67', 'erg square centimetre per gram'),
	('A68', 'exajoule'),
	('A69', 'farad per metre'),
	('A7', 'ampere per square millimetre'),
	('A70', 'femtojoule'),
	('A71', 'femtometre'),
	('A73', 'foot per second squared'),
	('A74', 'foot pound-force per second'),
	('A75', 'freight ton'),
	('A76', 'gal'),
	('A77', 'Gaussian CGS unit of displacement'),
	('A78', 'Gaussian CGS unit of electic current'),
	('A79', 'Gaussian CGS unit of electric charge'),
	('A8', 'ampere second'),
	('A80', 'Gaussian CGS unit of electric field strength'),
	('A81', 'Gaussian CGS unit of electric polarization'),
	('A82', 'Gaussian CGS unit of electric potential'),
	('A83', 'Gaussian CGS unit of magnetization'),
	('A84', 'gigacoulomb per cubic metre'),
	('A85', 'gigaelectronvolt'),
	('A86', 'gigahertz'),
	('A87', 'gigaohm'),
	('A88', 'gigaohm metre'),
	('A89', 'gigapascal'),
	('A9', 'rate'),
	('A90', 'gigawatt'),
	('A91', 'gon'),
	('A93', 'gram per cubic metre'),
	('A94', 'gram per mole'),
	('A95', 'gray'),
	('A96', 'gray per second'),
	('A97', 'hectopascal'),
	('A98', 'henry per metre'),
	('A99', 'bit'),
	('AA', 'ball'),
	('AB', 'bulk pack'),
	('ACR', 'acre'),
	('ACT', 'activity'),
	('AD', 'byte'),
	('AE', 'ampere per metre'),
	('AH', 'additional minute'),
	('AI', 'average minute per call'),
	('AJ', 'cop'),
	('AK', 'fathom'),
	('AL', 'access line'),
	('AM', 'ampoule'),
	('AMH', 'ampere hour'),
	('AMP', 'ampere'),
	('ANN', 'year'),
	('AP', 'aluminium pound only'),
	('APZ', 'troy ounce or apothecary ounce'),
	('AQ', 'anti-hemophilic factor (AHF) unit'),
	('AR', 'suppository'),
	('ARE', 'are'),
	('AS', 'assortment'),
	('ASM', 'alcoholic strength by mass'),
	('ASU', 'alcoholic strength by volume'),
	('ATM', 'standard atmosphere'),
	('ATT', 'technical atmosphere'),
	('AV', 'capsule'),
	('AW', 'powder filled vial'),
	('AY', 'assembly'),
	('AZ', 'British thermal unit per pound'),
	('B0', 'Btu per cubic foot'),
	('B1', 'barrel (US) per day'),
	('B10', 'bit per second'),
	('B11', 'joule per kilogram kelvin'),
	('B12', 'joule per metre'),
	('B13', 'joule per square metre'),
	('B14', 'joule per metre to the fourth power'),
	('B15', 'joule per mole'),
	('B16', 'joule per mole kelvin'),
	('B17', 'credit'),
	('B18', 'joule second'),
	('B19', 'digit'),
	('B2', 'bunk'),
	('B20', 'joule square metre per kilogram'),
	('B21', 'kelvin per watt'),
	('B22', 'kiloampere'),
	('B23', 'kiloampere per square metre'),
	('B24', 'kiloampere per metre'),
	('B25', 'kilobecquerel per kilogram'),
	('B26', 'kilocoulomb'),
	('B27', 'kilocoulomb per cubic metre'),
	('B28', 'kilocoulomb per square metre'),
	('B29', 'kiloelectronvolt'),
	('B3', 'batting pound'),
	('B30', 'gibibit'),
	('B31', 'kilogram metre per second'),
	('B32', 'kilogram metre squared'),
	('B33', 'kilogram metre squared per second'),
	('B34', 'kilogram per cubic decimetre'),
	('B35', 'kilogram per litre'),
	('B36', 'thermochemical calorie per gram'),
	('B37', 'kilogram-force'),
	('B38', 'kilogram-force metre'),
	('B39', 'kilogram-force metre per second'),
	('B4', 'barrel, imperial'),
	('B40', 'kilogram-force per square metre'),
	('B41', 'kilojoule per kelvin'),
	('B42', 'kilojoule per kilogram'),
	('B43', 'kilojoule per kilogram kelvin'),
	('B44', 'kilojoule per mole'),
	('B45', 'kilomole'),
	('B46', 'kilomole per cubic metre'),
	('B47', 'kilonewton'),
	('B48', 'kilonewton metre'),
	('B49', 'kiloohm'),
	('B5', 'billet'),
	('B50', 'kiloohm metre'),
	('B51', 'kilopond'),
	('B52', 'kilosecond'),
	('B53', 'kilosiemens'),
	('B54', 'kilosiemens per metre'),
	('B55', 'kilovolt per metre'),
	('B56', 'kiloweber per metre'),
	('B57', 'light year'),
	('B58', 'litre per mole'),
	('B59', 'lumen hour'),
	('B6', 'bun'),
	('B60', 'lumen per square metre'),
	('B61', 'lumen per watt'),
	('B62', 'lumen second'),
	('B63', 'lux hour'),
	('B64', 'lux second'),
	('B65', 'maxwell'),
	('B66', 'megaampere per square metre'),
	('B67', 'megabecquerel per kilogram'),
	('B68', 'gigabit'),
	('B69', 'megacoulomb per cubic metre'),
	('B7', 'cycle'),
	('B70', 'megacoulomb per square metre'),
	('B71', 'megaelectronvolt'),
	('B72', 'megagram per cubic metre'),
	('B73', 'meganewton'),
	('B74', 'meganewton metre'),
	('B75', 'megaohm'),
	('B76', 'megaohm metre'),
	('B77', 'megasiemens per metre'),
	('B78', 'megavolt'),
	('B79', 'megavolt per metre'),
	('B8', 'joule per cubic metre'),
	('B80', 'gigabit per second'),
	('B81', 'reciprocal metre squared reciprocal second'),
	('B82', 'inch per linear foot'),
	('B83', 'metre to the fourth power'),
	('B84', 'microampere'),
	('B85', 'microbar'),
	('B86', 'microcoulomb'),
	('B87', 'microcoulomb per cubic metre'),
	('B88', 'microcoulomb per square metre'),
	('B89', 'microfarad per metre'),
	('B9', 'batt'),
	('B90', 'microhenry'),
	('B91', 'microhenry per metre'),
	('B92', 'micronewton'),
	('B93', 'micronewton metre'),
	('B94', 'microohm'),
	('B95', 'microohm metre'),
	('B96', 'micropascal'),
	('B97', 'microradian'),
	('B98', 'microsecond'),
	('B99', 'microsiemens'),
	('BAR', 'bar [unit of pressure]'),
	('BB', 'base box'),
	('BD', 'board'),
	('BE', 'bundle'),
	('BFT', 'board foot'),
	('BG', 'bag'),
	('BH', 'brush'),
	('BHP', 'brake horse power'),
	('BIL', 'billion (EUR)'),
	('BJ', 'bucket'),
	('BK', 'basket'),
	('BL', 'bale'),
	('BLD', 'dry barrel (US)'),
	('BLL', 'barrel (US)'),
	('BO', 'bottle'),
	('BP', 'hundred board feet'),
	('BQL', 'becquerel'),
	('BR', 'bar [unit of packaging]'),
	('BT', 'bolt'),
	('BTU', 'British thermal unit'),
	('BUA', 'bushel (US)'),
	('BUI', 'bushel (UK)'),
	('BW', 'base weight'),
	('BX', 'box'),
	('BZ', 'million BTUs'),
	('C0', 'call'),
	('C1', 'composite product pound (total weight)'),
	('C10', 'millifarad'),
	('C11', 'milligal'),
	('C12', 'milligram per metre'),
	('C13', 'milligray'),
	('C14', 'millihenry'),
	('C15', 'millijoule'),
	('C16', 'millimetre per second'),
	('C17', 'millimetre squared per second'),
	('C18', 'millimole'),
	('C19', 'mole per kilogram'),
	('C2', 'carset'),
	('C20', 'millinewton'),
	('C21', 'kibibit'),
	('C22', 'millinewton per metre'),
	('C23', 'milliohm metre'),
	('C24', 'millipascal second'),
	('C25', 'milliradian'),
	('C26', 'millisecond'),
	('C27', 'millisiemens'),
	('C28', 'millisievert'),
	('C29', 'millitesla'),
	('C3', 'microvolt per metre'),
	('C30', 'millivolt per metre'),
	('C31', 'milliwatt'),
	('C32', 'milliwatt per square metre'),
	('C33', 'milliweber'),
	('C34', 'mole'),
	('C35', 'mole per cubic decimetre'),
	('C36', 'mole per cubic metre'),
	('C37', 'kilobit'),
	('C38', 'mole per litre'),
	('C39', 'nanoampere'),
	('C4', 'carload'),
	('C40', 'nanocoulomb'),
	('C41', 'nanofarad'),
	('C42', 'nanofarad per metre'),
	('C43', 'nanohenry'),
	('C44', 'nanohenry per metre'),
	('C45', 'nanometre'),
	('C46', 'nanoohm metre'),
	('C47', 'nanosecond'),
	('C48', 'nanotesla'),
	('C49', 'nanowatt'),
	('C5', 'cost'),
	('C50', 'neper'),
	('C51', 'neper per second'),
	('C52', 'picometre'),
	('C53', 'newton metre second'),
	('C54', 'newton metre squared kilogram squared'),
	('C55', 'newton per square metre'),
	('C56', 'newton per square millimetre'),
	('C57', 'newton second'),
	('C58', 'newton second per metre'),
	('C59', 'octave'),
	('C6', 'cell'),
	('C60', 'ohm centimetre'),
	('C61', 'ohm metre'),
	('C62', 'one'),
	('C63', 'parsec'),
	('C64', 'pascal per kelvin'),
	('C65', 'pascal second'),
	('C66', 'pascal second per cubic metre'),
	('C67', 'pascal second per metre'),
	('C68', 'petajoule'),
	('C69', 'phon'),
	('C7', 'centipoise'),
	('C70', 'picoampere'),
	('C71', 'picocoulomb'),
	('C72', 'picofarad per metre'),
	('C73', 'picohenry'),
	('C74', 'kilobit per second'),
	('C75', 'picowatt'),
	('C76', 'picowatt per square metre'),
	('C77', 'pound gage'),
	('C78', 'pound-force'),
	('C79', 'kilovolt ampere hour'),
	('C8', 'millicoulomb per kilogram'),
	('C80', 'rad'),
	('C81', 'radian'),
	('C82', 'radian square metre per mole'),
	('C83', 'radian square metre per kilogram'),
	('C84', 'radian per metre'),
	('C85', 'reciprocal angstrom'),
	('C86', 'reciprocal cubic metre'),
	('C87', 'reciprocal cubic metre per second'),
	('C88', 'reciprocal electron volt per cubic metre'),
	('C89', 'reciprocal henry'),
	('C9', 'coil group'),
	('C90', 'reciprocal joule per cubic metre'),
	('C91', 'reciprocal kelvin or kelvin to the power minus one'),
	('C92', 'reciprocal metre'),
	('C93', 'reciprocal square metre'),
	('C94', 'reciprocal minute'),
	('C95', 'reciprocal mole'),
	('C96', 'reciprocal pascal or pascal to the power minus one'),
	('C97', 'reciprocal second'),
	('C98', 'reciprocal second per cubic metre'),
	('C99', 'reciprocal second per metre squared'),
	('CA', 'can'),
	('CCT', 'carrying capacity in metric ton'),
	('CDL', 'candela'),
	('CEL', 'degree Celsius'),
	('CEN', 'hundred'),
	('CG', 'card'),
	('CGM', 'centigram'),
	('CH', 'container'),
	('CJ', 'cone'),
	('CK', 'connector'),
	('CKG', 'coulomb per kilogram'),
	('CL', 'coil'),
	('CLF', 'hundred leave'),
	('CLT', 'centilitre'),
	('CMK', 'square centimetre'),
	('CMQ', 'cubic centimetre'),
	('CMT', 'centimetre'),
	('CNP', 'hundred pack'),
	('CNT', 'cental (UK)'),
	('CO', 'carboy'),
	('COU', 'coulomb'),
	('CQ', 'cartridge'),
	('CR', 'crate'),
	('CS', 'case'),
	('CT', 'carton'),
	('CTG', 'content gram'),
	('CTM', 'metric carat'),
	('CTN', 'content ton (metric)'),
	('CU', 'cup'),
	('CUR', 'curie'),
	('CV', 'cover'),
	('CWA', 'hundred pounds (cwt) / hundred weight (US)'),
	('CWI', 'hundred weight (UK)'),
	('CY', 'cylinder'),
	('CZ', 'combo'),
	('D03', 'kilowatt hour per hour'),
	('D04', 'lot  [unit of weight]'),
	('D1', 'reciprocal second per steradian'),
	('D10', 'siemens per metre'),
	('D11', 'mebibit'),
	('D12', 'siemens square metre per mole'),
	('D13', 'sievert'),
	('D14', 'thousand linear yard'),
	('D15', 'sone'),
	('D16', 'square centimetre per erg'),
	('D17', 'square centimetre per steradian erg'),
	('D18', 'metre kelvin'),
	('D19', 'square metre kelvin per watt'),
	('D2', 'reciprocal second per steradian metre squared'),
	('D20', 'square metre per joule'),
	('D21', 'square metre per kilogram'),
	('D22', 'square metre per mole'),
	('D23', 'pen gram (protein)'),
	('D24', 'square metre per steradian'),
	('D25', 'square metre per steradian joule'),
	('D26', 'square metre per volt second'),
	('D27', 'steradian'),
	('D28', 'syphon'),
	('D29', 'terahertz'),
	('D30', 'terajoule'),
	('D31', 'terawatt'),
	('D32', 'terawatt hour'),
	('D33', 'tesla'),
	('D34', 'tex'),
	('D35', 'thermochemical calorie'),
	('D36', 'megabit'),
	('D37', 'thermochemical calorie per gram kelvin'),
	('D38', 'thermochemical calorie per second centimetre kelvin'),
	('D39', 'thermochemical calorie per second square centimetre kelvin'),
	('D40', 'thousand litre'),
	('D41', 'tonne per cubic metre'),
	('D42', 'tropical year'),
	('D43', 'unified atomic mass unit'),
	('D44', 'var'),
	('D45', 'volt squared per kelvin squared'),
	('D46', 'volt - ampere'),
	('D47', 'volt per centimetre'),
	('D48', 'volt per kelvin'),
	('D49', 'millivolt per kelvin'),
	('D5', 'kilogram per square centimetre'),
	('D50', 'volt per metre'),
	('D51', 'volt per millimetre'),
	('D52', 'watt per kelvin'),
	('D53', 'watt per metre kelvin'),
	('D54', 'watt per square metre'),
	('D55', 'watt per square metre kelvin'),
	('D56', 'watt per square metre kelvin to the fourth power'),
	('D57', 'watt per steradian'),
	('D58', 'watt per steradian square metre'),
	('D59', 'weber per metre'),
	('D6', 'roentgen per second'),
	('D60', 'weber per millimetre'),
	('D61', 'minute [unit of angle]'),
	('D62', 'second [unit of angle]'),
	('D63', 'book'),
	('D64', 'block'),
	('D65', 'round'),
	('D66', 'cassette'),
	('D67', 'dollar per hour'),
	('D68', 'number of words'),
	('D69', 'inch to the fourth power'),
	('D7', 'sandwich'),
	('D70', 'International Table (IT) calorie'),
	('D71', 'International Table (IT) calorie per second centimetre kelvin'),
	('D72', 'International Table (IT) calorie per second square centimetre kelvin'),
	('D73', 'joule square metre'),
	('D74', 'kilogram per mole'),
	('D75', 'International Table (IT)calorie per gram'),
	('D76', 'International Table (IT) calorie per gram kelvin'),
	('D77', 'megacoulomb'),
	('D78', 'megajoule per second'),
	('D79', 'beam'),
	('D8', 'draize score'),
	('D80', 'microwatt'),
	('D81', 'microtesla'),
	('D82', 'microvolt'),
	('D83', 'millinewton metre'),
	('D85', 'microwatt per square metre'),
	('D86', 'millicoulomb'),
	('D87', 'millimole per kilogram'),
	('D88', 'millicoulomb per cubic metre'),
	('D89', 'millicoulomb per square metre'),
	('D9', 'dyne per square centimetre'),
	('D90', 'cubic metre (net)'),
	('D91', 'rem'),
	('D92', 'band'),
	('D93', 'second per cubic metre'),
	('D94', 'second per radian cubic metre'),
	('D95', 'joule per gram'),
	('D96', 'pound gross'),
	('D97', 'pallet/unit load'),
	('D98', 'mass pound'),
	('D99', 'sleeve'),
	('DAA', 'decare'),
	('DAD', 'ten day'),
	('DAY', 'day'),
	('DB', 'dry pound'),
	('DC', 'disk (disc)'),
	('DD', 'degree [unit of angle]'),
	('DE', 'deal'),
	('DEC', 'decade'),
	('DG', 'decigram'),
	('DI', 'dispenser'),
	('DJ', 'decagram'),
	('DLT', 'decilitre'),
	('DMK', 'square decimetre'),
	('DMO', 'standard kilolitre'),
	('DMQ', 'cubic decimetre'),
	('DMT', 'decimetre'),
	('DN', 'decinewton metre'),
	('DPC', 'dozen piece'),
	('DPR', 'dozen pair'),
	('DPT', 'displacement tonnage'),
	('DQ', 'data record'),
	('DR', 'drum'),
	('DRA', 'dram (US)'),
	('DRI', 'dram (UK)'),
	('DRL', 'dozen roll'),
	('DRM', 'drachm (UK)'),
	('DS', 'display'),
	('DT', 'dry ton'),
	('DTN', 'decitonne'),
	('DU', 'dyne'),
	('DWT', 'pennyweight'),
	('DX', 'dyne per centimetre'),
	('DY', 'directory book'),
	('DZN', 'dozen'),
	('DZP', 'dozen pack'),
	('E01', 'newton per square centimetre'),
	('E07', 'megawatt hour per hour'),
	('E08', 'megawatt per hertz'),
	('E09', 'milliampere hour'),
	('E10', 'degree days'),
	('E11', 'gigacalorie'),
	('E12', 'mille'),
	('E14', 'kilocalorie (IT)'),
	('E15', 'kilocalorie (TH) per hour'),
	('E16', 'million BTU(IT) per hour'),
	('E17', 'cubic foot per second'),
	('E18', 'tonne per hour'),
	('E19', 'ping'),
	('E2', 'belt'),
	('E20', 'megabit per second'),
	('E21', 'shares'),
	('E22', 'TEU'),
	('E23', 'tyre'),
	('E25', 'active unit'),
	('E27', 'dose'),
	('E28', 'air dry ton'),
	('E3', 'trailer'),
	('E30', 'strand'),
	('E31', 'square metre per litre'),
	('E32', 'litre per hour'),
	('E33', 'foot per thousand'),
	('E34', 'gigabyte'),
	('E35', 'terabyte'),
	('E36', 'petabyte'),
	('E37', 'pixel'),
	('E38', 'megapixel'),
	('E39', 'dots per inch'),
	('E4', 'gross kilogram'),
	('E40', 'part per hundred thousand'),
	('E41', 'kilogram force per square millimetre'),
	('E42', 'kilogram force per square centimetre'),
	('E43', 'joule per square centimetre'),
	('E44', 'kilogram-force metre per square centimetre'),
	('E45', 'milliohm'),
	('E46', 'kilowatt hour per cubic metre'),
	('E47', 'kilowatt hour per kelvin'),
	('E48', 'service unit'),
	('E49', 'working day'),
	('E5', 'metric long ton'),
	('E50', 'accounting unit'),
	('EA', 'each'),
	('EB', 'electronic mail box'),
	('EC', 'each per month'),
	('EP', 'eleven pack'),
	('EQ', 'equivalent gallon'),
	('EV', 'envelope'),
	('F1', 'thousand cubic feet per day'),
	('F9', 'fibre per cubic centimetre of air'),
	('FAH', 'degree Fahrenheit'),
	('FAR', 'farad'),
	('FB', 'field'),
	('FBM', 'fibre metre'),
	('FC', 'thousand cubic feet'),
	('FD', 'million particle per cubic foot'),
	('FE', 'track foot'),
	('FF', 'hundred cubic metre'),
	('FG', 'transdermal patch'),
	('FH', 'micromole'),
	('FL', 'flake ton'),
	('FM', 'million cubic feet'),
	('FOT', 'foot'),
	('FP', 'pound per square foot'),
	('FR', 'foot per minute'),
	('FS', 'foot per second'),
	('FTK', 'square foot'),
	('FTQ', 'cubic foot'),
	('G2', 'US gallon per minute'),
	('G3', 'Imperial gallon per minute'),
	('G7', 'microfiche sheet'),
	('GB', 'gallon (US) per day'),
	('GBQ', 'gigabecquerel'),
	('GC', 'gram per 100 gram'),
	('GD', 'gross barrel'),
	('GDW', 'gram, dry weight'),
	('GE', 'pound per gallon (US)'),
	('GF', 'gram per metre (gram per 100 centimetres)'),
	('GFI', 'gram of fissile isotope'),
	('GGR', 'great gross'),
	('GH', 'half gallon (US)'),
	('GIA', 'gill (US)'),
	('GIC', 'gram, including container'),
	('GII', 'gill (UK)'),
	('GIP', 'gram, including inner packaging'),
	('GJ', 'gram per millilitre'),
	('GK', 'gram per kilogram'),
	('GL', 'gram per litre'),
	('GLD', 'dry gallon (US)'),
	('GLI', 'gallon (UK)'),
	('GLL', 'gallon (US)'),
	('GM', 'gram per square metre'),
	('GN', 'gross gallon'),
	('GO', 'milligrams per square metre'),
	('GP', 'milligram per cubic metre'),
	('GQ', 'microgram per cubic metre'),
	('GRM', 'gram'),
	('GRN', 'grain'),
	('GRO', 'gross'),
	('GRT', 'gross register ton'),
	('GT', 'gross ton'),
	('GV', 'gigajoule'),
	('GW', 'gallon per thousand cubic feet'),
	('GWH', 'gigawatt hour'),
	('GY', 'gross yard'),
	('GZ', 'gage system'),
	('H1', 'half page ¿ electronic'),
	('H2', 'half litre'),
	('HA', 'hank'),
	('HAR', 'hectare'),
	('HBA', 'hectobar'),
	('HBX', 'hundred boxes'),
	('HC', 'hundred count'),
	('HD', 'half dozen'),
	('HDW', 'hundred kilogram, dry weight'),
	('HE', 'hundredth of a carat'),
	('HF', 'hundred feet'),
	('HGM', 'hectogram'),
	('HH', 'hundred cubic feet'),
	('HI', 'hundred sheet'),
	('HIU', 'hundred international unit'),
	('HJ', 'metric horse power'),
	('HK', 'hundred kilogram'),
	('HKM', 'hundred kilogram, net mass'),
	('HL', 'hundred feet (linear)'),
	('HLT', 'hectolitre'),
	('HM', 'mile per hour'),
	('HMQ', 'million cubic metre'),
	('HMT', 'hectometre'),
	('HN', 'conventional millimetre of mercury'),
	('HO', 'hundred troy ounce'),
	('HP', 'conventional millimetre of water'),
	('HPA', 'hectolitre of pure alcohol'),
	('HS', 'hundred square feet'),
	('HT', 'half hour'),
	('HTZ', 'hertz'),
	('HUR', 'hour'),
	('HY', 'hundred yard'),
	('IA', 'inch pound (pound inch)'),
	('IC', 'count per inch'),
	('IE', 'person'),
	('IF', 'inches of water'),
	('II', 'column inch'),
	('IL', 'inch per minute'),
	('IM', 'impression'),
	('INH', 'inch'),
	('INK', 'square inch'),
	('INQ', 'cubic inch'),
	('IP', 'insurance policy'),
	('ISD', 'international sugar degree'),
	('IT', 'count per centimetre'),
	('IU', 'inch per second'),
	('IV', 'inch per second squared'),
	('J2', 'joule per kilogram'),
	('JB', 'jumbo'),
	('JE', 'joule per kelvin'),
	('JG', 'jug'),
	('JK', 'megajoule per kilogram'),
	('JM', 'megajoule per cubic metre'),
	('JO', 'joint'),
	('JOU', 'joule'),
	('JPS', 'hundred metre'),
	('JR', 'jar'),
	('JWL', 'number of jewels'),
	('K1', 'kilowatt demand'),
	('K2', 'kilovolt ampere reactive demand'),
	('K3', 'kilovolt ampere reactive hour'),
	('K5', 'kilovolt ampere (reactive)'),
	('K6', 'kilolitre'),
	('KA', 'cake'),
	('KB', 'kilocharacter'),
	('KBA', 'kilobar'),
	('KCC', 'kilogram of choline chloride'),
	('KD', 'kilogram decimal'),
	('KDW', 'kilogram drained net weight'),
	('KEL', 'kelvin'),
	('KF', 'kilopacket'),
	('KG', 'keg'),
	('KGM', 'kilogram'),
	('KGS', 'kilogram per second'),
	('KHY', 'kilogram of hydrogen peroxide'),
	('KHZ', 'kilohertz'),
	('KI', 'kilogram per millimetre width'),
	('KIC', 'kilogram, including container'),
	('KIP', 'kilogram, including inner packaging'),
	('KJ', 'kilosegment'),
	('KJO', 'kilojoule'),
	('KL', 'kilogram per metre'),
	('KLK', 'lactic dry material percentage'),
	('KMA', 'kilogram of methylamine'),
	('KMH', 'kilometre per hour'),
	('KMK', 'square kilometre'),
	('KMQ', 'kilogram per cubic metre'),
	('KMT', 'kilometre'),
	('KNI', 'kilogram of nitrogen'),
	('KNS', 'kilogram named substance'),
	('KNT', 'knot'),
	('KO', 'milliequivalence caustic potash per gram of product'),
	('KPA', 'kilopascal'),
	('KPH', 'kilogram of potassium hydroxide (caustic potash)'),
	('KPO', 'kilogram of potassium oxide'),
	('KPP', 'kilogram of phosphorus pentoxide (phosphoric anhydride)'),
	('KR', 'kiloroentgen'),
	('KS', 'thousand pound per square inch'),
	('KSD', 'kilogram of substance 90 % dry'),
	('KSH', 'kilogram of sodium hydroxide (caustic soda)'),
	('KT', 'kit'),
	('KTM', 'kilometre'),
	('KTN', 'kilotonne'),
	('KUR', 'kilogram of uranium'),
	('KVA', 'kilovolt - ampere'),
	('KVR', 'kilovar'),
	('KVT', 'kilovolt'),
	('KW', 'kilograms per millimetre'),
	('KWH', 'kilowatt hour'),
	('KWO', 'kilogram of tungsten trioxide'),
	('KWT', 'kilowatt'),
	('KX', 'millilitre per kilogram'),
	('L2', 'litre per minute'),
	('LA', 'pound per cubic inch'),
	('LAC', 'lactose excess percentage'),
	('LBR', 'pound'),
	('LBT', 'troy pound (US)'),
	('LC', 'linear centimetre'),
	('LD', 'litre per day'),
	('LE', 'lite'),
	('LEF', 'leaf'),
	('LF', 'linear foot'),
	('LH', 'labour hour'),
	('LI', 'linear inch'),
	('LJ', 'large spray'),
	('LK', 'link'),
	('LM', 'linear metre'),
	('LN', 'length'),
	('LO', 'lot  [unit of procurement]'),
	('LP', 'liquid pound'),
	('LPA', 'litre of pure alcohol'),
	('LR', 'layer'),
	('LS', 'lump sum'),
	('LTN', 'ton (UK) or long ton (US)'),
	('LTR', 'litre'),
	('LUB', 'metric ton, lubricating oil'),
	('LUM', 'lumen'),
	('LUX', 'lux'),
	('LX', 'linear yard per pound'),
	('LY', 'linear yard'),
	('M0', 'magnetic tape'),
	('M1', 'milligram per litre'),
	('M4', 'monetary value'),
	('M5', 'microcurie'),
	('M7', 'micro-inch'),
	('M9', 'million Btu per 1000 cubic feet'),
	('MA', 'machine per unit'),
	('MAH', 'megavolt ampere reactive hours'),
	('MAL', 'mega litre'),
	('MAM', 'megametre'),
	('MAR', 'megavolt ampere reactive'),
	('MAW', 'megawatt'),
	('MBE', 'thousand standard brick equivalent'),
	('MBF', 'thousand board feet'),
	('MBR', 'millibar'),
	('MC', 'microgram'),
	('MCU', 'millicurie'),
	('MD', 'air dry metric ton'),
	('MF', 'milligram per square foot per side'),
	('MGM', 'milligram'),
	('MHZ', 'megahertz'),
	('MIK', 'square mile'),
	('MIL', 'thousand'),
	('MIN', 'minute [unit of time]'),
	('MIO', 'million'),
	('MIU', 'million international unit'),
	('MK', 'milligram per square inch'),
	('MLD', 'milliard'),
	('MLT', 'millilitre'),
	('MMK', 'square millimetre'),
	('MMQ', 'cubic millimetre'),
	('MMT', 'millimetre'),
	('MND', 'kilogram, dry weight'),
	('MON', 'month'),
	('MPA', 'megapascal'),
	('MQ', 'thousand metre'),
	('MQH', 'cubic metre per hour'),
	('MQS', 'cubic metre per second'),
	('MSK', 'metre per second squared'),
	('MT', 'mat'),
	('MTK', 'square metre'),
	('MTQ', 'cubic metre'),
	('MTR', 'metre'),
	('MTS', 'metre per second'),
	('MV', 'number of mults'),
	('MVA', 'megavolt - ampere'),
	('MWH', 'megawatt hour (1000 kW.h)'),
	('N1', 'pen calorie'),
	('N2', 'number of lines'),
	('N3', 'print point'),
	('NA', 'milligram per kilogram'),
	('NAR', 'number of articles'),
	('NB', 'barge'),
	('NBB', 'number of bobbins'),
	('NC', 'car'),
	('NCL', 'number of cells'),
	('ND', 'net barrel'),
	('NE', 'net litre'),
	('NEW', 'newton'),
	('NF', 'message'),
	('NG', 'net gallon (us)'),
	('NH', 'message hour'),
	('NI', 'net imperial gallon'),
	('NIU', 'number of international units'),
	('NJ', 'number of screens'),
	('NL', 'load'),
	('NMI', 'nautical mile'),
	('NMP', 'number of packs'),
	('NN', 'train'),
	('NPL', 'number of parcels'),
	('NPR', 'number of pairs'),
	('NPT', 'number of parts'),
	('NQ', 'mho'),
	('NR', 'micromho'),
	('NRL', 'number of rolls'),
	('NT', 'net ton'),
	('NTT', 'net register ton'),
	('NU', 'newton metre'),
	('NV', 'vehicle'),
	('NX', 'part per thousand'),
	('NY', 'pound per air dry metric ton'),
	('OA', 'panel'),
	('ODE', 'ozone depletion equivalent'),
	('OHM', 'ohm'),
	('ON', 'ounce per square yard'),
	('ONZ', 'ounce'),
	('OP', 'two pack'),
	('OT', 'overtime hour'),
	('OZ', 'ounce av'),
	('OZA', 'fluid ounce (US)'),
	('OZI', 'fluid ounce (UK)'),
	('P0', 'page - electronic'),
	('P1', 'percent'),
	('P2', 'pound per foot'),
	('P3', 'three pack'),
	('P4', 'four pack'),
	('P5', 'five pack'),
	('P6', 'six pack'),
	('P7', 'seven pack'),
	('P8', 'eight pack'),
	('P9', 'nine pack'),
	('PA', 'packet'),
	('PAL', 'pascal'),
	('PB', 'pair inch'),
	('PD', 'pad'),
	('PE', 'pound equivalent'),
	('PF', 'pallet (lift)'),
	('PFL', 'proof litre'),
	('PG', 'plate'),
	('PGL', 'proof gallon'),
	('PI', 'pitch'),
	('PK', 'pack'),
	('PL', 'pail'),
	('PLA', 'degree Plato'),
	('PM', 'pound percentage'),
	('PN', 'pound net'),
	('PO', 'pound per inch of length'),
	('PQ', 'page per inch'),
	('PR', 'pair'),
	('PS', 'pound-force per square inch'),
	('PT', 'pint (US)'),
	('PTD', 'dry pint (US)'),
	('PTI', 'pint (UK)'),
	('PTL', 'liquid pint (US)'),
	('PU', 'tray / tray pack'),
	('PV', 'half pint (US)'),
	('PW', 'pound per inch of width'),
	('PY', 'peck dry (US)'),
	('PZ', 'peck dry (UK)'),
	('Q3', 'meal'),
	('QA', 'page - facsimile'),
	('QAN', 'quarter (of a year)'),
	('QB', 'page - hardcopy'),
	('QD', 'quarter dozen'),
	('QH', 'quarter hour'),
	('QK', 'quarter kilogram'),
	('QR', 'quire'),
	('QT', 'quart (US)'),
	('QTD', 'dry quart (US)'),
	('QTI', 'quart (UK)'),
	('QTL', 'liquid quart (US)'),
	('QTR', 'quarter (UK)'),
	('R1', 'pica'),
	('R4', 'calorie'),
	('R9', 'thousand cubic metre'),
	('RA', 'rack'),
	('RD', 'rod'),
	('RG', 'ring'),
	('RH', 'running or operating hour'),
	('RK', 'roll metric measure'),
	('RL', 'reel'),
	('RM', 'ream'),
	('RN', 'ream metric measure'),
	('RO', 'roll'),
	('RP', 'pound per ream'),
	('RPM', 'revolutions per minute'),
	('RPS', 'revolutions per second'),
	('RS', 'reset'),
	('RT', 'revenue ton mile'),
	('RU', 'run'),
	('S3', 'square foot per second'),
	('S4', 'square metre per second'),
	('S5', 'sixty fourths of an inch'),
	('S6', 'session'),
	('S7', 'storage unit'),
	('S8', 'standard advertising unit'),
	('SA', 'sack'),
	('SAN', 'half year (6 months)'),
	('SCO', 'score'),
	('SCR', 'scruple'),
	('SD', 'solid pound'),
	('SE', 'section'),
	('SEC', 'second [unit of time]'),
	('SET', 'set'),
	('SG', 'segment'),
	('SHT', 'shipping ton'),
	('SIE', 'siemens'),
	('SK', 'split tank truck'),
	('SL', 'slipsheet'),
	('SMI', 'mile (statute mile)'),
	('SN', 'square rod'),
	('SO', 'spool'),
	('SP', 'shelf package'),
	('SQ', 'square'),
	('SQR', 'square, roofing'),
	('SR', 'strip'),
	('SS', 'sheet metric measure'),
	('SST', 'short standard (7200 matches)'),
	('ST', 'sheet'),
	('STI', 'stone (UK)'),
	('STK', 'stick, cigarette'),
	('STL', 'standard litre'),
	('STN', 'ton (US) or short ton (UK/US)'),
	('SV', 'skid'),
	('SW', 'skein'),
	('SX', 'shipment'),
	('T0', 'telecommunication line in service'),
	('T1', 'thousand pound gross'),
	('T3', 'thousand piece'),
	('T4', 'thousand bag'),
	('T5', 'thousand casing'),
	('T6', 'thousand gallon (US)'),
	('T7', 'thousand impression'),
	('T8', 'thousand linear inch'),
	('TA', 'tenth cubic foot'),
	('TAH', 'kiloampere hour (thousand ampere hour)'),
	('TC', 'truckload'),
	('TD', 'therm'),
	('TE', 'tote'),
	('TF', 'ten square yard'),
	('TI', 'thousand square inch'),
	('TIC', 'metric ton, including container'),
	('TIP', 'metric ton, including inner packaging'),
	('TJ', 'thousand square centimetre'),
	('TK', 'tank, rectangular'),
	('TL', 'thousand feet (linear)'),
	('TMS', 'kilogram of imported meat, less offal'),
	('TN', 'tin'),
	('TNE', 'tonne (metric ton)'),
	('TP', 'ten pack'),
	('TPR', 'ten pair'),
	('TQ', 'thousand feet'),
	('TQD', 'thousand cubic metre per day'),
	('TR', 'ten square feet'),
	('TRL', 'trillion (EUR)'),
	('TS', 'thousand square feet'),
	('TSD', 'tonne of substance 90 % dry'),
	('TSH', 'ton of steam per hour'),
	('TT', 'thousand linear metre'),
	('TU', 'tube'),
	('TV', 'thousand kilogram'),
	('TW', 'thousand sheet'),
	('TY', 'tank, cylindrical'),
	('U1', 'treatment'),
	('U2', 'tablet'),
	('UA', 'torr'),
	('UB', 'telecommunication line in service average'),
	('UC', 'telecommunication port'),
	('UD', 'tenth minute'),
	('UE', 'tenth hour'),
	('UF', 'usage per telecommunication line average'),
	('UH', 'ten thousand yard'),
	('UM', 'million unit'),
	('VA', 'volt ampere per kilogram'),
	('VI', 'vial'),
	('VLT', 'volt'),
	('VQ', 'bulk'),
	('VS', 'visit'),
	('W2', 'wet kilo'),
	('W4', 'two week'),
	('WA', 'watt per kilogram'),
	('WB', 'wet pound'),
	('WCD', 'cord'),
	('WE', 'wet ton'),
	('WEB', 'weber'),
	('WEE', 'week'),
	('WG', 'wine gallon'),
	('WH', 'wheel'),
	('WHR', 'watt hour'),
	('WI', 'weight per square inch'),
	('WM', 'working month'),
	('WR', 'wrap'),
	('WSD', 'standard'),
	('WTT', 'watt'),
	('WW', 'millilitre of water'),
	('X1', 'chain'),
	('YDK', 'square yard'),
	('YDQ', 'cubic yard'),
	('YL', 'hundred linear yard'),
	('YRD', 'yard'),
	('YT', 'ten yard'),
	('Z1', 'lift van'),
	('Z2', 'chest'),
	('Z3', 'cask'),
	('Z4', 'hogshead'),
	('Z5', 'lug'),
	('Z6', 'conference point'),
	('Z8', 'newspage agate line'),
	('ZP', 'page'),
	('ZZ', 'mutually defined');
/*!40000 ALTER TABLE `contentunit` ENABLE KEYS */;


# Dumping structure for table ebus.country
CREATE TABLE IF NOT EXISTS `country` (
  `isocode` char(5) NOT NULL DEFAULT '',
  `name` varchar(64) NOT NULL,
  `currency` char(3) NOT NULL,
  PRIMARY KEY (`isocode`),
  UNIQUE KEY `country_u1` (`name`),
  KEY `country_currency_fk` (`currency`),
  CONSTRAINT `country_currency_fk` FOREIGN KEY (`currency`) REFERENCES `currency` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.country: ~166 rows (approximately)
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
INSERT INTO `country` VALUES ('AE', 'UNITED ARAB EMIRATES', 'AED');
INSERT INTO `country` VALUES ('AL', 'ALBANIA', 'ALL');
INSERT INTO `country` VALUES ('AN', 'NETHERLANDS ANTILLES', 'ANG');
INSERT INTO `country` VALUES ('AU', 'AUSTRALIA', 'AUD');
INSERT INTO `country` VALUES ('CC', 'COCOS (KEELING) ISLANDS', 'AUD');
INSERT INTO `country` VALUES ('CX', 'CHRISTMAS ISLAND', 'AUD');
INSERT INTO `country` VALUES ('HM', 'HEARD ISLAND AND MCDONALD ISLANDS', 'AUD');
INSERT INTO `country` VALUES ('KI', 'KIRIBATI', 'AUD');
INSERT INTO `country` VALUES ('NF', 'NORFOLK ISLAND', 'AUD');
INSERT INTO `country` VALUES ('NR', 'NAURU', 'AUD');
INSERT INTO `country` VALUES ('TV', 'TUVALU', 'AUD');
INSERT INTO `country` VALUES ('AW', 'ARUBA', 'AWG');
INSERT INTO `country` VALUES ('BB', 'BARBADOS', 'BBD');
INSERT INTO `country` VALUES ('BD', 'BANGLADESH', 'BDT');
INSERT INTO `country` VALUES ('BH', 'BAHRAIN', 'BHD');
INSERT INTO `country` VALUES ('BI', 'BURUNDI', 'BIF');
INSERT INTO `country` VALUES ('BM', 'BERMUDA', 'BMD');
INSERT INTO `country` VALUES ('BN', 'BRUNEI DARUSSALAM', 'BND');
INSERT INTO `country` VALUES ('BS', 'BAHAMAS', 'BSD');
INSERT INTO `country` VALUES ('BT', 'BHUTAN', 'BTN');
INSERT INTO `country` VALUES ('BW', 'BOTSWANA', 'BWP');
INSERT INTO `country` VALUES ('BZ', 'BELIZE', 'BZD');
INSERT INTO `country` VALUES ('CA', 'CANADA', 'CAD');
INSERT INTO `country` VALUES ('CH', 'SWITZERLAND', 'CHF');
INSERT INTO `country` VALUES ('LI', 'LIECHTENSTEIN', 'CHF');
INSERT INTO `country` VALUES ('CL', 'CHILE', 'CLP');
INSERT INTO `country` VALUES ('CN', 'CHINA', 'CNY');
INSERT INTO `country` VALUES ('CO', 'COLOMBIA', 'COP');
INSERT INTO `country` VALUES ('CR', 'COSTA RICA', 'CRC');
INSERT INTO `country` VALUES ('CU', 'CUBA', 'CUP');
INSERT INTO `country` VALUES ('CV', 'CAPE VERDE', 'CVE');
INSERT INTO `country` VALUES ('CY', 'CYPRUS', 'CYP');
INSERT INTO `country` VALUES ('DJ', 'DJIBOUTI', 'DJF');
INSERT INTO `country` VALUES ('DK', 'DENMARK', 'DKK');
INSERT INTO `country` VALUES ('FO', 'FAROE ISLANDS', 'DKK');
INSERT INTO `country` VALUES ('GL', 'GREENLAND', 'DKK');
INSERT INTO `country` VALUES ('DO', 'DOMINICAN REPUBLIC', 'DOP');
INSERT INTO `country` VALUES ('DZ', 'ALGERIA', 'DZD');
INSERT INTO `country` VALUES ('EG', 'EGYPT', 'EGP');
INSERT INTO `country` VALUES ('ET', 'ETHIOPIA', 'ETB');
INSERT INTO `country` VALUES ('AD', 'ANDORRA', 'EUR');
INSERT INTO `country` VALUES ('AT', 'AUSTRIA', 'EUR');
INSERT INTO `country` VALUES ('BA', 'BOSNIA AND HERZEGOVINA', 'EUR');
INSERT INTO `country` VALUES ('BE', 'BELGIUM', 'EUR');
INSERT INTO `country` VALUES ('DE', 'GERMANY', 'EUR');
INSERT INTO `country` VALUES ('ES', 'SPAIN', 'EUR');
INSERT INTO `country` VALUES ('FI', 'FINLAND', 'EUR');
INSERT INTO `country` VALUES ('FR', 'FRANCE', 'EUR');
INSERT INTO `country` VALUES ('GP', 'GUADELOUPE', 'EUR');
INSERT INTO `country` VALUES ('GR', 'GREECE', 'EUR');
INSERT INTO `country` VALUES ('GY', 'GUYANA', 'EUR');
INSERT INTO `country` VALUES ('IE', 'IRELAND', 'EUR');
INSERT INTO `country` VALUES ('IT', 'ITALY', 'EUR');
INSERT INTO `country` VALUES ('LU', 'LUXEMBOURG', 'EUR');
INSERT INTO `country` VALUES ('MC', 'MONACO', 'EUR');
INSERT INTO `country` VALUES ('MQ', 'MARTINIQUE', 'EUR');
INSERT INTO `country` VALUES ('NL', 'NETHERLANDS', 'EUR');
INSERT INTO `country` VALUES ('PM', 'SAINT PIERRE AND MIQUELON', 'EUR');
INSERT INTO `country` VALUES ('PT', 'PORTUGAL', 'EUR');
INSERT INTO `country` VALUES ('RE', 'REUNION', 'EUR');
INSERT INTO `country` VALUES ('SM', 'SAN MARINO', 'EUR');
INSERT INTO `country` VALUES ('VA', 'VATICAN CITY STATE (HOLY SEE)', 'EUR');
INSERT INTO `country` VALUES ('YT', 'MAYOTTE', 'EUR');
INSERT INTO `country` VALUES ('FJ', 'FIJI', 'FJD');
INSERT INTO `country` VALUES ('FK', 'FALKLAND ISLANDS (MALVINAS)', 'FKP');
INSERT INTO `country` VALUES ('GB', 'UNITED KINGDOM', 'GBP');
INSERT INTO `country` VALUES ('GH', 'GHANA', 'GHC');
INSERT INTO `country` VALUES ('GI', 'GIBRALTAR', 'GIP');
INSERT INTO `country` VALUES ('GM', 'GAMBIA', 'GMD');
INSERT INTO `country` VALUES ('GN', 'GUINEA', 'GNF');
INSERT INTO `country` VALUES ('GT', 'GUATEMALA', 'GTQ');
INSERT INTO `country` VALUES ('HK', 'HONG KONG', 'HKD');
INSERT INTO `country` VALUES ('HN', 'HONDURAS', 'HNL');
INSERT INTO `country` VALUES ('HU', 'HUNGARY', 'HUF');
INSERT INTO `country` VALUES ('ID', 'INDONESIA', 'IDR');
INSERT INTO `country` VALUES ('IL', 'ISRAEL', 'ILS');
INSERT INTO `country` VALUES ('IN', 'INDIA', 'INR');
INSERT INTO `country` VALUES ('IQ', 'IRAQ', 'IQD');
INSERT INTO `country` VALUES ('IR', 'IRAN (ISLAMIC REPUBLIC OF)', 'IRR');
INSERT INTO `country` VALUES ('IS', 'ICELAND', 'ISK');
INSERT INTO `country` VALUES ('JM', 'JAMAICA', 'JMD');
INSERT INTO `country` VALUES ('JO', 'JORDAN', 'JOD');
INSERT INTO `country` VALUES ('JP', 'JAPAN', 'JPY');
INSERT INTO `country` VALUES ('KE', 'KENYA', 'KES');
INSERT INTO `country` VALUES ('KH', 'CAMBODIA', 'KHR');
INSERT INTO `country` VALUES ('KM', 'COMOROS', 'KMF');
INSERT INTO `country` VALUES ('KP', 'KOREA, DEMOCRATIC PEOPLE\'S REPUBLIC OF', 'KPW');
INSERT INTO `country` VALUES ('KR', 'KOREA, REPUBLIC OF', 'KRW');
INSERT INTO `country` VALUES ('KW', 'KUWAIT', 'KWD');
INSERT INTO `country` VALUES ('KY', 'CAYMAN ISLANDS', 'KYD');
INSERT INTO `country` VALUES ('LA', 'REPUBLIC', 'LAK');
INSERT INTO `country` VALUES ('LB', 'LEBANON', 'LBP');
INSERT INTO `country` VALUES ('LK', 'SRI LANKA', 'LKR');
INSERT INTO `country` VALUES ('LR', 'LIBERIA', 'LRD');
INSERT INTO `country` VALUES ('LY', 'LIBYAN ARAB JAMAHIRIYA', 'LYD');
INSERT INTO `country` VALUES ('EH', 'WESTERN SAHARA', 'MAD');
INSERT INTO `country` VALUES ('MA', 'MOROCCO', 'MAD');
INSERT INTO `country` VALUES ('MN', 'MONGOLIA', 'MNT');
INSERT INTO `country` VALUES ('MO', 'MACAU', 'MOP');
INSERT INTO `country` VALUES ('MR', 'MAURITANIA', 'MRO');
INSERT INTO `country` VALUES ('MT', 'MALTA', 'MTL');
INSERT INTO `country` VALUES ('MU', 'MAURITIUS', 'MUR');
INSERT INTO `country` VALUES ('MV', 'MALDIVES', 'MVR');
INSERT INTO `country` VALUES ('MW', 'MALAWI', 'MWK');
INSERT INTO `country` VALUES ('MY', 'MALAYSIA', 'MYR');
INSERT INTO `country` VALUES ('MZ', 'MOZAMBIQUE', 'MZM');
INSERT INTO `country` VALUES ('NG', 'NIGERIA', 'NGN');
INSERT INTO `country` VALUES ('BV', 'BOUVET ISLAND', 'NOK');
INSERT INTO `country` VALUES ('NO', 'NORWAY', 'NOK');
INSERT INTO `country` VALUES ('SJ', 'SVALBARD AND JAN MAYEN', 'NOK');
INSERT INTO `country` VALUES ('NP', 'NEPAL', 'NPR');
INSERT INTO `country` VALUES ('CK', 'COOK ISLANDS', 'NZD');
INSERT INTO `country` VALUES ('NU', 'NIUE', 'NZD');
INSERT INTO `country` VALUES ('NZ', 'NEW ZEALAND', 'NZD');
INSERT INTO `country` VALUES ('PN', 'PITCAIRN', 'NZD');
INSERT INTO `country` VALUES ('TK', 'TOKELAU', 'NZD');
INSERT INTO `country` VALUES ('OM', 'OMAN', 'OMR');
INSERT INTO `country` VALUES ('PG', 'PAPUA NEW GUINEA', 'PGK');
INSERT INTO `country` VALUES ('PH', 'PHILIPPINES', 'PHP');
INSERT INTO `country` VALUES ('PK', 'PAKISTAN', 'PKR');
INSERT INTO `country` VALUES ('PY', 'PARAGUAY', 'PYG');
INSERT INTO `country` VALUES ('RO', 'ROMANIA', 'ROL');
INSERT INTO `country` VALUES ('RW', 'RWANDA', 'RWF');
INSERT INTO `country` VALUES ('SA', 'SAUDI ARABIA', 'SAR');
INSERT INTO `country` VALUES ('SB', 'SOLOMON ISLANDS', 'SBD');
INSERT INTO `country` VALUES ('SC', 'SEYCHELLES', 'SCR');
INSERT INTO `country` VALUES ('SE', 'SWEDEN', 'SEK');
INSERT INTO `country` VALUES ('SG', 'SINGAPORE', 'SGD');
INSERT INTO `country` VALUES ('SH', 'SAINT HELENA', 'SHP');
INSERT INTO `country` VALUES ('SK', 'SLOVAKIA', 'SKK');
INSERT INTO `country` VALUES ('SL', 'SIERRA LEONE', 'SLL');
INSERT INTO `country` VALUES ('SO', 'SOMALIA', 'SOS');
INSERT INTO `country` VALUES ('ST', 'SAO TOME AND PRINCIPE', 'STD');
INSERT INTO `country` VALUES ('SV', 'EL SALVADOR', 'SVC');
INSERT INTO `country` VALUES ('SY', 'SYRIAN ARAB REPUBLIC', 'SYP');
INSERT INTO `country` VALUES ('SZ', 'SWAZILAND', 'SZL');
INSERT INTO `country` VALUES ('TH', 'THAILAND', 'THB');
INSERT INTO `country` VALUES ('TN', 'TUNISIA', 'TND');
INSERT INTO `country` VALUES ('TO', 'TONGA', 'TOP');
INSERT INTO `country` VALUES ('TT', 'TRINIDAD AND TOBAGO', 'TTD');
INSERT INTO `country` VALUES ('TW', 'TAIWAN, PROVINCE OF CHINA', 'TWD');
INSERT INTO `country` VALUES ('TZ', 'REPUBLIC OF', 'TZS');
INSERT INTO `country` VALUES ('AS', 'AMERICAN SAMOA', 'USD');
INSERT INTO `country` VALUES ('FM', 'STATES OF)', 'USD');
INSERT INTO `country` VALUES ('GU', 'GUAM', 'USD');
INSERT INTO `country` VALUES ('HT', 'HAITI', 'USD');
INSERT INTO `country` VALUES ('IO', 'BRITISH INDIAN OCEAN TERRITORY', 'USD');
/* INSERT INTO `country` VALUES ('MH', 'MARSHALL ISLANDS', 'USD'); */
INSERT INTO `country` VALUES ('MP', 'NORTHERN MARIANA ISLANDS', 'USD');
INSERT INTO `country` VALUES ('PA', 'PANAMA', 'USD');
INSERT INTO `country` VALUES ('PR', 'PUERTO RICO', 'USD');
INSERT INTO `country` VALUES ('PW', 'PALAU', 'USD');
INSERT INTO `country` VALUES ('TC', 'TURKS AND CAICOS ISLANDS', 'USD');
/* INSERT INTO `country` VALUES ('UM', 'OUTLYING ISLANDS', 'USD'); */
INSERT INTO `country` VALUES ('US', 'UNITED STATES', 'USD');
INSERT INTO `country` VALUES ('VG', 'VIRGIN ISLANDS (BRITISH)', 'USD');
INSERT INTO `country` VALUES ('VI', 'VIRGIN ISLANDS (U.S.)', 'USD');
INSERT INTO `country` VALUES ('VE', 'VENEZUELA', 'VEB');
INSERT INTO `country` VALUES ('VN', 'VIET NAM', 'VND');
INSERT INTO `country` VALUES ('VU', 'VANUATU', 'VUV');
INSERT INTO `country` VALUES ('WS', 'SAMOA', 'WST');
INSERT INTO `country` VALUES ('YE', 'YEMEN', 'YER');
INSERT INTO `country` VALUES ('ZA', 'SOUTH AFRICA', 'ZAR');
/* INSERT INTO `country` VALUES ('ZR', 'ZAIRE', 'ZAR'); */
INSERT INTO `country` VALUES ('ZM', 'ZAMBIA', 'ZMK');
INSERT INTO `country` VALUES ('ZW', 'ZIMBABWE', 'ZWD');
/*!40000 ALTER TABLE `country` ENABLE KEYS */;


# Dumping structure for table ebus.currency
CREATE TABLE IF NOT EXISTS `currency` (
  `code` char(3) NOT NULL DEFAULT '',
  `description` varchar(256) NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.currency: ~118 rows (approximately)
/*!40000 ALTER TABLE `currency` DISABLE KEYS */;
INSERT INTO `currency` VALUES ('AED', 'United Arab Emirates, Dirhams');
INSERT INTO `currency` VALUES ('ALL', 'Albania, Leke');
INSERT INTO `currency` VALUES ('ANG', 'Netherlands Antilles, Guilders (also called Florins)');
INSERT INTO `currency` VALUES ('AUD', 'Australia, Dollars');
INSERT INTO `currency` VALUES ('AWG', 'Aruba, Guilders (also called Florins)');
INSERT INTO `currency` VALUES ('BBD', 'Barbados, Dollars');
INSERT INTO `currency` VALUES ('BDT', 'Bangladesh, Taka');
INSERT INTO `currency` VALUES ('BHD', 'Bahrain, Dinars');
INSERT INTO `currency` VALUES ('BIF', 'Burundi, Francs');
INSERT INTO `currency` VALUES ('BMD', 'Bermuda, Dollars');
INSERT INTO `currency` VALUES ('BND', 'Brunei Darussalam, Dollars');
INSERT INTO `currency` VALUES ('BOB', 'Bolivia, Bolivianos');
INSERT INTO `currency` VALUES ('BSD', 'Bahamas, Dollars');
INSERT INTO `currency` VALUES ('BTN', 'Bhutan, Ngultrum');
INSERT INTO `currency` VALUES ('BWP', 'Botswana, Pulas');
INSERT INTO `currency` VALUES ('BZD', 'Belize, Dollars');
INSERT INTO `currency` VALUES ('CAD', 'Canada, Dollars');
INSERT INTO `currency` VALUES ('CHF', 'Switzerland, Francs');
INSERT INTO `currency` VALUES ('CLP', 'Chile, Pesos');
INSERT INTO `currency` VALUES ('CNY', 'China, Yuan Renminbi');
INSERT INTO `currency` VALUES ('COP', 'Colombia, Pesos');
INSERT INTO `currency` VALUES ('CRC', 'Costa Rica, Colones');
INSERT INTO `currency` VALUES ('CUP', 'Cuba, Pesos');
INSERT INTO `currency` VALUES ('CVE', 'Cape Verde, Escudos');
INSERT INTO `currency` VALUES ('CYP', 'Cyprus, Pounds');
INSERT INTO `currency` VALUES ('DJF', 'Djibouti, Francs');
INSERT INTO `currency` VALUES ('DKK', 'Denmark, Kroner');
INSERT INTO `currency` VALUES ('DOP', 'Dominican Republic, Pesos');
INSERT INTO `currency` VALUES ('DZD', 'Algeria, Algeria Dinars');
INSERT INTO `currency` VALUES ('EGP', 'Egypt, Pounds');
INSERT INTO `currency` VALUES ('ETB', 'Ethiopia, Birr');
INSERT INTO `currency` VALUES ('EUR', 'Euro Member Countries, Euro');
INSERT INTO `currency` VALUES ('FJD', 'Fiji, Dollars');
INSERT INTO `currency` VALUES ('FKP', 'Falkland Islands (Malvinas), Pounds');
INSERT INTO `currency` VALUES ('GBP', 'United Kingdom, Pounds');
INSERT INTO `currency` VALUES ('GHC', 'Ghana, Cedis');
INSERT INTO `currency` VALUES ('GIP', 'Gibraltar, Pounds');
INSERT INTO `currency` VALUES ('GMD', 'Gambia, Dalasi');
INSERT INTO `currency` VALUES ('GNF', 'Guinea, Francs');
INSERT INTO `currency` VALUES ('GTQ', 'Guatemala, Quetzales');
INSERT INTO `currency` VALUES ('GYD', 'Guyana, Dollars');
INSERT INTO `currency` VALUES ('HKD', 'Hong Kong, Dollars');
INSERT INTO `currency` VALUES ('HNL', 'Honduras, Lempiras');
INSERT INTO `currency` VALUES ('HTG', 'Haiti, Gourdes');
INSERT INTO `currency` VALUES ('HUF', 'Hungary, Forint');
INSERT INTO `currency` VALUES ('IDR', 'Indonesia, Rupiahs');
INSERT INTO `currency` VALUES ('ILS', 'Israel, New Shekels');
INSERT INTO `currency` VALUES ('INR', 'India, Rupees');
INSERT INTO `currency` VALUES ('IQD', 'Iraq, Dinars');
INSERT INTO `currency` VALUES ('IRR', 'Iran, Rials');
INSERT INTO `currency` VALUES ('ISK', 'Iceland, Kronur');
INSERT INTO `currency` VALUES ('JMD', 'Jamaica, Dollars');
INSERT INTO `currency` VALUES ('JOD', 'Jordan, Dinars');
INSERT INTO `currency` VALUES ('JPY', 'Japan, Yen');
INSERT INTO `currency` VALUES ('KES', 'Kenya, Shillings');
INSERT INTO `currency` VALUES ('KHR', 'Cambodia, Riels');
INSERT INTO `currency` VALUES ('KMF', 'Comoros, Francs');
INSERT INTO `currency` VALUES ('KPW', 'Korea (North), Won');
INSERT INTO `currency` VALUES ('KRW', 'Korea (South), Won');
INSERT INTO `currency` VALUES ('KWD', 'Kuwait, Dinars');
INSERT INTO `currency` VALUES ('KYD', 'Cayman Islands, Dollars');
INSERT INTO `currency` VALUES ('LAK', 'Laos, Kips');
INSERT INTO `currency` VALUES ('LBP', 'Lebanon, Pounds');
INSERT INTO `currency` VALUES ('LKR', 'Sri Lanka, Rupees');
INSERT INTO `currency` VALUES ('LRD', 'Liberia, Dollars');
INSERT INTO `currency` VALUES ('LSL', 'Lesotho, Maloti');
INSERT INTO `currency` VALUES ('LYD', 'Libya, Dinars');
INSERT INTO `currency` VALUES ('MAD', 'Morocco, Dirhams');
INSERT INTO `currency` VALUES ('MNT', 'Mongolia, Tugriks');
INSERT INTO `currency` VALUES ('MOP', 'Macau, Patacas');
INSERT INTO `currency` VALUES ('MRO', 'Mauritania, Ouguiyas');
INSERT INTO `currency` VALUES ('MTL', 'Malta, Liri');
INSERT INTO `currency` VALUES ('MUR', 'Mauritius, Rupees');
INSERT INTO `currency` VALUES ('MVR', 'Maldives (Maldive Islands), Rufiyaa');
INSERT INTO `currency` VALUES ('MWK', 'Malawi, Kwachas');
INSERT INTO `currency` VALUES ('MYR', 'Malaysia, Ringgits');
INSERT INTO `currency` VALUES ('MZM', 'Mozambique, Meticais');
INSERT INTO `currency` VALUES ('NGN', 'Nigeria, Nairas');
INSERT INTO `currency` VALUES ('NOK', 'Norway, Krone');
INSERT INTO `currency` VALUES ('NPR', 'Nepal, Nepal Rupees');
INSERT INTO `currency` VALUES ('NZD', 'New Zealand, Dollars');
INSERT INTO `currency` VALUES ('OMR', 'Oman, Rials');
INSERT INTO `currency` VALUES ('PAB', 'Panama, Balboa');
INSERT INTO `currency` VALUES ('PGK', 'Papua New Guinea, Kina');
INSERT INTO `currency` VALUES ('PHP', 'Philippines, Pesos');
INSERT INTO `currency` VALUES ('PKR', 'Pakistan, Rupees');
INSERT INTO `currency` VALUES ('PYG', 'Paraguay, Guarani');
INSERT INTO `currency` VALUES ('QAR', 'Qatar, Rials');
INSERT INTO `currency` VALUES ('ROL', 'Romania, Lei [being phased out]');
INSERT INTO `currency` VALUES ('RWF', 'Rwanda, Rwanda Francs');
INSERT INTO `currency` VALUES ('SAR', 'Saudi Arabia, Riyals');
INSERT INTO `currency` VALUES ('SBD', 'Solomon Islands, Dollars');
INSERT INTO `currency` VALUES ('SCR', 'Seychelles, Rupees');
INSERT INTO `currency` VALUES ('SEK', 'Sweden, Kronor');
INSERT INTO `currency` VALUES ('SGD', 'Singapore, Dollars');
INSERT INTO `currency` VALUES ('SHP', 'Saint Helena, Pounds');
INSERT INTO `currency` VALUES ('SKK', 'Slovakia, Koruny');
INSERT INTO `currency` VALUES ('SLL', 'Sierra Leone, Leones');
INSERT INTO `currency` VALUES ('SOS', 'Somalia, Shillings');
INSERT INTO `currency` VALUES ('STD', 'São Tome and Principe, Dobras');
INSERT INTO `currency` VALUES ('SVC', 'El Salvador, Colones');
INSERT INTO `currency` VALUES ('SYP', 'Syria, Pounds');
INSERT INTO `currency` VALUES ('SZL', 'Swaziland, Emalangeni');
INSERT INTO `currency` VALUES ('THB', 'Thailand, Baht');
INSERT INTO `currency` VALUES ('TND', 'Tunisia, Dinars');
INSERT INTO `currency` VALUES ('TOP', 'Tonga, Pa\'anga');
INSERT INTO `currency` VALUES ('TTD', 'Trinidad and Tobago, Dollars');
INSERT INTO `currency` VALUES ('TWD', 'Taiwan, New Dollars');
INSERT INTO `currency` VALUES ('TZS', 'Tanzania, Shillings');
INSERT INTO `currency` VALUES ('USD', 'United States of America, Dollars');
INSERT INTO `currency` VALUES ('VEB', 'Venezuela, Bolivares');
INSERT INTO `currency` VALUES ('VND', 'Viet Nam, Dong');
INSERT INTO `currency` VALUES ('VUV', 'Vanuatu, Vatu');
INSERT INTO `currency` VALUES ('WST', 'Samoa, Tala');
INSERT INTO `currency` VALUES ('YER', 'Yemen, Rials');
INSERT INTO `currency` VALUES ('ZAR', 'South Africa, Rand');
INSERT INTO `currency` VALUES ('ZMK', 'Zambia, Kwacha');
INSERT INTO `currency` VALUES ('ZWD', 'Zimbabwe, Zimbabwe Dollars');
/*!40000 ALTER TABLE `currency` ENABLE KEYS */;


# Dumping structure for table ebus.customer
CREATE TABLE IF NOT EXISTS `customer` (
  `customerid` char(40) NOT NULL DEFAULT '',
  `companyname` varchar(255) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `address` char(40) NOT NULL,
  `ws_user_name` varchar(255) DEFAULT NULL,
  `ws_password` varchar(255) DEFAULT NULL,
  `ws_delivery_endpoint` varchar(255) DEFAULT NULL,
  `ws_invoice_endpoint` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`customerid`),
  UNIQUE KEY `customer_u1` (`address`),
  CONSTRAINT `customer_address_fk` FOREIGN KEY (`address`) REFERENCES `address` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.customer: ~2 rows (approximately)
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` (`customerid`, `companyname`, `firstname`, `lastname`, `remark`, `address`, `ws_user_name`, `ws_password`, `ws_delivery_endpoint`, `ws_invoice_endpoint`) VALUES
	('10', 'HTWG Konstanz', 'HTWG', 'Konstanz', NULL, '20', 'ws_htwg_1', 'ws_htwg_1', 'http://localhost:8080/eps/DeliveryService', 'http://localhost:8080/eps/InvoiceService'),
	('11', 'Sportscheck', 'Sporty', 'Sportsman', NULL, '80', 'sportscheck_user_ws', 'sportscheck_user_ws', 'http://localhost:8080/eps/DeliveryService', 'http://localhost:8080/eps/InvoiceService');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;


# Dumping structure for table ebus.customeridentifcation
CREATE TABLE IF NOT EXISTS `customeridentifcation` (
  `companyidenttype` char(8) NOT NULL,
  `identification` char(40) NOT NULL,
  `customer` char(40) DEFAULT NULL,
  PRIMARY KEY (`companyidenttype`,`identification`),
  UNIQUE KEY `custid_u1` (`companyidenttype`,`customer`),
  KEY `custid_customer_fk` (`customer`),
  CONSTRAINT `custid_compidtyp_fk` FOREIGN KEY (`companyidenttype`) REFERENCES `companyidenttype` (`companyidenttype`),
  CONSTRAINT `custid_customer_fk` FOREIGN KEY (`customer`) REFERENCES `customer` (`customerid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.customeridentifcation: ~0 rows (approximately)
/*!40000 ALTER TABLE `customeridentifcation` DISABLE KEYS */;
/*!40000 ALTER TABLE `customeridentifcation` ENABLE KEYS */;


# Dumping structure for table ebus.fulfillmentinfoitem_customer
CREATE TABLE IF NOT EXISTS `fulfillmentinfoitem_customer` (
  `fulfillmentinfo` char(40) NOT NULL DEFAULT '',
  `itemnumber` int(11) NOT NULL DEFAULT '0',
  `ordernumber_customer` char(40) NOT NULL,
  `productdescription` varchar(256) DEFAULT NULL,
  `orderamount` int(11) NOT NULL,
  `orderunit` char(16) NOT NULL,
  `contentunit` char(16) DEFAULT NULL,
  `no_cu_per_ou` int(11) DEFAULT '1',
  `unitprice` decimal(10,2) DEFAULT NULL,
  `itemprice` decimal(10,2) DEFAULT NULL,
  `pricetype` char(16) DEFAULT NULL,
  `pricequantity` int(11) DEFAULT NULL,
  `taxrate` decimal(4,2) DEFAULT NULL,
  `taxamount` decimal(10,2) DEFAULT NULL,
  `deliveryaddress` char(40) DEFAULT NULL,
  `partialshipment` int(11) DEFAULT NULL,
  `transport` varchar(256) DEFAULT NULL,
  `specialtreatment` varchar(256) DEFAULT NULL,
  `internationalrestrictions` varchar(256) DEFAULT NULL,
  `remark` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`fulfillmentinfo`,`itemnumber`),
  KEY `fulfitemcust_deladdr_fk` (`deliveryaddress`),
  CONSTRAINT `fulfitemcust_deladdr_fk` FOREIGN KEY (`deliveryaddress`) REFERENCES `address` (`id`),
  CONSTRAINT `fulfitemcust_fulfinfo_fk` FOREIGN KEY (`fulfillmentinfo`) REFERENCES `fulfillmentinfo_customer` (`fulfillmentinfoid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.fulfillmentinfoitem_customer: ~0 rows (approximately)
/*!40000 ALTER TABLE `fulfillmentinfoitem_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `fulfillmentinfoitem_customer` ENABLE KEYS */;


# Dumping structure for table ebus.fulfillmentinfoitem_purchase
CREATE TABLE IF NOT EXISTS `fulfillmentinfoitem_purchase` (
  `fulfillmentinfo` char(40) NOT NULL DEFAULT '',
  `itemnumber` int(11) NOT NULL DEFAULT '0',
  `ordernumber_supplier` char(40) NOT NULL,
  `productdescription` varchar(256) DEFAULT NULL,
  `orderamount` int(11) NOT NULL,
  `orderunit` char(16) NOT NULL,
  `contentunit` char(16) DEFAULT NULL,
  `no_cu_per_ou` int(11) DEFAULT '1',
  `unitprice` decimal(10,2) DEFAULT NULL,
  `itemprice` decimal(10,2) DEFAULT NULL,
  `pricetype` char(16) DEFAULT NULL,
  `pricequantity` int(11) DEFAULT NULL,
  `taxrate` decimal(4,2) DEFAULT NULL,
  `taxamount` decimal(10,2) DEFAULT NULL,
  `deliveryaddress` char(40) DEFAULT NULL,
  `partialshipment` int(11) DEFAULT NULL,
  `transport` varchar(256) DEFAULT NULL,
  `specialtreatment` varchar(256) DEFAULT NULL,
  `internationalrestrictions` varchar(256) DEFAULT NULL,
  `remark` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`fulfillmentinfo`,`itemnumber`),
  KEY `fulfitempurc_deladdr_fk` (`deliveryaddress`),
  CONSTRAINT `fulfitempurc_deladdr_fk` FOREIGN KEY (`deliveryaddress`) REFERENCES `address` (`id`),
  CONSTRAINT `fulfitempurc_fulfinfo_fk` FOREIGN KEY (`fulfillmentinfo`) REFERENCES `fulfillmentinfo_purchase` (`fulfillmentinfoid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.fulfillmentinfoitem_purchase: ~0 rows (approximately)
/*!40000 ALTER TABLE `fulfillmentinfoitem_purchase` DISABLE KEYS */;
/*!40000 ALTER TABLE `fulfillmentinfoitem_purchase` ENABLE KEYS */;


# Dumping structure for table ebus.fulfillmentinfo_customer
CREATE TABLE IF NOT EXISTS `fulfillmentinfo_customer` (
  `fulfillmentinfoid` char(40) NOT NULL DEFAULT '',
  `fulfillmentinfodate` date NOT NULL,
  `orderref` char(40) NOT NULL,
  `customer` char(40) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `ordertype` char(16) DEFAULT NULL,
  `orderid_customer` char(40) DEFAULT NULL,
  `invoiceaddress` char(40) DEFAULT NULL,
  `deliveryaddress` char(40) DEFAULT NULL,
  `currency` char(3) DEFAULT NULL,
  `remark` varchar(2000) DEFAULT NULL,
  `partialshipment` int(11) DEFAULT NULL,
  `transport` varchar(256) DEFAULT NULL,
  `specialtreatment` varchar(256) DEFAULT NULL,
  `internationalrestrictions` varchar(256) DEFAULT NULL,
  `pricetotal_net` decimal(10,2) DEFAULT NULL,
  `pricetotal_gross` decimal(10,2) DEFAULT NULL,
  `taxtotal` decimal(10,2) DEFAULT NULL,
  `taxamount` decimal(10,2) DEFAULT NULL,
  `totallineitems` int(11) DEFAULT NULL,
  PRIMARY KEY (`fulfillmentinfoid`),
  KEY `fulfinfocust_order_fk` (`orderref`),
  KEY `fulfinfocust_customer_fk` (`customer`),
  KEY `fulfinfocust_currency_fk` (`currency`),
  KEY `fulfinfocust_invaddr_fk` (`invoiceaddress`),
  KEY `fulfinfocust_deladdr_fk` (`deliveryaddress`),
  CONSTRAINT `fulfinfocust_currency_fk` FOREIGN KEY (`currency`) REFERENCES `currency` (`code`),
  CONSTRAINT `fulfinfocust_customer_fk` FOREIGN KEY (`customer`) REFERENCES `customer` (`customerid`),
  CONSTRAINT `fulfinfocust_deladdr_fk` FOREIGN KEY (`deliveryaddress`) REFERENCES `address` (`id`),
  CONSTRAINT `fulfinfocust_invaddr_fk` FOREIGN KEY (`invoiceaddress`) REFERENCES `address` (`id`),
  CONSTRAINT `fulfinfocust_order_fk` FOREIGN KEY (`orderref`) REFERENCES `order_customer` (`orderid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.fulfillmentinfo_customer: ~0 rows (approximately)
/*!40000 ALTER TABLE `fulfillmentinfo_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `fulfillmentinfo_customer` ENABLE KEYS */;


# Dumping structure for table ebus.fulfillmentinfo_purchase
CREATE TABLE IF NOT EXISTS `fulfillmentinfo_purchase` (
  `fulfillmentinfoid` char(40) NOT NULL DEFAULT '',
  `fulfillmentinfodate` date NOT NULL,
  `supplier` char(40) DEFAULT NULL,
  `fulfillmentinfoid_supplier` char(40) DEFAULT NULL,
  `orderref` char(40) NOT NULL,
  `orderdate` date DEFAULT NULL,
  `ordertype` char(16) DEFAULT NULL,
  `orderid_supplier` char(40) DEFAULT NULL,
  `invoiceaddress` char(40) DEFAULT NULL,
  `deliveryaddress` char(40) DEFAULT NULL,
  `currency` char(3) DEFAULT NULL,
  `remark` varchar(2000) DEFAULT NULL,
  `partialshipment` int(11) DEFAULT NULL,
  `transport` varchar(256) DEFAULT NULL,
  `specialtreatment` varchar(256) DEFAULT NULL,
  `internationalrestrictions` varchar(256) DEFAULT NULL,
  `pricetotal_net` decimal(10,2) DEFAULT NULL,
  `pricetotal_gross` decimal(10,2) DEFAULT NULL,
  `taxtotal` decimal(10,2) DEFAULT NULL,
  `taxamount` decimal(10,2) DEFAULT NULL,
  `totallineitems` int(11) DEFAULT NULL,
  PRIMARY KEY (`fulfillmentinfoid`),
  UNIQUE KEY `fulfinfopurc_u1` (`fulfillmentinfoid_supplier`,`supplier`),
  KEY `fulfinfopurc_order_fk` (`orderref`),
  KEY `fulfinfopurc_customer_fk` (`supplier`),
  KEY `fulfinfopurc_currency_fk` (`currency`),
  KEY `fulfinfopurc_invaddr_fk` (`invoiceaddress`),
  KEY `fulfinfopurc_deladdr_fk` (`deliveryaddress`),
  CONSTRAINT `fulfinfopurc_currency_fk` FOREIGN KEY (`currency`) REFERENCES `currency` (`code`),
  CONSTRAINT `fulfinfopurc_customer_fk` FOREIGN KEY (`supplier`) REFERENCES `supplier` (`suppliernumber`),
  CONSTRAINT `fulfinfopurc_deladdr_fk` FOREIGN KEY (`deliveryaddress`) REFERENCES `address` (`id`),
  CONSTRAINT `fulfinfopurc_invaddr_fk` FOREIGN KEY (`invoiceaddress`) REFERENCES `address` (`id`),
  CONSTRAINT `fulfinfopurc_order_fk` FOREIGN KEY (`orderref`) REFERENCES `order_purchase` (`orderid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.fulfillmentinfo_purchase: ~0 rows (approximately)
/*!40000 ALTER TABLE `fulfillmentinfo_purchase` DISABLE KEYS */;
/*!40000 ALTER TABLE `fulfillmentinfo_purchase` ENABLE KEYS */;


# Dumping structure for table ebus.fulfillment_shipment_customer
CREATE TABLE IF NOT EXISTS `fulfillment_shipment_customer` (
  `shipment` char(40) NOT NULL DEFAULT '',
  `fulfillmentinfo` char(40) NOT NULL DEFAULT '',
  PRIMARY KEY (`shipment`,`fulfillmentinfo`),
  KEY `fulfshipcust_fulfcust_fk` (`fulfillmentinfo`),
  CONSTRAINT `fulfshipcust_fulfcust_fk` FOREIGN KEY (`fulfillmentinfo`) REFERENCES `fulfillmentinfo_customer` (`fulfillmentinfoid`),
  CONSTRAINT `fulfshipcust_shipcust_fk` FOREIGN KEY (`shipment`) REFERENCES `shipment_customer` (`shipmentid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.fulfillment_shipment_customer: ~0 rows (approximately)
/*!40000 ALTER TABLE `fulfillment_shipment_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `fulfillment_shipment_customer` ENABLE KEYS */;


# Dumping structure for table ebus.fulfillment_shipment_purchase
CREATE TABLE IF NOT EXISTS `fulfillment_shipment_purchase` (
  `shipment` char(40) NOT NULL DEFAULT '',
  `fulfillmentinfo` char(40) NOT NULL DEFAULT '',
  PRIMARY KEY (`shipment`,`fulfillmentinfo`),
  KEY `fulfshippurc_fulfpurc_fk` (`fulfillmentinfo`),
  CONSTRAINT `fulfshippurc_fulfpurc_fk` FOREIGN KEY (`fulfillmentinfo`) REFERENCES `fulfillmentinfo_purchase` (`fulfillmentinfoid`),
  CONSTRAINT `fulfshippurc_shippurc_fk` FOREIGN KEY (`shipment`) REFERENCES `shipment_purchase` (`shipmentid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.fulfillment_shipment_purchase: ~0 rows (approximately)
/*!40000 ALTER TABLE `fulfillment_shipment_purchase` DISABLE KEYS */;
/*!40000 ALTER TABLE `fulfillment_shipment_purchase` ENABLE KEYS */;


# Dumping structure for table ebus.inventory
CREATE TABLE IF NOT EXISTS `inventory` (
  `product` int(11) NOT NULL DEFAULT '0',
  `inventory` int(11) DEFAULT '0',
  `threshold_reorder` int(11) DEFAULT '0',
  `number_to_reorder` int(11) DEFAULT NULL,
  `nonphysicaldelivery` int(11) DEFAULT '0',
  `relativepath_digitalproduct` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`product`),
  CONSTRAINT `inventory_produkt_fk` FOREIGN KEY (`product`) REFERENCES `product` (`materialnumber`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.inventory: ~17 rows (approximately)
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
INSERT INTO `inventory` (`product`, `inventory`, `threshold_reorder`, `number_to_reorder`, `nonphysicaldelivery`, `relativepath_digitalproduct`) VALUES
	(1, 1000, 100, 50, 0, NULL),
	(2, 1000, 100, 50, 0, NULL),
	(3, 1000, 100, 50, 0, NULL),
	(4, 1000, 100, 50, 0, NULL),
	(5, 1000, 100, 11, 0, NULL),
	(6, 1000, 100, 50, 0, NULL),
	(7, 1000, 100, 50, 0, NULL),
	(8, 1000, 100, 50, 0, NULL),
	(9, 1000, 100, 50, 0, NULL),
	(10, 1000, 100, 50, 0, NULL),
	(20, 1000, 100, 50, 0, NULL),
	(21, 1000, 100, 50, 0, NULL),
	(22, 1000, 100, 50, 0, NULL),
	(23, 1000, 100, 50, 0, NULL),
	(24, 1000, 100, 50, 0, NULL),
	(25, 1000, 100, 50, 0, NULL),
	(26, 1000, 100, 50, 0, NULL);
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;


# Dumping structure for table ebus.invoiceitem_customer
CREATE TABLE IF NOT EXISTS `invoiceitem_customer` (
  `invoice` char(40) NOT NULL DEFAULT '',
  `itemnumber` int(11) NOT NULL DEFAULT '0',
  `orderref` char(40) NOT NULL,
  `fulfillmentref` char(40) NOT NULL,
  `shipmentref` char(40) NOT NULL,
  `ordernumber_customer` char(40) NOT NULL,
  `productdescription` varchar(256) DEFAULT NULL,
  `orderamount` int(11) NOT NULL,
  `orderunit` char(16) NOT NULL,
  `contentunit` char(16) DEFAULT NULL,
  `no_cu_per_ou` int(11) DEFAULT '1',
  `unitprice` decimal(10,2) DEFAULT NULL,
  `itemprice` decimal(10,2) DEFAULT NULL,
  `pricetype` char(16) DEFAULT NULL,
  `pricequantity` int(11) DEFAULT NULL,
  `taxrate` decimal(4,2) DEFAULT NULL,
  `taxamount` decimal(10,2) DEFAULT NULL,
  `deliveryaddress` char(40) DEFAULT NULL,
  `partialshipment` int(11) DEFAULT NULL,
  `transport` varchar(256) DEFAULT NULL,
  `specialtreatment` varchar(256) DEFAULT NULL,
  `internationalrestrictions` varchar(256) DEFAULT NULL,
  `remark` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`invoice`,`itemnumber`),
  KEY `invitemcust_order_fk` (`orderref`),
  KEY `invitemcust_fulfill_fk` (`fulfillmentref`),
  KEY `invitemcust_ship_fk` (`shipmentref`),
  KEY `invitemcust_deladdr_fk` (`deliveryaddress`),
  CONSTRAINT `invitemcust_deladdr_fk` FOREIGN KEY (`deliveryaddress`) REFERENCES `address` (`id`),
  CONSTRAINT `invitemcust_fulfill_fk` FOREIGN KEY (`fulfillmentref`) REFERENCES `fulfillmentinfo_customer` (`fulfillmentinfoid`),
  CONSTRAINT `invitemcust_invoice_fk` FOREIGN KEY (`invoice`) REFERENCES `invoice_customer` (`invoiceid`) ON DELETE CASCADE,
  CONSTRAINT `invitemcust_order_fk` FOREIGN KEY (`orderref`) REFERENCES `order_customer` (`orderid`),
  CONSTRAINT `invitemcust_ship_fk` FOREIGN KEY (`shipmentref`) REFERENCES `shipment_customer` (`shipmentid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.invoiceitem_customer: ~0 rows (approximately)
/*!40000 ALTER TABLE `invoiceitem_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoiceitem_customer` ENABLE KEYS */;


# Dumping structure for table ebus.invoiceitem_purchase
CREATE TABLE IF NOT EXISTS `invoiceitem_purchase` (
  `invoice` char(40) NOT NULL DEFAULT '',
  `itemnumber` int(11) NOT NULL DEFAULT '0',
  `orderref` char(40) NOT NULL,
  `fulfillmentref` char(40) NOT NULL,
  `shipmentref` char(40) NOT NULL,
  `ordernumber_supplier` char(40) NOT NULL,
  `productdescription` varchar(256) DEFAULT NULL,
  `orderamount` int(11) NOT NULL,
  `orderunit` char(16) NOT NULL,
  `contentunit` char(16) DEFAULT NULL,
  `no_cu_per_ou` int(11) DEFAULT '1',
  `unitprice` decimal(10,2) DEFAULT NULL,
  `itemprice` decimal(10,2) DEFAULT NULL,
  `pricetype` char(16) DEFAULT NULL,
  `pricequantity` int(11) DEFAULT NULL,
  `taxrate` decimal(4,2) DEFAULT NULL,
  `taxamount` decimal(10,2) DEFAULT NULL,
  `deliveryaddress` char(40) DEFAULT NULL,
  `partialshipment` int(11) DEFAULT NULL,
  `transport` varchar(256) DEFAULT NULL,
  `specialtreatment` varchar(256) DEFAULT NULL,
  `internationalrestrictions` varchar(256) DEFAULT NULL,
  `remark` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`invoice`,`itemnumber`),
  KEY `invitempurc_order_fk` (`orderref`),
  KEY `invitempurc_fulfill_fk` (`fulfillmentref`),
  KEY `invitempurc_ship_fk` (`shipmentref`),
  KEY `invitempurc_deladdr_fk` (`deliveryaddress`),
  CONSTRAINT `invitempurc_deladdr_fk` FOREIGN KEY (`deliveryaddress`) REFERENCES `address` (`id`),
  CONSTRAINT `invitempurc_fulfill_fk` FOREIGN KEY (`fulfillmentref`) REFERENCES `fulfillmentinfo_customer` (`fulfillmentinfoid`),
  CONSTRAINT `invitempurc_invoice_fk` FOREIGN KEY (`invoice`) REFERENCES `invoice_customer` (`invoiceid`) ON DELETE CASCADE,
  CONSTRAINT `invitempurc_order_fk` FOREIGN KEY (`orderref`) REFERENCES `order_customer` (`orderid`),
  CONSTRAINT `invitempurc_ship_fk` FOREIGN KEY (`shipmentref`) REFERENCES `shipment_customer` (`shipmentid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.invoiceitem_purchase: ~0 rows (approximately)
/*!40000 ALTER TABLE `invoiceitem_purchase` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoiceitem_purchase` ENABLE KEYS */;


# Dumping structure for table ebus.invoice_customer
CREATE TABLE IF NOT EXISTS `invoice_customer` (
  `invoiceid` char(40) NOT NULL DEFAULT '',
  `invoicedate` date NOT NULL,
  `customer` char(40) DEFAULT NULL,
  `invoiceaddress` char(40) DEFAULT NULL,
  `currency` char(3) DEFAULT NULL,
  `remark` varchar(2000) DEFAULT NULL,
  `pricetotal_net` decimal(10,2) DEFAULT NULL,
  `pricetotal_gross` decimal(10,2) DEFAULT NULL,
  `taxtotal` decimal(10,2) DEFAULT NULL,
  `taxamount` decimal(10,2) DEFAULT NULL,
  `totallineitems` int(11) DEFAULT NULL,
  `paymenttype` char(32) DEFAULT NULL,
  `paymentinformation` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`invoiceid`),
  KEY `invcust_currency_fk` (`currency`),
  KEY `invcust_customer_fk` (`customer`),
  KEY `invcust_invadr_fk` (`invoiceaddress`),
  CONSTRAINT `invcust_currency_fk` FOREIGN KEY (`currency`) REFERENCES `currency` (`code`),
  CONSTRAINT `invcust_customer_fk` FOREIGN KEY (`customer`) REFERENCES `customer` (`customerid`),
  CONSTRAINT `invcust_invadr_fk` FOREIGN KEY (`invoiceaddress`) REFERENCES `address` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.invoice_customer: ~0 rows (approximately)
/*!40000 ALTER TABLE `invoice_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_customer` ENABLE KEYS */;


# Dumping structure for table ebus.invoice_purchase
CREATE TABLE IF NOT EXISTS `invoice_purchase` (
  `invoiceid` char(40) NOT NULL DEFAULT '',
  `invoicedate` date NOT NULL,
  `invoiceid_supplier` char(40) DEFAULT NULL,
  `supplier` char(40) DEFAULT NULL,
  `invoiceaddress` char(40) DEFAULT NULL,
  `currency` char(3) DEFAULT NULL,
  `remark` varchar(2000) DEFAULT NULL,
  `pricetotal_net` decimal(10,2) DEFAULT NULL,
  `pricetotal_gross` decimal(10,2) DEFAULT NULL,
  `taxtotal` decimal(10,2) DEFAULT NULL,
  `taxamount` decimal(10,2) DEFAULT NULL,
  `totallineitems` int(11) DEFAULT NULL,
  `paymenttype` char(32) DEFAULT NULL,
  `paymentinformation` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`invoiceid`),
  UNIQUE KEY `invpurc_u1` (`invoiceid_supplier`,`supplier`),
  KEY `invpurc_currency_fk` (`currency`),
  KEY `invpurc_customer_fk` (`supplier`),
  KEY `invpurc_invadr_fk` (`invoiceaddress`),
  CONSTRAINT `invpurc_currency_fk` FOREIGN KEY (`currency`) REFERENCES `currency` (`code`),
  CONSTRAINT `invpurc_customer_fk` FOREIGN KEY (`supplier`) REFERENCES `supplier` (`suppliernumber`),
  CONSTRAINT `invpurc_invadr_fk` FOREIGN KEY (`invoiceaddress`) REFERENCES `address` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.invoice_purchase: ~0 rows (approximately)
/*!40000 ALTER TABLE `invoice_purchase` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_purchase` ENABLE KEYS */;


# Dumping structure for table ebus.invoice_shipment_customer
CREATE TABLE IF NOT EXISTS `invoice_shipment_customer` (
  `shipment` char(40) NOT NULL DEFAULT '',
  `invoice` char(40) NOT NULL DEFAULT '',
  PRIMARY KEY (`shipment`,`invoice`),
  KEY `invshipcust_invcust_fk` (`invoice`),
  CONSTRAINT `invshipcust_invcust_fk` FOREIGN KEY (`invoice`) REFERENCES `invoice_customer` (`invoiceid`),
  CONSTRAINT `invshipcust_shipcust_fk` FOREIGN KEY (`shipment`) REFERENCES `shipment_customer` (`shipmentid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.invoice_shipment_customer: ~0 rows (approximately)
/*!40000 ALTER TABLE `invoice_shipment_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_shipment_customer` ENABLE KEYS */;


# Dumping structure for table ebus.invoice_shipment_purchase
CREATE TABLE IF NOT EXISTS `invoice_shipment_purchase` (
  `shipment` char(40) NOT NULL DEFAULT '',
  `invoice` char(40) NOT NULL DEFAULT '',
  PRIMARY KEY (`shipment`,`invoice`),
  KEY `invshippurc_invpurc_fk` (`invoice`),
  CONSTRAINT `invshippurc_invpurc_fk` FOREIGN KEY (`invoice`) REFERENCES `invoice_purchase` (`invoiceid`),
  CONSTRAINT `invshippurc_shippurc_fk` FOREIGN KEY (`shipment`) REFERENCES `shipment_purchase` (`shipmentid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.invoice_shipment_purchase: ~0 rows (approximately)
/*!40000 ALTER TABLE `invoice_shipment_purchase` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_shipment_purchase` ENABLE KEYS */;


# Dumping structure for table ebus.mimepurpose
CREATE TABLE IF NOT EXISTS `mimepurpose` (
  `code` char(32) NOT NULL DEFAULT '',
  `description` varchar(256) NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.mimepurpose: ~3 rows (approximately)
/*!40000 ALTER TABLE `mimepurpose` DISABLE KEYS */;
INSERT INTO `mimepurpose` (`code`, `description`) VALUES
	('data_sheet', 'Produktdatenblatt'),
	('logo', 'Logo'),
	('thumbnail', 'Thumbnail');
/*!40000 ALTER TABLE `mimepurpose` ENABLE KEYS */;


# Dumping structure for table ebus.mimetype
CREATE TABLE IF NOT EXISTS `mimetype` (
  `code` char(32) NOT NULL DEFAULT '',
  `description` varchar(256) NOT NULL,
  `fileextension` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.mimetype: ~137 rows (approximately)
/*!40000 ALTER TABLE `mimetype` DISABLE KEYS */;
INSERT INTO `mimetype` (`code`, `description`, `fileextension`) VALUES
	('application/acad', 'AutoCAD-Dateien (nach NCSA)', '*.dwg'),
	('application/applefile', 'AppleFile-Dateien', NULL),
	('application/astound', 'Astound-Dateien', '*.asd *.'),
	('application/dsptype', 'TSP-Dateien', '*.tsp'),
	('application/dxf', 'AutoCAD-Dateien (nach CERN)', '*.dxf'),
	('application/futuresplash', 'Flash Futuresplash-Dateien', '*.spl'),
	('application/gzip', 'GNU Zip-Dateien', '*.gz'),
	('application/listenup', 'Listenup-Dateien', '*.ptlk'),
	('application/mac-binhex40', 'Macintosh Binärdateien', '*.hqx'),
	('application/mbedlet', 'Mbedlet-Dateien', '*.mbd'),
	('application/mif', 'FrameMaker Interchange Format Dateien', '*.mif'),
	('application/msexcel', 'Microsoft Excel Dateien', '*.xls *.'),
	('application/mshelp', 'Microsoft Windows Hilfe Dateien', '*.hlp *.'),
	('application/mspowerpoint', 'Microsoft Powerpoint Dateien', '*.ppt *.'),
	('application/msword', 'Microsoft Word Dateien', '*.doc *.'),
	('application/octet-stream', 'Ausführbare Dateien', '*.bin *.'),
	('application/oda', 'Oda-Dateien', '*.oda'),
	('application/pdf', 'Adobe PDF-Dateien', '*.pdf'),
	('application/postscript', 'Adobe PostScript-Dateien', '*.ai *.e'),
	('application/rtc', 'RTC-Dateien', '*.rtc'),
	('application/rtf', 'Microsoft RTF-Dateien', '*.rtf'),
	('application/studiom', 'Studiom-Dateien', '*.smp'),
	('application/toolbook', 'Toolbook-Dateien', '*.tbk'),
	('application/vnd.wap.wmlc', 'WMLC-Dateien (WAP)', '*.wmlc'),
	('application/vnd.wap.wmlscriptc', 'WML-Script-C-dateien (WAP)', '*.wmlsc'),
	('application/vocaltec-media-desc', 'Vocaltec Mediadesc-Dateien', '*.vmd'),
	('application/vocaltec-media-file', 'Vocaltec Media-Dateien', '*.vmf'),
	('application/x-bcpio', 'BCPIO-Dateien', '*.bcpio'),
	('application/x-compress', 'zlib-komprimierte Dateien', '*.z'),
	('application/x-cpio', 'CPIO-Dateien', '*.cpio'),
	('application/x-csh', 'C-Shellscript-Dateien', '*.csh'),
	('application/x-director', 'Macromedia Director-Dateien', '*.dcr *.'),
	('application/x-dvi', 'DVI-Dateien', '*.dvi'),
	('application/x-envoy', 'Envoy-Dateien', '*.evy'),
	('application/x-gtar', 'GNU tar-Archivdateien', '*.gtar'),
	('application/x-hdf', 'HDF-Dateien', '*.hdf'),
	('application/x-httpd-php', 'PHP-Dateien', '*.php *.'),
	('application/x-javascript', 'serverseitige JavaScript-Dateien', '*.js'),
	('application/x-latex', 'LaTeX-Quelldateien', '*.latex'),
	('application/x-macbinary', 'Macintosh Binärdateien', '*.bin'),
	('application/x-mif', 'FrameMaker Interchange Format Dateien', '*.mif'),
	('application/x-netcdf', 'Unidata CDF-Dateien', '*.nc *.c'),
	('application/x-nschat', 'NS Chat-Dateien', '*.nsc'),
	('application/x-sh', 'Bourne Shellscript-Dateien', '*.sh'),
	('application/x-shar', 'Shell-Archivdateien', '*.shar'),
	('application/x-shockwave-flash', 'Flash Shockwave-Dateien', '*.swf *.'),
	('application/x-sprite', 'Sprite-Dateien', '*.spr *.'),
	('application/x-stuffit', 'Stuffit-Dateien', '*.sit'),
	('application/x-supercard', 'Supercard-Dateien', '*.sca'),
	('application/x-sv4cpio', 'CPIO-Dateien', '*.sv4cpi'),
	('application/x-sv4crc', 'CPIO-Dateien mit CRC', '*.sv4crc'),
	('application/x-tar', 'tar-Archivdateien', '*.tar'),
	('application/x-tcl', 'TCL Scriptdateien', '*.tcl'),
	('application/x-tex', 'TeX-Dateien', '*.tex'),
	('application/x-texinfo', 'Texinfo-Dateien', '*.texinf'),
	('application/x-troff', 'TROFF-Dateien (Unix)', '*.t *.tr'),
	('application/x-troff-man', 'TROFF-Dateien mit MAN-Makros (Unix)', '*.man *.'),
	('application/x-troff-me', 'TROFF-Dateien mit ME-Makros (Unix)', '*.me *.t'),
	('application/x-troff-ms', 'TROFF-Dateien mit MS-Makros (Unix)', '*.me *.t'),
	('application/x-ustar', 'tar-Archivdateien (Posix)', '*.ustar'),
	('application/x-wais-source', 'WAIS Quelldateien', '*.src'),
	('application/x-www-form-urlencode', 'HTML-Formulardaten an CGI', NULL),
	('application/xhtml+xml', 'XHTML-Dateien', '*.htm *.'),
	('application/xml', 'XML-Dateien', '*.xml'),
	('application/zip', 'ZIP-Archivdateien', '*.zip'),
	('audio/basic', 'Sound-Dateien', '*.au *.s'),
	('audio/echospeech', 'Echospeed-Dateien', '*.es'),
	('audio/tsplayer', 'TS-Player-Dateien', '*.tsi'),
	('audio/voxware', 'Vox-Dateien', '*.vox'),
	('audio/x-aiff', 'AIFF-Sound-Dateien', '*.aif *.'),
	('audio/x-dspeeh', 'Sprachdateien', '*.dus *.'),
	('audio/x-midi', 'MIDI-Dateien', '*.mid *.'),
	('audio/x-mpeg', 'MPEG-Dateien', '*.mp2'),
	('audio/x-pn-realaudio', 'RealAudio-Dateien', '*.ram *.'),
	('audio/x-pn-realaudio-plugin', 'RealAudio-Plugin-Dateien', '*.rpm'),
	('audio/x-qt-stream', 'Quicktime-Streaming-Dateien', '*.stream'),
	('audio/x-wav', 'WAV-Dateien', '*.wav'),
	('drawing/x-dwf', 'Drawing-Dateien', '*.dwf'),
	('image/cis-cod', 'CIS-Cod-Dateien', '*.cod'),
	('image/cmu-raster', 'CMU-Raster-Dateien', '*.ras'),
	('image/fif', 'FIF-Dateien', '*.fif'),
	('image/gif', 'GIF-Dateien', '*.gif'),
	('image/ief', 'IEF-Dateien', '*.ief'),
	('image/jpeg', 'JPEG-Dateien', '*.jpeg *'),
	('image/png', 'PNG-Dateien', '*.png'),
	('image/tiff', 'TIFF-Dateien', '*.tiff *'),
	('image/vasa', 'Vasa-Dateien', '*.mcf'),
	('image/vnd.wap.wbmp', 'Bitmap-Dateien (WAP)', '*.wbmp'),
	('image/x-freehand', 'Freehand-Dateien', '*.fh4 *.'),
	('image/x-portable-anymap', 'PBM Anymap Dateien', '*.pnm'),
	('image/x-portable-bitmap', 'PBM Bitmap Dateien', '*.pbm'),
	('image/x-portable-graymap', 'PBM Graymap Dateien', '*.pgm'),
	('image/x-portable-pixmap', 'PBM Pixmap Dateien', '*.ppm'),
	('image/x-rgb', 'RGB-Dateien', '*.rgb'),
	('image/x-windowdump', 'X-Windows Dump', '*.xwd'),
	('image/x-xbitmap', 'XBM-Dateien', '*.xbm'),
	('image/x-xpixmap', 'XPM-Dateien', '*.xpm'),
	('message/external-body', 'Nachricht mit externem Inhalt', NULL),
	('message/http', 'HTTP-Headernachricht', NULL),
	('message/news', 'Newsgroup-Nachricht', NULL),
	('message/partial', 'Nachricht mit Teilinhalt', NULL),
	('message/rfc822', 'Nachricht nach RFC 2822', NULL),
	('model/vrml', 'Visualisierung virtueller Welten (VRML)', '*.wrl'),
	('multipart/alternative', 'mehrteilige Daten gemischt', NULL),
	('multipart/byteranges', 'mehrteilige Daten mit Byte-Angaben', NULL),
	('multipart/digest', 'mehrteilige Daten / Auswahl', NULL),
	('multipart/encrypted', 'mehrteilige Daten verschlüsselt', NULL),
	('multipart/form-data', 'mehrteilige Daten aus HTML-Formular (z.B. File-Upload)', NULL),
	('multipart/mixed', 'mehrteilige Daten gemischt', NULL),
	('multipart/parallel', 'mehrteilige Daten parallel', NULL),
	('multipart/related', 'mehrteilige Daten / verbunden', NULL),
	('multipart/report', 'mehrteilige Daten / Bericht', NULL),
	('multipart/signed', 'mehrteilige Daten / bezeichnet', NULL),
	('multipart/voice-message', 'mehrteilige Daten / Sprachnachricht', NULL),
	('text/comma-separated-values', 'kommaseparierte Datendateien', '*.csv'),
	('text/css', 'CSS Stylesheet-Dateien', '*.css'),
	('text/html', 'HTML-Dateien', '*.htm *.'),
	('text/javascript', 'JavaScript-Dateien', '*.js'),
	('text/plain', 'reine Textdateien', '*.txt'),
	('text/richtext', 'Richtext-Dateien', '*.rtx'),
	('text/rtf', 'Microsoft RTF-Dateien', '*.rtf'),
	('text/tab-separated-values', 'tabulator-separierte Datendateien', '*.tsv'),
	('text/vnd.wap.wml', 'WML-Dateien (WAP)', '*.wml'),
	('text/vnd.wap.wmlscript', 'WML-Scriptdateien (WAP)', '*.wmls'),
	('text/x-setext', 'SeText-Dateien', '*.etx'),
	('text/x-sgml', 'SGML-Dateien', '*.sgm *.'),
	('text/x-speech', 'Speech-Dateien', '*.talk *'),
	('text/xml', 'XML-Dateien', '*.xml'),
	('text/xml-external-parsed-entity', 'extern geparste XML-Dateien', NULL),
	('video/mpeg', 'MPEG-Dateien', '*.mpeg *'),
	('video/quicktime', 'Quicktime-Dateien', '*.qt *.m'),
	('video/vnd.vivo', 'Vivo-Dateien', '*.viv *.'),
	('video/x-msvideo', 'Microsoft AVI-Dateien', '*.avi'),
	('video/x-sgi-movie', 'Movie-Dateien', '*.movie'),
	('workbook/formulaone', 'FormulaOne-Dateien', '*.vts *.'),
	('x-world/x-3dmf', '3DMF-Dateien', '*.3dmf *'),
	('x-world/x-vrml', 'Visualisierung virtueller Welten (VRML) (veralteter MIME-Typ, aktuell ist model/vrml)', '*.wrl');
/*!40000 ALTER TABLE `mimetype` ENABLE KEYS */;


# Dumping structure for table ebus.multimediadocument_product
CREATE TABLE IF NOT EXISTS `multimediadocument_product` (
  `id` int(11) NOT NULL DEFAULT '0',
  `product` int(11) NOT NULL,
  `mimetype` char(32) NOT NULL,
  `url_or_relativefilepath` varchar(512) NOT NULL,
  `isuri` int(11) DEFAULT NULL,
  `purpose` char(32) NOT NULL,
  `description` varchar(256) DEFAULT NULL,
  `remark` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mmdocprod_product_fk` (`product`),
  CONSTRAINT `mmdocprod_product_fk` FOREIGN KEY (`product`) REFERENCES `product` (`materialnumber`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.multimediadocument_product: ~0 rows (approximately)
/*!40000 ALTER TABLE `multimediadocument_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `multimediadocument_product` ENABLE KEYS */;


# Dumping structure for table ebus.orderinfo_customer
CREATE TABLE IF NOT EXISTS `orderinfo_customer` (
  `product` int(11) NOT NULL DEFAULT '0',
  `orderunit` char(16) NOT NULL,
  `contentunit` char(16) NOT NULL,
  `no_cu_per_ou` int(11) DEFAULT '1',
  `minorderquantity` int(11) DEFAULT '1',
  `maxorderquantity` int(11) DEFAULT NULL,
  `orderquantityinterval` int(11) DEFAULT '1',
  `deliverydays` int(11) DEFAULT NULL,
  `specialtreatment` varchar(256) DEFAULT NULL,
  `internationalrestrictions` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`product`),
  CONSTRAINT `orderinfcust_product_fk` FOREIGN KEY (`product`) REFERENCES `product` (`materialnumber`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.orderinfo_customer: ~0 rows (approximately)
/*!40000 ALTER TABLE `orderinfo_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `orderinfo_customer` ENABLE KEYS */;


# Dumping structure for table ebus.orderinfo_supplier
CREATE TABLE IF NOT EXISTS `orderinfo_supplier` (
  `product` int(11) NOT NULL DEFAULT '0',
  `orderunit` char(16) NOT NULL,
  `contentunit` char(16) NOT NULL,
  `no_cu_per_ou` int(11) DEFAULT '1',
  `minorderquantity` int(11) DEFAULT '1',
  `maxorderquantity` int(11) DEFAULT NULL,
  `orderquantityinterval` int(11) DEFAULT '1',
  `deliverydays` int(11) DEFAULT NULL,
  `specialtreatment` varchar(256) DEFAULT NULL,
  `specialtreatmentclasstype` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`product`),
  CONSTRAINT `orderinfsupp_product_fk` FOREIGN KEY (`product`) REFERENCES `product` (`materialnumber`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.orderinfo_supplier: ~0 rows (approximately)
/*!40000 ALTER TABLE `orderinfo_supplier` DISABLE KEYS */;
/*!40000 ALTER TABLE `orderinfo_supplier` ENABLE KEYS */;


# Dumping structure for table ebus.orderitem_customer
CREATE TABLE IF NOT EXISTS `orderitem_customer` (
  `orderref` char(40) NOT NULL DEFAULT '',
  `itemnumber` int(11) NOT NULL DEFAULT '0',
  `ordernumber_customer` char(40) NOT NULL,
  `productdescription` varchar(256) DEFAULT NULL,
  `orderamount` int(11) NOT NULL,
  `orderunit` char(16) NOT NULL,
  `contentunit` char(16) DEFAULT NULL,
  `no_cu_per_ou` int(11) DEFAULT '1',
  `unitprice` decimal(10,2) DEFAULT NULL,
  `itemprice` decimal(10,2) DEFAULT NULL,
  `pricetype` char(16) DEFAULT NULL,
  `pricequantity` int(11) DEFAULT NULL,
  `taxrate` decimal(4,4) DEFAULT NULL,
  `taxamount` decimal(10,2) DEFAULT NULL,
  `deliveryaddress` char(40) DEFAULT NULL,
  `partialshipment` int(11) DEFAULT NULL,
  `transport` varchar(256) DEFAULT NULL,
  `specialtreatment` varchar(256) DEFAULT NULL,
  `internationalrestrictions` varchar(256) DEFAULT NULL,
  `remark` varchar(256) DEFAULT NULL,
  `ordertype` char(16) DEFAULT NULL,
  `is_rejected` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`orderref`,`itemnumber`),
  KEY `orditemcust_deladdr_fk` (`deliveryaddress`),
  CONSTRAINT `orditemcust_deladdr_fk` FOREIGN KEY (`deliveryaddress`) REFERENCES `address` (`id`),
  CONSTRAINT `orditemcust_ordercust_fk` FOREIGN KEY (`orderref`) REFERENCES `order_customer` (`orderid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.orderitem_customer: ~1 rows (approximately)
/*!40000 ALTER TABLE `orderitem_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `orderitem_customer` ENABLE KEYS */;


# Dumping structure for table ebus.orderitem_purchase
CREATE TABLE IF NOT EXISTS `orderitem_purchase` (
  `orderref` char(40) NOT NULL DEFAULT '',
  `itemnumber` int(11) NOT NULL DEFAULT '0',
  `ordernumber_supplier` char(40) NOT NULL,
  `productdescription` varchar(256) DEFAULT NULL,
  `orderamount` int(11) NOT NULL,
  `orderunit` char(16) NOT NULL,
  `contentunit` char(16) DEFAULT NULL,
  `no_cu_per_ou` int(11) DEFAULT '1',
  `unitprice` decimal(10,2) DEFAULT NULL,
  `itemprice` decimal(10,2) DEFAULT NULL,
  `pricetype` char(16) DEFAULT NULL,
  `pricequantity` int(11) DEFAULT NULL,
  `taxrate` decimal(4,4) DEFAULT NULL,
  `taxamount` decimal(10,2) DEFAULT NULL,
  `deliveryaddress` char(40) DEFAULT NULL,
  `partialshipment` int(11) DEFAULT NULL,
  `transport` varchar(256) DEFAULT NULL,
  `specialtreatment` varchar(256) DEFAULT NULL,
  `internationalrestrictions` varchar(256) DEFAULT NULL,
  `remark` varchar(256) DEFAULT NULL,
  `ordertype` char(16) DEFAULT NULL,
  `is_rejected` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`orderref`,`itemnumber`),
  KEY `orderitempurc_deladdr_fk` (`deliveryaddress`),
  CONSTRAINT `orderitempurc_deladdr_fk` FOREIGN KEY (`deliveryaddress`) REFERENCES `address` (`id`),
  CONSTRAINT `orderitempurc_orderpurc_fk` FOREIGN KEY (`orderref`) REFERENCES `order_purchase` (`orderid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.orderitem_purchase: ~1 rows (approximately)
/*!40000 ALTER TABLE `orderitem_purchase` DISABLE KEYS */;
/*!40000 ALTER TABLE `orderitem_purchase` ENABLE KEYS */;


# Dumping structure for table ebus.ordertype
CREATE TABLE IF NOT EXISTS `ordertype` (
  `code` char(16) NOT NULL DEFAULT '',
  `description` varchar(256) NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.ordertype: ~4 rows (approximately)
/*!40000 ALTER TABLE `ordertype` DISABLE KEYS */;
INSERT INTO `ordertype` (`code`, `description`) VALUES
	('consignment', 'Spezifiziert die Entnahme eines Artikels aus einem Konsignationslager (Lieferantenlager beim Kunden)'),
	('express', 'Es wird eine Expresslieferung für diesen Auftrag angefordert.'),
	('release', 'Der Auftrag ist ein Abruf aus einer Rahmenvereinbarung. Die Rahmenvereinbarung wird unter AGREEMENT'),
	('standard', 'Es wird eine Standardlieferung für diesen Auftrag angefordert.');
/*!40000 ALTER TABLE `ordertype` ENABLE KEYS */;


# Dumping structure for table ebus.orderunit
CREATE TABLE IF NOT EXISTS `orderunit` (
  `code` char(8) NOT NULL DEFAULT '',
  `description` varchar(256) NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.orderunit: ~1.029 rows (approximately)
/*!40000 ALTER TABLE `orderunit` DISABLE KEYS */;
INSERT INTO `orderunit` (`code`, `description`) VALUES
	('05', 'lift'),
	('06', 'small spray'),
	('08', 'heat lot'),
	('10', 'group'),
	('11', 'outfit'),
	('13', 'ration'),
	('14', 'shot'),
	('15', 'stick, military'),
	('16', 'hundred fifteen kg drum'),
	('17', 'hundred lb drum'),
	('18', 'fiftyfive gallon (US) drum'),
	('19', 'tank truck'),
	('1A', 'car mile'),
	('1B', 'car count'),
	('1C', 'locomotive count'),
	('1D', 'caboose count'),
	('1E', 'empty car'),
	('1F', 'train mile'),
	('1G', 'fuel usage gallon (US)'),
	('1H', 'caboose mile'),
	('1I', 'fixed rate'),
	('1J', 'ton mile'),
	('1K', 'locomotive mile'),
	('1L', 'total car count'),
	('1M', 'total car mile'),
	('1X', 'quarter mile'),
	('20', 'twenty foot container'),
	('21', 'forty foot container'),
	('22', 'decilitre per gram'),
	('23', 'gram per cubic centimetre'),
	('24', 'theoretical pound'),
	('25', 'gram per square centimetre'),
	('26', 'actual ton'),
	('27', 'theoretical ton'),
	('28', 'kilogram per square metre'),
	('29', 'pound per thousand square feet'),
	('2A', 'radian per second'),
	('2B', 'radian per second squared'),
	('2C', 'roentgen'),
	('2I', 'British thermal unit per hour'),
	('2J', 'cubic centimetre per second'),
	('2K', 'cubic foot per hour'),
	('2L', 'cubic foot per minute'),
	('2M', 'centimetre per second'),
	('2N', 'decibel'),
	('2P', 'kilobyte'),
	('2Q', 'kilobecquerel'),
	('2R', 'kilocurie'),
	('2U', 'megagram'),
	('2V', 'megagram per hour'),
	('2W', 'bin'),
	('2X', 'metre per minute'),
	('2Y', 'milliroentgen'),
	('2Z', 'millivolt'),
	('30', 'horse power day per air dry metric ton'),
	('31', 'catch weight'),
	('32', 'kilogram per air dry metric ton'),
	('33', 'kilopascal square metres per gram'),
	('34', 'kilopascals per millimetre'),
	('35', 'millilitres per square centimetre second'),
	('36', 'cubic feet per minute per square foot'),
	('37', 'ounce per square foot'),
	('38', 'ounces per square foot per 0,01inch'),
	('3B', 'megajoule'),
	('3C', 'manmonth'),
	('3E', 'pound per pound of product'),
	('3G', 'pound per piece of product'),
	('3H', 'kilogram per kilogram of product'),
	('3I', 'kilogram per piece of product'),
	('40', 'millilitre per second'),
	('41', 'millilitre per minute'),
	('43', 'super bulk bag'),
	('44', 'fivehundred kg bulk bag'),
	('45', 'threehundred kg bulk bag'),
	('46', 'fifty lb bulk bag'),
	('47', 'fifty lb bag'),
	('48', 'bulk car load'),
	('4A', 'bobbin'),
	('4B', 'cap'),
	('4C', 'centistokes'),
	('4E', 'twenty pack'),
	('4G', 'microlitre'),
	('4H', 'micrometre (micron)'),
	('4K', 'milliampere'),
	('4L', 'megabyte'),
	('4M', 'milligram per hour'),
	('4N', 'megabecquerel'),
	('4O', 'microfarad'),
	('4P', 'newton per metre'),
	('4Q', 'ounce inch'),
	('4R', 'ounce foot'),
	('4T', 'picofarad'),
	('4U', 'pound per hour'),
	('4W', 'ton (US) per hour'),
	('4X', 'kilolitre per hour'),
	('53', 'theoretical kilograms'),
	('54', 'theoretical tonne'),
	('56', 'sitas'),
	('57', 'mesh'),
	('58', 'net kilogram'),
	('59', 'part per million'),
	('5A', 'barrel (US) per minute'),
	('5B', 'batch'),
	('5C', 'gallon(US) per thousand'),
	('5E', 'MMSCF/day'),
	('5F', 'pounds per thousand'),
	('5G', 'pump'),
	('5H', 'stage'),
	('5I', 'standard cubic foot'),
	('5J', 'hydraulic horse power'),
	('5K', 'count per minute'),
	('5P', 'seismic level'),
	('5Q', 'seismic line'),
	('60', 'percent weight'),
	('61', 'part per billion (US)'),
	('62', 'percent per 1000 hour'),
	('63', 'failure rate in time'),
	('64', 'pound per square inch, gauge'),
	('66', 'oersted'),
	('69', 'test specific scale'),
	('71', 'volt ampere per pound'),
	('72', 'watt per pound'),
	('73', 'ampere tum per centimetre'),
	('74', 'millipascal'),
	('76', 'gauss'),
	('77', 'milli-inch'),
	('78', 'kilogauss'),
	('80', 'pounds per square inch absolute'),
	('81', 'henry'),
	('84', 'kilopound per square inch'),
	('85', 'foot pound-force'),
	('87', 'pound per cubic foot'),
	('89', 'poise'),
	('90', 'Saybold universal second'),
	('91', 'stokes'),
	('92', 'calorie per cubic centimetre'),
	('93', 'calorie per gram'),
	('94', 'curl unit'),
	('95', 'twenty thousand gallon (US) tankcar'),
	('96', 'ten thousand gallon (US) tankcar'),
	('97', 'ten kg drum'),
	('98', 'fifteen kg drum'),
	('A1', '15 °C calorie'),
	('A10', 'ampere square metre per joule second'),
	('A11', 'angstrom'),
	('A12', 'astronomical unit'),
	('A13', 'attojoule'),
	('A14', 'barn'),
	('A15', 'barn per electron volt'),
	('A16', 'barn per steradian electronvolt'),
	('A17', 'barn per steradian'),
	('A18', 'becquerel per kilogram'),
	('A19', 'becquerel per metre cubed'),
	('A2', 'ampere per centimetre'),
	('A20', 'British thermal unit per second square foot degree Rankin'),
	('A21', 'British thermal unit per pound degree Rankin'),
	('A22', 'British thermal unit per second foot degree Rankin'),
	('A23', 'British thermal unit per hour square foot degree Rankin'),
	('A24', 'candela per square metre'),
	('A25', 'cheval vapeur'),
	('A26', 'coulomb metre'),
	('A27', 'coulomb metre squared per volt'),
	('A28', 'coulomb per cubic centimetre'),
	('A29', 'coulomb per cubic metre'),
	('A3', 'ampere per millimetre'),
	('A30', 'coulomb per cubic millimetre'),
	('A31', 'coulomb per kilogram second'),
	('A32', 'coulomb per mole'),
	('A33', 'coulomb per square centimetre'),
	('A34', 'coulomb per square metre'),
	('A35', 'coulomb per square millimetre'),
	('A36', 'cubic centimetre per mole'),
	('A37', 'cubic decimetre per mole'),
	('A38', 'cubic metre per coulomb'),
	('A39', 'cubic metre per kilogram'),
	('A4', 'ampere per square centimetre'),
	('A40', 'cubic metre per mole'),
	('A41', 'ampere per square metre'),
	('A42', 'curie per kilogram'),
	('A43', 'deadweight tonnage'),
	('A44', 'decalitre'),
	('A45', 'decametre'),
	('A47', 'decitex'),
	('A48', 'degree Rankin'),
	('A49', 'denier'),
	('A5', 'ampere square metre'),
	('A50', 'dyne second per cubic centimetre'),
	('A51', 'dyne second per centimetre'),
	('A52', 'dyne second per centimetre to the fifth power'),
	('A53', 'electronvolt'),
	('A54', 'electronvolt per metre'),
	('A55', 'electronvolt square metre'),
	('A56', 'electronvolt square metre per kilogram'),
	('A57', 'erg'),
	('A58', 'erg per centimetre'),
	('A59', '8-part cloud cover'),
	('A6', 'ampere per square metre kelvin squared'),
	('A60', 'erg per cubic centimetre'),
	('A61', 'erg per gram'),
	('A62', 'erg per gram second'),
	('A63', 'erg per second'),
	('A64', 'erg per second square centimetre'),
	('A65', 'erg per square centimetre second'),
	('A66', 'erg square centimetre'),
	('A67', 'erg square centimetre per gram'),
	('A68', 'exajoule'),
	('A69', 'farad per metre'),
	('A7', 'ampere per square millimetre'),
	('A70', 'femtojoule'),
	('A71', 'femtometre'),
	('A73', 'foot per second squared'),
	('A74', 'foot pound-force per second'),
	('A75', 'freight ton'),
	('A76', 'gal'),
	('A77', 'Gaussian CGS unit of displacement'),
	('A78', 'Gaussian CGS unit of electic current'),
	('A79', 'Gaussian CGS unit of electric charge'),
	('A8', 'ampere second'),
	('A80', 'Gaussian CGS unit of electric field strength'),
	('A81', 'Gaussian CGS unit of electric polarization'),
	('A82', 'Gaussian CGS unit of electric potential'),
	('A83', 'Gaussian CGS unit of magnetization'),
	('A84', 'gigacoulomb per cubic metre'),
	('A85', 'gigaelectronvolt'),
	('A86', 'gigahertz'),
	('A87', 'gigaohm'),
	('A88', 'gigaohm metre'),
	('A89', 'gigapascal'),
	('A9', 'rate'),
	('A90', 'gigawatt'),
	('A91', 'gon'),
	('A93', 'gram per cubic metre'),
	('A94', 'gram per mole'),
	('A95', 'gray'),
	('A96', 'gray per second'),
	('A97', 'hectopascal'),
	('A98', 'henry per metre'),
	('A99', 'bit'),
	('AA', 'ball'),
	('AB', 'bulk pack'),
	('ACR', 'acre'),
	('ACT', 'activity'),
	('AD', 'byte'),
	('AE', 'ampere per metre'),
	('AH', 'additional minute'),
	('AI', 'average minute per call'),
	('AJ', 'cop'),
	('AK', 'fathom'),
	('AL', 'access line'),
	('AM', 'ampoule'),
	('AMH', 'ampere hour'),
	('AMP', 'ampere'),
	('ANN', 'year'),
	('AP', 'aluminium pound only'),
	('APZ', 'troy ounce or apothecary ounce'),
	('AQ', 'anti-hemophilic factor (AHF) unit'),
	('AR', 'suppository'),
	('ARE', 'are'),
	('AS', 'assortment'),
	('ASM', 'alcoholic strength by mass'),
	('ASU', 'alcoholic strength by volume'),
	('ATM', 'standard atmosphere'),
	('ATT', 'technical atmosphere'),
	('AV', 'capsule'),
	('AW', 'powder filled vial'),
	('AY', 'assembly'),
	('AZ', 'British thermal unit per pound'),
	('B0', 'Btu per cubic foot'),
	('B1', 'barrel (US) per day'),
	('B10', 'bit per second'),
	('B11', 'joule per kilogram kelvin'),
	('B12', 'joule per metre'),
	('B13', 'joule per square metre'),
	('B14', 'joule per metre to the fourth power'),
	('B15', 'joule per mole'),
	('B16', 'joule per mole kelvin'),
	('B17', 'credit'),
	('B18', 'joule second'),
	('B19', 'digit'),
	('B2', 'bunk'),
	('B20', 'joule square metre per kilogram'),
	('B21', 'kelvin per watt'),
	('B22', 'kiloampere'),
	('B23', 'kiloampere per square metre'),
	('B24', 'kiloampere per metre'),
	('B25', 'kilobecquerel per kilogram'),
	('B26', 'kilocoulomb'),
	('B27', 'kilocoulomb per cubic metre'),
	('B28', 'kilocoulomb per square metre'),
	('B29', 'kiloelectronvolt'),
	('B3', 'batting pound'),
	('B30', 'gibibit'),
	('B31', 'kilogram metre per second'),
	('B32', 'kilogram metre squared'),
	('B33', 'kilogram metre squared per second'),
	('B34', 'kilogram per cubic decimetre'),
	('B35', 'kilogram per litre'),
	('B36', 'thermochemical calorie per gram'),
	('B37', 'kilogram-force'),
	('B38', 'kilogram-force metre'),
	('B39', 'kilogram-force metre per second'),
	('B4', 'barrel, imperial'),
	('B40', 'kilogram-force per square metre'),
	('B41', 'kilojoule per kelvin'),
	('B42', 'kilojoule per kilogram'),
	('B43', 'kilojoule per kilogram kelvin'),
	('B44', 'kilojoule per mole'),
	('B45', 'kilomole'),
	('B46', 'kilomole per cubic metre'),
	('B47', 'kilonewton'),
	('B48', 'kilonewton metre'),
	('B49', 'kiloohm'),
	('B5', 'billet'),
	('B50', 'kiloohm metre'),
	('B51', 'kilopond'),
	('B52', 'kilosecond'),
	('B53', 'kilosiemens'),
	('B54', 'kilosiemens per metre'),
	('B55', 'kilovolt per metre'),
	('B56', 'kiloweber per metre'),
	('B57', 'light year'),
	('B58', 'litre per mole'),
	('B59', 'lumen hour'),
	('B6', 'bun'),
	('B60', 'lumen per square metre'),
	('B61', 'lumen per watt'),
	('B62', 'lumen second'),
	('B63', 'lux hour'),
	('B64', 'lux second'),
	('B65', 'maxwell'),
	('B66', 'megaampere per square metre'),
	('B67', 'megabecquerel per kilogram'),
	('B68', 'gigabit'),
	('B69', 'megacoulomb per cubic metre'),
	('B7', 'cycle'),
	('B70', 'megacoulomb per square metre'),
	('B71', 'megaelectronvolt'),
	('B72', 'megagram per cubic metre'),
	('B73', 'meganewton'),
	('B74', 'meganewton metre'),
	('B75', 'megaohm'),
	('B76', 'megaohm metre'),
	('B77', 'megasiemens per metre'),
	('B78', 'megavolt'),
	('B79', 'megavolt per metre'),
	('B8', 'joule per cubic metre'),
	('B80', 'gigabit per second'),
	('B81', 'reciprocal metre squared reciprocal second'),
	('B82', 'inch per linear foot'),
	('B83', 'metre to the fourth power'),
	('B84', 'microampere'),
	('B85', 'microbar'),
	('B86', 'microcoulomb'),
	('B87', 'microcoulomb per cubic metre'),
	('B88', 'microcoulomb per square metre'),
	('B89', 'microfarad per metre'),
	('B9', 'batt'),
	('B90', 'microhenry'),
	('B91', 'microhenry per metre'),
	('B92', 'micronewton'),
	('B93', 'micronewton metre'),
	('B94', 'microohm'),
	('B95', 'microohm metre'),
	('B96', 'micropascal'),
	('B97', 'microradian'),
	('B98', 'microsecond'),
	('B99', 'microsiemens'),
	('BAR', 'bar [unit of pressure]'),
	('BB', 'base box'),
	('BD', 'board'),
	('BE', 'bundle'),
	('BFT', 'board foot'),
	('BG', 'bag'),
	('BH', 'brush'),
	('BHP', 'brake horse power'),
	('BIL', 'billion (EUR)'),
	('BJ', 'bucket'),
	('BK', 'basket'),
	('BL', 'bale'),
	('BLD', 'dry barrel (US)'),
	('BLL', 'barrel (US)'),
	('BO', 'bottle'),
	('BP', 'hundred board feet'),
	('BQL', 'becquerel'),
	('BR', 'bar [unit of packaging]'),
	('BT', 'bolt'),
	('BTU', 'British thermal unit'),
	('BUA', 'bushel (US)'),
	('BUI', 'bushel (UK)'),
	('BW', 'base weight'),
	('BX', 'box'),
	('BZ', 'million BTUs'),
	('C0', 'call'),
	('C1', 'composite product pound (total weight)'),
	('C10', 'millifarad'),
	('C11', 'milligal'),
	('C12', 'milligram per metre'),
	('C13', 'milligray'),
	('C14', 'millihenry'),
	('C15', 'millijoule'),
	('C16', 'millimetre per second'),
	('C17', 'millimetre squared per second'),
	('C18', 'millimole'),
	('C19', 'mole per kilogram'),
	('C2', 'carset'),
	('C20', 'millinewton'),
	('C21', 'kibibit'),
	('C22', 'millinewton per metre'),
	('C23', 'milliohm metre'),
	('C24', 'millipascal second'),
	('C25', 'milliradian'),
	('C26', 'millisecond'),
	('C27', 'millisiemens'),
	('C28', 'millisievert'),
	('C29', 'millitesla'),
	('C3', 'microvolt per metre'),
	('C30', 'millivolt per metre'),
	('C31', 'milliwatt'),
	('C32', 'milliwatt per square metre'),
	('C33', 'milliweber'),
	('C34', 'mole'),
	('C35', 'mole per cubic decimetre'),
	('C36', 'mole per cubic metre'),
	('C37', 'kilobit'),
	('C38', 'mole per litre'),
	('C39', 'nanoampere'),
	('C4', 'carload'),
	('C40', 'nanocoulomb'),
	('C41', 'nanofarad'),
	('C42', 'nanofarad per metre'),
	('C43', 'nanohenry'),
	('C44', 'nanohenry per metre'),
	('C45', 'nanometre'),
	('C46', 'nanoohm metre'),
	('C47', 'nanosecond'),
	('C48', 'nanotesla'),
	('C49', 'nanowatt'),
	('C5', 'cost'),
	('C50', 'neper'),
	('C51', 'neper per second'),
	('C52', 'picometre'),
	('C53', 'newton metre second'),
	('C54', 'newton metre squared kilogram squared'),
	('C55', 'newton per square metre'),
	('C56', 'newton per square millimetre'),
	('C57', 'newton second'),
	('C58', 'newton second per metre'),
	('C59', 'octave'),
	('C6', 'cell'),
	('C60', 'ohm centimetre'),
	('C61', 'ohm metre'),
	('C62', 'one'),
	('C63', 'parsec'),
	('C64', 'pascal per kelvin'),
	('C65', 'pascal second'),
	('C66', 'pascal second per cubic metre'),
	('C67', 'pascal second per metre'),
	('C68', 'petajoule'),
	('C69', 'phon'),
	('C7', 'centipoise'),
	('C70', 'picoampere'),
	('C71', 'picocoulomb'),
	('C72', 'picofarad per metre'),
	('C73', 'picohenry'),
	('C74', 'kilobit per second'),
	('C75', 'picowatt'),
	('C76', 'picowatt per square metre'),
	('C77', 'pound gage'),
	('C78', 'pound-force'),
	('C79', 'kilovolt ampere hour'),
	('C8', 'millicoulomb per kilogram'),
	('C80', 'rad'),
	('C81', 'radian'),
	('C82', 'radian square metre per mole'),
	('C83', 'radian square metre per kilogram'),
	('C84', 'radian per metre'),
	('C85', 'reciprocal angstrom'),
	('C86', 'reciprocal cubic metre'),
	('C87', 'reciprocal cubic metre per second'),
	('C88', 'reciprocal electron volt per cubic metre'),
	('C89', 'reciprocal henry'),
	('C9', 'coil group'),
	('C90', 'reciprocal joule per cubic metre'),
	('C91', 'reciprocal kelvin or kelvin to the power minus one'),
	('C92', 'reciprocal metre'),
	('C93', 'reciprocal square metre'),
	('C94', 'reciprocal minute'),
	('C95', 'reciprocal mole'),
	('C96', 'reciprocal pascal or pascal to the power minus one'),
	('C97', 'reciprocal second'),
	('C98', 'reciprocal second per cubic metre'),
	('C99', 'reciprocal second per metre squared'),
	('CA', 'can'),
	('CCT', 'carrying capacity in metric ton'),
	('CDL', 'candela'),
	('CEL', 'degree Celsius'),
	('CEN', 'hundred'),
	('CG', 'card'),
	('CGM', 'centigram'),
	('CH', 'container'),
	('CJ', 'cone'),
	('CK', 'connector'),
	('CKG', 'coulomb per kilogram'),
	('CL', 'coil'),
	('CLF', 'hundred leave'),
	('CLT', 'centilitre'),
	('CMK', 'square centimetre'),
	('CMQ', 'cubic centimetre'),
	('CMT', 'centimetre'),
	('CNP', 'hundred pack'),
	('CNT', 'cental (UK)'),
	('CO', 'carboy'),
	('COU', 'coulomb'),
	('CQ', 'cartridge'),
	('CR', 'crate'),
	('CS', 'case'),
	('CT', 'carton'),
	('CTG', 'content gram'),
	('CTM', 'metric carat'),
	('CTN', 'content ton (metric)'),
	('CU', 'cup'),
	('CUR', 'curie'),
	('CV', 'cover'),
	('CWA', 'hundred pounds (cwt) / hundred weight (US)'),
	('CWI', 'hundred weight (UK)'),
	('CY', 'cylinder'),
	('CZ', 'combo'),
	('D03', 'kilowatt hour per hour'),
	('D04', 'lot  [unit of weight]'),
	('D1', 'reciprocal second per steradian'),
	('D10', 'siemens per metre'),
	('D11', 'mebibit'),
	('D12', 'siemens square metre per mole'),
	('D13', 'sievert'),
	('D14', 'thousand linear yard'),
	('D15', 'sone'),
	('D16', 'square centimetre per erg'),
	('D17', 'square centimetre per steradian erg'),
	('D18', 'metre kelvin'),
	('D19', 'square metre kelvin per watt'),
	('D2', 'reciprocal second per steradian metre squared'),
	('D20', 'square metre per joule'),
	('D21', 'square metre per kilogram'),
	('D22', 'square metre per mole'),
	('D23', 'pen gram (protein)'),
	('D24', 'square metre per steradian'),
	('D25', 'square metre per steradian joule'),
	('D26', 'square metre per volt second'),
	('D27', 'steradian'),
	('D28', 'syphon'),
	('D29', 'terahertz'),
	('D30', 'terajoule'),
	('D31', 'terawatt'),
	('D32', 'terawatt hour'),
	('D33', 'tesla'),
	('D34', 'tex'),
	('D35', 'thermochemical calorie'),
	('D36', 'megabit'),
	('D37', 'thermochemical calorie per gram kelvin'),
	('D38', 'thermochemical calorie per second centimetre kelvin'),
	('D39', 'thermochemical calorie per second square centimetre kelvin'),
	('D40', 'thousand litre'),
	('D41', 'tonne per cubic metre'),
	('D42', 'tropical year'),
	('D43', 'unified atomic mass unit'),
	('D44', 'var'),
	('D45', 'volt squared per kelvin squared'),
	('D46', 'volt - ampere'),
	('D47', 'volt per centimetre'),
	('D48', 'volt per kelvin'),
	('D49', 'millivolt per kelvin'),
	('D5', 'kilogram per square centimetre'),
	('D50', 'volt per metre'),
	('D51', 'volt per millimetre'),
	('D52', 'watt per kelvin'),
	('D53', 'watt per metre kelvin'),
	('D54', 'watt per square metre'),
	('D55', 'watt per square metre kelvin'),
	('D56', 'watt per square metre kelvin to the fourth power'),
	('D57', 'watt per steradian'),
	('D58', 'watt per steradian square metre'),
	('D59', 'weber per metre'),
	('D6', 'roentgen per second'),
	('D60', 'weber per millimetre'),
	('D61', 'minute [unit of angle]'),
	('D62', 'second [unit of angle]'),
	('D63', 'book'),
	('D64', 'block'),
	('D65', 'round'),
	('D66', 'cassette'),
	('D67', 'dollar per hour'),
	('D68', 'number of words'),
	('D69', 'inch to the fourth power'),
	('D7', 'sandwich'),
	('D70', 'International Table (IT) calorie'),
	('D71', 'International Table (IT) calorie per second centimetre kelvin'),
	('D72', 'International Table (IT) calorie per second square centimetre kelvin'),
	('D73', 'joule square metre'),
	('D74', 'kilogram per mole'),
	('D75', 'International Table (IT)calorie per gram'),
	('D76', 'International Table (IT) calorie per gram kelvin'),
	('D77', 'megacoulomb'),
	('D78', 'megajoule per second'),
	('D79', 'beam'),
	('D8', 'draize score'),
	('D80', 'microwatt'),
	('D81', 'microtesla'),
	('D82', 'microvolt'),
	('D83', 'millinewton metre'),
	('D85', 'microwatt per square metre'),
	('D86', 'millicoulomb'),
	('D87', 'millimole per kilogram'),
	('D88', 'millicoulomb per cubic metre'),
	('D89', 'millicoulomb per square metre'),
	('D9', 'dyne per square centimetre'),
	('D90', 'cubic metre (net)'),
	('D91', 'rem'),
	('D92', 'band'),
	('D93', 'second per cubic metre'),
	('D94', 'second per radian cubic metre'),
	('D95', 'joule per gram'),
	('D96', 'pound gross'),
	('D97', 'pallet/unit load'),
	('D98', 'mass pound'),
	('D99', 'sleeve'),
	('DAA', 'decare'),
	('DAD', 'ten day'),
	('DAY', 'day'),
	('DB', 'dry pound'),
	('DC', 'disk (disc)'),
	('DD', 'degree [unit of angle]'),
	('DE', 'deal'),
	('DEC', 'decade'),
	('DG', 'decigram'),
	('DI', 'dispenser'),
	('DJ', 'decagram'),
	('DLT', 'decilitre'),
	('DMK', 'square decimetre'),
	('DMO', 'standard kilolitre'),
	('DMQ', 'cubic decimetre'),
	('DMT', 'decimetre'),
	('DN', 'decinewton metre'),
	('DPC', 'dozen piece'),
	('DPR', 'dozen pair'),
	('DPT', 'displacement tonnage'),
	('DQ', 'data record'),
	('DR', 'drum'),
	('DRA', 'dram (US)'),
	('DRI', 'dram (UK)'),
	('DRL', 'dozen roll'),
	('DRM', 'drachm (UK)'),
	('DS', 'display'),
	('DT', 'dry ton'),
	('DTN', 'decitonne'),
	('DU', 'dyne'),
	('DWT', 'pennyweight'),
	('DX', 'dyne per centimetre'),
	('DY', 'directory book'),
	('DZN', 'dozen'),
	('DZP', 'dozen pack'),
	('E01', 'newton per square centimetre'),
	('E07', 'megawatt hour per hour'),
	('E08', 'megawatt per hertz'),
	('E09', 'milliampere hour'),
	('E10', 'degree days'),
	('E11', 'gigacalorie'),
	('E12', 'mille'),
	('E14', 'kilocalorie (IT)'),
	('E15', 'kilocalorie (TH) per hour'),
	('E16', 'million BTU(IT) per hour'),
	('E17', 'cubic foot per second'),
	('E18', 'tonne per hour'),
	('E19', 'ping'),
	('E2', 'belt'),
	('E20', 'megabit per second'),
	('E21', 'shares'),
	('E22', 'TEU'),
	('E23', 'tyre'),
	('E25', 'active unit'),
	('E27', 'dose'),
	('E28', 'air dry ton'),
	('E3', 'trailer'),
	('E30', 'strand'),
	('E31', 'square metre per litre'),
	('E32', 'litre per hour'),
	('E33', 'foot per thousand'),
	('E34', 'gigabyte'),
	('E35', 'terabyte'),
	('E36', 'petabyte'),
	('E37', 'pixel'),
	('E38', 'megapixel'),
	('E39', 'dots per inch'),
	('E4', 'gross kilogram'),
	('E40', 'part per hundred thousand'),
	('E41', 'kilogram force per square millimetre'),
	('E42', 'kilogram force per square centimetre'),
	('E43', 'joule per square centimetre'),
	('E44', 'kilogram-force metre per square centimetre'),
	('E45', 'milliohm'),
	('E46', 'kilowatt hour per cubic metre'),
	('E47', 'kilowatt hour per kelvin'),
	('E48', 'service unit'),
	('E49', 'working day'),
	('E5', 'metric long ton'),
	('E50', 'accounting unit'),
	('EA', 'each'),
	('EB', 'electronic mail box'),
	('EC', 'each per month'),
	('EP', 'eleven pack'),
	('EQ', 'equivalent gallon'),
	('EV', 'envelope'),
	('F1', 'thousand cubic feet per day'),
	('F9', 'fibre per cubic centimetre of air'),
	('FAH', 'degree Fahrenheit'),
	('FAR', 'farad'),
	('FB', 'field'),
	('FBM', 'fibre metre'),
	('FC', 'thousand cubic feet'),
	('FD', 'million particle per cubic foot'),
	('FE', 'track foot'),
	('FF', 'hundred cubic metre'),
	('FG', 'transdermal patch'),
	('FH', 'micromole'),
	('FL', 'flake ton'),
	('FM', 'million cubic feet'),
	('FOT', 'foot'),
	('FP', 'pound per square foot'),
	('FR', 'foot per minute'),
	('FS', 'foot per second'),
	('FTK', 'square foot'),
	('FTQ', 'cubic foot'),
	('G2', 'US gallon per minute'),
	('G3', 'Imperial gallon per minute'),
	('G7', 'microfiche sheet'),
	('GB', 'gallon (US) per day'),
	('GBQ', 'gigabecquerel'),
	('GC', 'gram per 100 gram'),
	('GD', 'gross barrel'),
	('GDW', 'gram, dry weight'),
	('GE', 'pound per gallon (US)'),
	('GF', 'gram per metre (gram per 100 centimetres)'),
	('GFI', 'gram of fissile isotope'),
	('GGR', 'great gross'),
	('GH', 'half gallon (US)'),
	('GIA', 'gill (US)'),
	('GIC', 'gram, including container'),
	('GII', 'gill (UK)'),
	('GIP', 'gram, including inner packaging'),
	('GJ', 'gram per millilitre'),
	('GK', 'gram per kilogram'),
	('GL', 'gram per litre'),
	('GLD', 'dry gallon (US)'),
	('GLI', 'gallon (UK)'),
	('GLL', 'gallon (US)'),
	('GM', 'gram per square metre'),
	('GN', 'gross gallon'),
	('GO', 'milligrams per square metre'),
	('GP', 'milligram per cubic metre'),
	('GQ', 'microgram per cubic metre'),
	('GRM', 'gram'),
	('GRN', 'grain'),
	('GRO', 'gross'),
	('GRT', 'gross register ton'),
	('GT', 'gross ton'),
	('GV', 'gigajoule'),
	('GW', 'gallon per thousand cubic feet'),
	('GWH', 'gigawatt hour'),
	('GY', 'gross yard'),
	('GZ', 'gage system'),
	('H1', 'half page ¿ electronic'),
	('H2', 'half litre'),
	('HA', 'hank'),
	('HAR', 'hectare'),
	('HBA', 'hectobar'),
	('HBX', 'hundred boxes'),
	('HC', 'hundred count'),
	('HD', 'half dozen'),
	('HDW', 'hundred kilogram, dry weight'),
	('HE', 'hundredth of a carat'),
	('HF', 'hundred feet'),
	('HGM', 'hectogram'),
	('HH', 'hundred cubic feet'),
	('HI', 'hundred sheet'),
	('HIU', 'hundred international unit'),
	('HJ', 'metric horse power'),
	('HK', 'hundred kilogram'),
	('HKM', 'hundred kilogram, net mass'),
	('HL', 'hundred feet (linear)'),
	('HLT', 'hectolitre'),
	('HM', 'mile per hour'),
	('HMQ', 'million cubic metre'),
	('HMT', 'hectometre'),
	('HN', 'conventional millimetre of mercury'),
	('HO', 'hundred troy ounce'),
	('HP', 'conventional millimetre of water'),
	('HPA', 'hectolitre of pure alcohol'),
	('HS', 'hundred square feet'),
	('HT', 'half hour'),
	('HTZ', 'hertz'),
	('HUR', 'hour'),
	('HY', 'hundred yard'),
	('IA', 'inch pound (pound inch)'),
	('IC', 'count per inch'),
	('IE', 'person'),
	('IF', 'inches of water'),
	('II', 'column inch'),
	('IL', 'inch per minute'),
	('IM', 'impression'),
	('INH', 'inch'),
	('INK', 'square inch'),
	('INQ', 'cubic inch'),
	('IP', 'insurance policy'),
	('ISD', 'international sugar degree'),
	('IT', 'count per centimetre'),
	('IU', 'inch per second'),
	('IV', 'inch per second squared'),
	('J2', 'joule per kilogram'),
	('JB', 'jumbo'),
	('JE', 'joule per kelvin'),
	('JG', 'jug'),
	('JK', 'megajoule per kilogram'),
	('JM', 'megajoule per cubic metre'),
	('JO', 'joint'),
	('JOU', 'joule'),
	('JPS', 'hundred metre'),
	('JR', 'jar'),
	('JWL', 'number of jewels'),
	('K1', 'kilowatt demand'),
	('K2', 'kilovolt ampere reactive demand'),
	('K3', 'kilovolt ampere reactive hour'),
	('K5', 'kilovolt ampere (reactive)'),
	('K6', 'kilolitre'),
	('KA', 'cake'),
	('KB', 'kilocharacter'),
	('KBA', 'kilobar'),
	('KCC', 'kilogram of choline chloride'),
	('KD', 'kilogram decimal'),
	('KDW', 'kilogram drained net weight'),
	('KEL', 'kelvin'),
	('KF', 'kilopacket'),
	('KG', 'keg'),
	('KGM', 'kilogram'),
	('KGS', 'kilogram per second'),
	('KHY', 'kilogram of hydrogen peroxide'),
	('KHZ', 'kilohertz'),
	('KI', 'kilogram per millimetre width'),
	('KIC', 'kilogram, including container'),
	('KIP', 'kilogram, including inner packaging'),
	('KJ', 'kilosegment'),
	('KJO', 'kilojoule'),
	('KL', 'kilogram per metre'),
	('KLK', 'lactic dry material percentage'),
	('KMA', 'kilogram of methylamine'),
	('KMH', 'kilometre per hour'),
	('KMK', 'square kilometre'),
	('KMQ', 'kilogram per cubic metre'),
	('KMT', 'kilometre'),
	('KNI', 'kilogram of nitrogen'),
	('KNS', 'kilogram named substance'),
	('KNT', 'knot'),
	('KO', 'milliequivalence caustic potash per gram of product'),
	('KPA', 'kilopascal'),
	('KPH', 'kilogram of potassium hydroxide (caustic potash)'),
	('KPO', 'kilogram of potassium oxide'),
	('KPP', 'kilogram of phosphorus pentoxide (phosphoric anhydride)'),
	('KR', 'kiloroentgen'),
	('KS', 'thousand pound per square inch'),
	('KSD', 'kilogram of substance 90 % dry'),
	('KSH', 'kilogram of sodium hydroxide (caustic soda)'),
	('KT', 'kit'),
	('KTM', 'kilometre'),
	('KTN', 'kilotonne'),
	('KUR', 'kilogram of uranium'),
	('KVA', 'kilovolt - ampere'),
	('KVR', 'kilovar'),
	('KVT', 'kilovolt'),
	('KW', 'kilograms per millimetre'),
	('KWH', 'kilowatt hour'),
	('KWO', 'kilogram of tungsten trioxide'),
	('KWT', 'kilowatt'),
	('KX', 'millilitre per kilogram'),
	('L2', 'litre per minute'),
	('LA', 'pound per cubic inch'),
	('LAC', 'lactose excess percentage'),
	('LBR', 'pound'),
	('LBT', 'troy pound (US)'),
	('LC', 'linear centimetre'),
	('LD', 'litre per day'),
	('LE', 'lite'),
	('LEF', 'leaf'),
	('LF', 'linear foot'),
	('LH', 'labour hour'),
	('LI', 'linear inch'),
	('LJ', 'large spray'),
	('LK', 'link'),
	('LM', 'linear metre'),
	('LN', 'length'),
	('LO', 'lot  [unit of procurement]'),
	('LP', 'liquid pound'),
	('LPA', 'litre of pure alcohol'),
	('LR', 'layer'),
	('LS', 'lump sum'),
	('LTN', 'ton (UK) or long ton (US)'),
	('LTR', 'litre'),
	('LUB', 'metric ton, lubricating oil'),
	('LUM', 'lumen'),
	('LUX', 'lux'),
	('LX', 'linear yard per pound'),
	('LY', 'linear yard'),
	('M0', 'magnetic tape'),
	('M1', 'milligram per litre'),
	('M4', 'monetary value'),
	('M5', 'microcurie'),
	('M7', 'micro-inch'),
	('M9', 'million Btu per 1000 cubic feet'),
	('MA', 'machine per unit'),
	('MAH', 'megavolt ampere reactive hours'),
	('MAL', 'mega litre'),
	('MAM', 'megametre'),
	('MAR', 'megavolt ampere reactive'),
	('MAW', 'megawatt'),
	('MBE', 'thousand standard brick equivalent'),
	('MBF', 'thousand board feet'),
	('MBR', 'millibar'),
	('MC', 'microgram'),
	('MCU', 'millicurie'),
	('MD', 'air dry metric ton'),
	('MF', 'milligram per square foot per side'),
	('MGM', 'milligram'),
	('MHZ', 'megahertz'),
	('MIK', 'square mile'),
	('MIL', 'thousand'),
	('MIN', 'minute [unit of time]'),
	('MIO', 'million'),
	('MIU', 'million international unit'),
	('MK', 'milligram per square inch'),
	('MLD', 'milliard'),
	('MLT', 'millilitre'),
	('MMK', 'square millimetre'),
	('MMQ', 'cubic millimetre'),
	('MMT', 'millimetre'),
	('MND', 'kilogram, dry weight'),
	('MON', 'month'),
	('MPA', 'megapascal'),
	('MQ', 'thousand metre'),
	('MQH', 'cubic metre per hour'),
	('MQS', 'cubic metre per second'),
	('MSK', 'metre per second squared'),
	('MT', 'mat'),
	('MTK', 'square metre'),
	('MTQ', 'cubic metre'),
	('MTR', 'metre'),
	('MTS', 'metre per second'),
	('MV', 'number of mults'),
	('MVA', 'megavolt - ampere'),
	('MWH', 'megawatt hour (1000 kW.h)'),
	('N1', 'pen calorie'),
	('N2', 'number of lines'),
	('N3', 'print point'),
	('NA', 'milligram per kilogram'),
	('NAR', 'number of articles'),
	('NB', 'barge'),
	('NBB', 'number of bobbins'),
	('NC', 'car'),
	('NCL', 'number of cells'),
	('ND', 'net barrel'),
	('NE', 'net litre'),
	('NEW', 'newton'),
	('NF', 'message'),
	('NG', 'net gallon (us)'),
	('NH', 'message hour'),
	('NI', 'net imperial gallon'),
	('NIU', 'number of international units'),
	('NJ', 'number of screens'),
	('NL', 'load'),
	('NMI', 'nautical mile'),
	('NMP', 'number of packs'),
	('NN', 'train'),
	('NPL', 'number of parcels'),
	('NPR', 'number of pairs'),
	('NPT', 'number of parts'),
	('NQ', 'mho'),
	('NR', 'micromho'),
	('NRL', 'number of rolls'),
	('NT', 'net ton'),
	('NTT', 'net register ton'),
	('NU', 'newton metre'),
	('NV', 'vehicle'),
	('NX', 'part per thousand'),
	('NY', 'pound per air dry metric ton'),
	('OA', 'panel'),
	('ODE', 'ozone depletion equivalent'),
	('OHM', 'ohm'),
	('ON', 'ounce per square yard'),
	('ONZ', 'ounce'),
	('OP', 'two pack'),
	('OT', 'overtime hour'),
	('OZ', 'ounce av'),
	('OZA', 'fluid ounce (US)'),
	('OZI', 'fluid ounce (UK)'),
	('P0', 'page - electronic'),
	('P1', 'percent'),
	('P2', 'pound per foot'),
	('P3', 'three pack'),
	('P4', 'four pack'),
	('P5', 'five pack'),
	('P6', 'six pack'),
	('P7', 'seven pack'),
	('P8', 'eight pack'),
	('P9', 'nine pack'),
	('PA', 'packet'),
	('PAL', 'pascal'),
	('PB', 'pair inch'),
	('PD', 'pad'),
	('PE', 'pound equivalent'),
	('PF', 'pallet (lift)'),
	('PFL', 'proof litre'),
	('PG', 'plate'),
	('PGL', 'proof gallon'),
	('PI', 'pitch'),
	('PK', 'pack'),
	('PL', 'pail'),
	('PLA', 'degree Plato'),
	('PM', 'pound percentage'),
	('PN', 'pound net'),
	('PO', 'pound per inch of length'),
	('PQ', 'page per inch'),
	('PR', 'pair'),
	('PS', 'pound-force per square inch'),
	('PT', 'pint (US)'),
	('PTD', 'dry pint (US)'),
	('PTI', 'pint (UK)'),
	('PTL', 'liquid pint (US)'),
	('PU', 'tray / tray pack'),
	('PV', 'half pint (US)'),
	('PW', 'pound per inch of width'),
	('PY', 'peck dry (US)'),
	('PZ', 'peck dry (UK)'),
	('Q3', 'meal'),
	('QA', 'page - facsimile'),
	('QAN', 'quarter (of a year)'),
	('QB', 'page - hardcopy'),
	('QD', 'quarter dozen'),
	('QH', 'quarter hour'),
	('QK', 'quarter kilogram'),
	('QR', 'quire'),
	('QT', 'quart (US)'),
	('QTD', 'dry quart (US)'),
	('QTI', 'quart (UK)'),
	('QTL', 'liquid quart (US)'),
	('QTR', 'quarter (UK)'),
	('R1', 'pica'),
	('R4', 'calorie'),
	('R9', 'thousand cubic metre'),
	('RA', 'rack'),
	('RD', 'rod'),
	('RG', 'ring'),
	('RH', 'running or operating hour'),
	('RK', 'roll metric measure'),
	('RL', 'reel'),
	('RM', 'ream'),
	('RN', 'ream metric measure'),
	('RO', 'roll'),
	('RP', 'pound per ream'),
	('RPM', 'revolutions per minute'),
	('RPS', 'revolutions per second'),
	('RS', 'reset'),
	('RT', 'revenue ton mile'),
	('RU', 'run'),
	('S3', 'square foot per second'),
	('S4', 'square metre per second'),
	('S5', 'sixty fourths of an inch'),
	('S6', 'session'),
	('S7', 'storage unit'),
	('S8', 'standard advertising unit'),
	('SA', 'sack'),
	('SAN', 'half year (6 months)'),
	('SCO', 'score'),
	('SCR', 'scruple'),
	('SD', 'solid pound'),
	('SE', 'section'),
	('SEC', 'second [unit of time]'),
	('SET', 'set'),
	('SG', 'segment'),
	('SHT', 'shipping ton'),
	('SIE', 'siemens'),
	('SK', 'split tank truck'),
	('SL', 'slipsheet'),
	('SMI', 'mile (statute mile)'),
	('SN', 'square rod'),
	('SO', 'spool'),
	('SP', 'shelf package'),
	('SQ', 'square'),
	('SQR', 'square, roofing'),
	('SR', 'strip'),
	('SS', 'sheet metric measure'),
	('SST', 'short standard (7200 matches)'),
	('ST', 'sheet'),
	('STI', 'stone (UK)'),
	('STK', 'stick, cigarette'),
	('STL', 'standard litre'),
	('STN', 'ton (US) or short ton (UK/US)'),
	('SV', 'skid'),
	('SW', 'skein'),
	('SX', 'shipment'),
	('T0', 'telecommunication line in service'),
	('T1', 'thousand pound gross'),
	('T3', 'thousand piece'),
	('T4', 'thousand bag'),
	('T5', 'thousand casing'),
	('T6', 'thousand gallon (US)'),
	('T7', 'thousand impression'),
	('T8', 'thousand linear inch'),
	('TA', 'tenth cubic foot'),
	('TAH', 'kiloampere hour (thousand ampere hour)'),
	('TC', 'truckload'),
	('TD', 'therm'),
	('TE', 'tote'),
	('TF', 'ten square yard'),
	('TI', 'thousand square inch'),
	('TIC', 'metric ton, including container'),
	('TIP', 'metric ton, including inner packaging'),
	('TJ', 'thousand square centimetre'),
	('TK', 'tank, rectangular'),
	('TL', 'thousand feet (linear)'),
	('TMS', 'kilogram of imported meat, less offal'),
	('TN', 'tin'),
	('TNE', 'tonne (metric ton)'),
	('TP', 'ten pack'),
	('TPR', 'ten pair'),
	('TQ', 'thousand feet'),
	('TQD', 'thousand cubic metre per day'),
	('TR', 'ten square feet'),
	('TRL', 'trillion (EUR)'),
	('TS', 'thousand square feet'),
	('TSD', 'tonne of substance 90 % dry'),
	('TSH', 'ton of steam per hour'),
	('TT', 'thousand linear metre'),
	('TU', 'tube'),
	('TV', 'thousand kilogram'),
	('TW', 'thousand sheet'),
	('TY', 'tank, cylindrical'),
	('U1', 'treatment'),
	('U2', 'tablet'),
	('UA', 'torr'),
	('UB', 'telecommunication line in service average'),
	('UC', 'telecommunication port'),
	('UD', 'tenth minute'),
	('UE', 'tenth hour'),
	('UF', 'usage per telecommunication line average'),
	('UH', 'ten thousand yard'),
	('UM', 'million unit'),
	('VA', 'volt ampere per kilogram'),
	('VI', 'vial'),
	('VLT', 'volt'),
	('VQ', 'bulk'),
	('VS', 'visit'),
	('W2', 'wet kilo'),
	('W4', 'two week'),
	('WA', 'watt per kilogram'),
	('WB', 'wet pound'),
	('WCD', 'cord'),
	('WE', 'wet ton'),
	('WEB', 'weber'),
	('WEE', 'week'),
	('WG', 'wine gallon'),
	('WH', 'wheel'),
	('WHR', 'watt hour'),
	('WI', 'weight per square inch'),
	('WM', 'working month'),
	('WR', 'wrap'),
	('WSD', 'standard'),
	('WTT', 'watt'),
	('WW', 'millilitre of water'),
	('X1', 'chain'),
	('YDK', 'square yard'),
	('YDQ', 'cubic yard'),
	('YL', 'hundred linear yard'),
	('YRD', 'yard'),
	('YT', 'ten yard'),
	('Z1', 'lift van'),
	('Z2', 'chest'),
	('Z3', 'cask'),
	('Z4', 'hogshead'),
	('Z5', 'lug'),
	('Z6', 'conference point'),
	('Z8', 'newspage agate line'),
	('ZP', 'page'),
	('ZZ', 'mutually defined');
/*!40000 ALTER TABLE `orderunit` ENABLE KEYS */;


# Dumping structure for table ebus.order_customer
CREATE TABLE IF NOT EXISTS `order_customer` (
  `orderid` char(40) NOT NULL DEFAULT '',
  `quotationref` char(40) DEFAULT NULL,
  `customer` char(40) NOT NULL,
  `orderdate` datetime NOT NULL,
  `ordertype` char(16) DEFAULT NULL,
  `orderid_customer` char(40) DEFAULT NULL,
  `invoiceaddress` char(40) DEFAULT NULL,
  `deliveryaddress` char(40) DEFAULT NULL,
  `currency` char(3) DEFAULT NULL,
  `remark` varchar(2000) DEFAULT NULL,
  `partialshipment` int(11) DEFAULT NULL,
  `transport` varchar(256) DEFAULT NULL,
  `specialtreatment` varchar(256) DEFAULT NULL,
  `internationalrestrictions` varchar(256) DEFAULT NULL,
  `pricetotal_net` decimal(10,2) DEFAULT NULL,
  `pricetotal_gross` decimal(10,2) DEFAULT NULL,
  `taxtotal` decimal(10,2) DEFAULT NULL,
  `taxamount` decimal(10,2) DEFAULT NULL,
  `totallineitems` int(11) DEFAULT NULL,
  `xml_file_request` longtext,
  `xml_file_response` longtext,
  `is_rejected` int(1) NOT NULL DEFAULT '0',
  `is_splitted` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`orderid`),
  UNIQUE KEY `ordercustc_u1` (`orderid_customer`,`customer`),
  KEY `ordercust_quotcust_fk` (`quotationref`),
  KEY `ordercust_cust_fk` (`customer`),
  KEY `ordercust_curr_fk_fk` (`currency`),
  KEY `ordercust_deladr_fk` (`invoiceaddress`),
  KEY `ordercust_invadr_fk` (`deliveryaddress`),
  CONSTRAINT `ordercust_curr_fk_fk` FOREIGN KEY (`currency`) REFERENCES `currency` (`code`),
  CONSTRAINT `ordercust_cust_fk` FOREIGN KEY (`customer`) REFERENCES `customer` (`customerid`),
  CONSTRAINT `ordercust_deladr_fk` FOREIGN KEY (`invoiceaddress`) REFERENCES `address` (`id`),
  CONSTRAINT `ordercust_invadr_fk` FOREIGN KEY (`deliveryaddress`) REFERENCES `address` (`id`),
  CONSTRAINT `ordercust_quotcust_fk` FOREIGN KEY (`quotationref`) REFERENCES `quotation_customer` (`quotationid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.order_customer: ~1 rows (approximately)
/*!40000 ALTER TABLE `order_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_customer` ENABLE KEYS */;


# Dumping structure for table ebus.order_purchase
CREATE TABLE IF NOT EXISTS `order_purchase` (
  `orderid` char(40) NOT NULL DEFAULT '',
  `quotationref` char(40) DEFAULT NULL,
  `supplier` char(40) NOT NULL,
  `orderdate` datetime NOT NULL,
  `ordertype` char(16) DEFAULT NULL,
  `orderid_supplier` char(40) DEFAULT NULL,
  `invoiceaddress` char(40) DEFAULT NULL,
  `deliveryaddress` char(40) DEFAULT NULL,
  `currency` char(3) DEFAULT NULL,
  `remark` varchar(2000) DEFAULT NULL,
  `partialshipment` int(11) DEFAULT NULL,
  `transport` varchar(256) DEFAULT NULL,
  `specialtreatment` varchar(256) DEFAULT NULL,
  `internationalrestrictions` varchar(256) DEFAULT NULL,
  `pricetotal_net` decimal(10,2) DEFAULT NULL,
  `pricetotal_gross` decimal(10,2) DEFAULT NULL,
  `taxtotal` decimal(10,2) DEFAULT NULL,
  `taxamount` decimal(10,2) DEFAULT NULL,
  `totallineitems` int(11) DEFAULT NULL,
  `xml_file_request` longtext,
  `xml_file_response` longtext,
  `is_rejected` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`orderid`),
  UNIQUE KEY `orderpurc_u1` (`orderid_supplier`,`supplier`),
  KEY `orderpurc_quotpurc_fk` (`quotationref`),
  KEY `orderpurc_supplier_fk` (`supplier`),
  KEY `orderpurc_currency_fk` (`currency`),
  KEY `orderpurc_invaddr_fk` (`invoiceaddress`),
  KEY `orderpurc_deladdr_fk` (`deliveryaddress`),
  CONSTRAINT `orderpurc_currency_fk` FOREIGN KEY (`currency`) REFERENCES `currency` (`code`),
  CONSTRAINT `orderpurc_deladdr_fk` FOREIGN KEY (`deliveryaddress`) REFERENCES `address` (`id`),
  CONSTRAINT `orderpurc_invaddr_fk` FOREIGN KEY (`invoiceaddress`) REFERENCES `address` (`id`),
  CONSTRAINT `orderpurc_quotpurc_fk` FOREIGN KEY (`quotationref`) REFERENCES `quotation_purchase` (`quotationid`),
  CONSTRAINT `orderpurc_supplier_fk` FOREIGN KEY (`supplier`) REFERENCES `supplier` (`suppliernumber`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.order_purchase: ~1 rows (approximately)
/*!40000 ALTER TABLE `order_purchase` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_purchase` ENABLE KEYS */;


# Dumping structure for table ebus.paymentreceipt_customer
CREATE TABLE IF NOT EXISTS `paymentreceipt_customer` (
  `paymentreceiptnumber` char(40) NOT NULL DEFAULT '',
  `paymentreceiptdate` date NOT NULL,
  `paymenttype` char(32) DEFAULT NULL,
  `paymentinformation` varchar(512) DEFAULT NULL,
  `paymentinfotext` varchar(512) DEFAULT NULL,
  `customer` char(40) NOT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `currency` char(3) NOT NULL,
  PRIMARY KEY (`paymentreceiptnumber`),
  KEY `payreccust_customer_fk` (`customer`),
  KEY `payreccust_currency_fk` (`currency`),
  CONSTRAINT `payreccust_currency_fk` FOREIGN KEY (`currency`) REFERENCES `currency` (`code`),
  CONSTRAINT `payreccust_customer_fk` FOREIGN KEY (`customer`) REFERENCES `customer` (`customerid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.paymentreceipt_customer: ~0 rows (approximately)
/*!40000 ALTER TABLE `paymentreceipt_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `paymentreceipt_customer` ENABLE KEYS */;


# Dumping structure for table ebus.paymentreceipt_invoice_cust
CREATE TABLE IF NOT EXISTS `paymentreceipt_invoice_cust` (
  `paymentreceipt` char(40) NOT NULL DEFAULT '',
  `invoice` char(40) NOT NULL DEFAULT '',
  `invoiceitem` int(11) NOT NULL DEFAULT '0',
  `partialpaymentnumber` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`paymentreceipt`,`invoice`,`invoiceitem`,`partialpaymentnumber`),
  KEY `payrecinvcust_inv_fk` (`invoice`,`invoiceitem`),
  CONSTRAINT `payrecinvcust_inv_fk` FOREIGN KEY (`invoice`, `invoiceitem`) REFERENCES `invoiceitem_customer` (`invoice`, `itemnumber`),
  CONSTRAINT `payrecinvcust_payrec_fk` FOREIGN KEY (`paymentreceipt`) REFERENCES `paymentreceipt_customer` (`paymentreceiptnumber`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.paymentreceipt_invoice_cust: ~0 rows (approximately)
/*!40000 ALTER TABLE `paymentreceipt_invoice_cust` DISABLE KEYS */;
/*!40000 ALTER TABLE `paymentreceipt_invoice_cust` ENABLE KEYS */;


# Dumping structure for table ebus.paymenttype
CREATE TABLE IF NOT EXISTS `paymenttype` (
  `code` char(16) NOT NULL DEFAULT '',
  `description` varchar(256) NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.paymenttype: ~5 rows (approximately)
/*!40000 ALTER TABLE `paymenttype` DISABLE KEYS */;
INSERT INTO `paymenttype` (`code`, `description`) VALUES
	('ACCOUNT', 'Bankverbindung'),
	('CARD', 'Verwendung für Kreditkarten'),
	('CASH', 'Barzahlung'),
	('CHECK', 'Scheckbezahlung'),
	('DEBIT', 'Gutschriftsverfahren');
/*!40000 ALTER TABLE `paymenttype` ENABLE KEYS */;


# Dumping structure for table ebus.payment_invoice_purchase
CREATE TABLE IF NOT EXISTS `payment_invoice_purchase` (
  `payment` char(40) NOT NULL DEFAULT '',
  `invoice` char(40) NOT NULL DEFAULT '',
  `invoiceitem` int(11) NOT NULL DEFAULT '0',
  `partialpaymentnumber` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`payment`,`invoice`,`invoiceitem`,`partialpaymentnumber`),
  KEY `payinvpurc_inv_fk` (`invoice`,`invoiceitem`),
  CONSTRAINT `payinvpurc_inv_fk` FOREIGN KEY (`invoice`, `invoiceitem`) REFERENCES `invoiceitem_purchase` (`invoice`, `itemnumber`),
  CONSTRAINT `payinvpurc_payrec_fk` FOREIGN KEY (`payment`) REFERENCES `payment_purchase` (`paymentnumber`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.payment_invoice_purchase: ~0 rows (approximately)
/*!40000 ALTER TABLE `payment_invoice_purchase` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_invoice_purchase` ENABLE KEYS */;


# Dumping structure for table ebus.payment_purchase
CREATE TABLE IF NOT EXISTS `payment_purchase` (
  `paymentnumber` char(40) NOT NULL DEFAULT '',
  `paymentdate` date NOT NULL,
  `paymenttype` char(32) DEFAULT NULL,
  `paymentinformation` varchar(512) DEFAULT NULL,
  `paymentinfotext` varchar(512) DEFAULT NULL,
  `supplier` char(40) NOT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `currency` char(3) NOT NULL,
  PRIMARY KEY (`paymentnumber`),
  KEY `paypurc_customer_fk` (`supplier`),
  KEY `paypurc_currency_fk` (`currency`),
  CONSTRAINT `paypurc_currency_fk` FOREIGN KEY (`currency`) REFERENCES `currency` (`code`),
  CONSTRAINT `paypurc_customer_fk` FOREIGN KEY (`supplier`) REFERENCES `supplier` (`suppliernumber`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.payment_purchase: ~0 rows (approximately)
/*!40000 ALTER TABLE `payment_purchase` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_purchase` ENABLE KEYS */;


# Dumping structure for table ebus.pricetype
CREATE TABLE IF NOT EXISTS `pricetype` (
  `code` char(16) NOT NULL DEFAULT '',
  `description` varchar(256) NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.pricetype: ~5 rows (approximately)
/*!40000 ALTER TABLE `pricetype` DISABLE KEYS */;
INSERT INTO `pricetype` (`code`, `description`) VALUES
	('gros_list', '(Einkaufs-)Listenpreis inklusive Umsatzsteuer'),
	('net_customer', 'Kundenspezifischer Endpreis ohne Umsatzsteuer'),
	('net_list', '(Einkaufs-)Listenpreis ohne Umsatzsteuer'),
	('new', 'Neu'),
	('nrp', 'unverbindliche (Verkaufs-)Preisempfehlung (nonbinding recommended price)');
/*!40000 ALTER TABLE `pricetype` ENABLE KEYS */;


# Dumping structure for table ebus.product
CREATE TABLE IF NOT EXISTS `product` (
  `materialnumber` int(11) NOT NULL DEFAULT '0',
  `ordernumber_supplier` char(40) NOT NULL,
  `shortdescription` varchar(256) NOT NULL,
  `longdescription` varchar(2000) DEFAULT NULL,
  `ordernumber_customer` char(40) NOT NULL,
  `shortdescription_customer` varchar(256) DEFAULT NULL,
  `longdescription_customer` varchar(2000) DEFAULT NULL,
  `manufacturertypedescription` varchar(256) DEFAULT NULL,
  `supplier` char(40) NOT NULL,
  `manufacturer` varchar(256) DEFAULT NULL,
  `productstatus` varchar(64) DEFAULT NULL,
  `producttype` varchar(64) DEFAULT NULL,
  `productcategory` char(64) DEFAULT NULL,
  `remark` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`materialnumber`),
  UNIQUE KEY `product_u3` (`ordernumber_supplier`,`supplier`),
  UNIQUE KEY `product_u1` (`ordernumber_customer`),
  KEY `product_prodcat_fk` (`productcategory`),
  KEY `product_supplier_fk` (`supplier`),
  CONSTRAINT `product_prodcat_fk` FOREIGN KEY (`productcategory`) REFERENCES `productcategory` (`shortdescription`),
  CONSTRAINT `product_supplier_fk` FOREIGN KEY (`supplier`) REFERENCES `supplier` (`suppliernumber`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.product: ~17 rows (approximately)
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` (`materialnumber`, `ordernumber_supplier`, `shortdescription`, `longdescription`, `ordernumber_customer`, `shortdescription_customer`, `longdescription_customer`, `manufacturertypedescription`, `supplier`, `manufacturer`, `productstatus`, `producttype`, `productcategory`, `remark`) VALUES
	(1, 'mer-penbook-1', 'HTWG-Pen Book', 'quadratisches Notizbuch inkl. HTWG-Kugelschreiber, 18 x 18 cm', 'mer-penbook-1', 'HTWG-Pen Book', 'quadratisches Notizbuch inkl. HTWG-Kugelschreiber, 18 x 18 cm', NULL, '10', 'HTWG Konstanz', NULL, NULL, 'Alle', NULL),
	(2, 'htwg-bluse-201', 'HTWG Damen Bluse', 'weiße Bluse, am Kragen HTWG-Schmuckelement, gestickt in blauer Farbe', 'htwg-bluse-201', 'HTWG Damen Bluse', 'weiße Bluse, am Kragen HTWG-Schmuckelement, gestickt in blauer Farbe', NULL, '10', 'HTWG Konstanz', NULL, NULL, 'Alle', NULL),
	(3, 'htwg-hemd-101', 'HTWG Herren Hemd', 'weißes Herren Hemd, am Kragen HTWG-Schmuckelement, gestickt in blauer Farbe', 'htwg-hemd-101', 'HTWG Herren Hemd', 'weißes Herren Hemd, am Kragen HTWG-Schmuckelement, gestickt in blauer Farbe', NULL, '10', 'HTWG Konstanz', NULL, NULL, 'Alle', NULL),
	(4, 'mer-pin-1', 'HTWG-Ansteckpin', 'Metallpin mit Logo, Hintergrund weiß', 'mer-pin-1', 'HTWG-Ansteckpin', 'Metallpin mit Logo, Hintergrund weiß', NULL, '10', 'HTWG Konstanz', NULL, NULL, 'Alle', NULL),
	(5, 'mer-blockA4-1', 'HTWG-Block', 'Din A4, blaues Cover, innen Rasterpunkte', 'mer-blockA4-1', 'HTWG-Block', 'Din A4, blaues Cover, innen Rasterpunkte', NULL, '10', 'HTWG Konstanz', NULL, NULL, 'Alle', NULL),
	(6, 'mer-konmappe-1', 'HTWG-Konferenzmappe', 'weiße Mappe mit Cyan-logo, innen Cyan-Wellenmuster, breiter Rücken', 'mer-konmappe-1', 'HTWG-Konferenzmappe', 'weiße Mappe mit Cyan-logo, innen Cyan-Wellenmuster, breiter Rücken', NULL, '10', 'HTWG Konstanz', NULL, NULL, 'Alle', NULL),
	(7, 'mer-stift-2', 'HTWG-Kugelschreiber', 'hochwertiger Kugelschreiber, Farbe: schwarz / silbern, logo in Cyan-blau', 'mer-stift-2', 'HTWG-Kugelschreiber', 'hochwertiger Kugelschreiber, Farbe: schwarz / silbern, logo in Cyan-blau', NULL, '10', 'HTWG Konstanz', NULL, NULL, 'Alle', NULL),
	(8, 'mer-stiftebox-1', 'HTWG-Stiftebox', 'Staedtler Stiftebox mit HTWG-Aufkleber, enthält 4 Stifte, aufstellbar', 'mer-stiftebox-1', 'HTWG-Stiftebox', 'Staedtler Stiftebox mit HTWG-Aufkleber, enthält 4 Stifte, aufstellbar', NULL, '10', 'HTWG Konstanz', NULL, NULL, 'Alle', NULL),
	(9, 'mer-uhr-1', 'HTWG-Uhr', 'International Watch Group Switzerland Damen- und Herrenmodell, Ziffernblatt mit HTWG-Logo, inkl. silberner Präsentbox', 'mer-uhr-1', 'HTWG-Uhr', 'International Watch Group Switzerland Damen- und Herrenmodell, Ziffernblatt mit HTWG-Logo, inkl. silberner Präsentbox', NULL, '10', 'HTWG Konstanz', NULL, NULL, 'Alle', NULL),
	(10, 'mer-zeugmappe-1', 'HTWG-Zeugnismappe', 'weiße Mappe mit Cyan-logo, innen Cyan-Wellenmuster, für wenige Blätter', 'mer-zeugmappe-1', 'HTWG-Zeugnismappe', 'weiße Mappe mit Cyan-logo, innen Cyan-Wellenmuster, für wenige Blätter', NULL, '10', 'HTWG Konstanz', NULL, NULL, 'Alle', NULL),
	(20, '3198044', 'MAUI WOWIE Badeshorts Frauen', 'Maui Wowie Badeshorts mit Schnürung, 1 Gesäßtasche, Schlüsseltäschchen; Länge ca. 50cm/Gr. 38; aus 100% Polyester.', '3198044', 'MAUI WOWIE Badeshorts Frauen', 'Maui Wowie Badeshorts mit Schnürung, 1 Gesäßtasche, Schlüsseltäschchen; Länge ca. 50cm/Gr. 38; aus 100% Polyester.', NULL, '20', 'Sportscheck', NULL, NULL, 'Sport', NULL),
	(21, '3097266', 'MAUI WOWIE Badeshorts Männer', 'Maui Wowie Badeshorts mit Elastikbund und Kordelzug, 2 seitliche Einschubtaschen, 1 Gesäßtasche; Innenslip und Schlüsseltäschchen; Länge ca. 38cm/Gr. L; aus 100% Polyester.', '3097266', 'MAUI WOWIE Badeshorts Männer', 'Maui Wowie Badeshorts mit Elastikbund und Kordelzug, 2 seitliche Einschubtaschen, 1 Gesäßtasche; Innenslip und Schlüsseltäschchen; Länge ca. 38cm/Gr. L; aus 100% Polyester.', NULL, '20', 'Sportscheck', NULL, NULL, 'Sport', NULL),
	(22, '837472D', 'MAUI WOWIE Sandale Frauen Flower', 'Maui Wowie FLOWER. Zehensandale aus PU und EVA; Fußbett mit floralem Musterprint; Außensohle mit leichtem Rillenprofil.', '837472D', 'MAUI WOWIE Sandale Frauen Flower', 'Maui Wowie FLOWER. Zehensandale aus PU und EVA; Fußbett mit floralem Musterprint; Außensohle mit leichtem Rillenprofil.', NULL, '20', 'Sportscheck', NULL, NULL, 'Sport', NULL),
	(23, '1054746', 'Mikasa Beachvolley', 'Beachvolleyball von Mikasa, orange/anthrazit', '1054746', 'Mikasa Beachvolley', 'Beachvolleyball von Mikasa, orange/anthrazit', NULL, '20', 'Sportscheck', NULL, NULL, 'Sport', NULL),
	(24, '368972C', 'Protest Bikini', 'Protest Bustierbikini mit Neckholderträgern, herausnehmbaren Pads, Bändel im Nacken und Rücken zu binden; Höschen gefüttert, mit wendbarem Gürtel; aus 80% Polyamid, 20% Elastan', '368972C', 'Protest Bikini', 'Protest Bustierbikini mit Neckholderträgern, herausnehmbaren Pads, Bändel im Nacken und Rücken zu binden; Höschen gefüttert, mit wendbarem Gürtel; aus 80% Polyamid, 20% Elastan', NULL, '20', 'Sportscheck', NULL, NULL, 'Sport', NULL),
	(25, '2783103', 'QUIKSILVER Handtuch', 'Strandtuch - Limited Edition Ob Schwimmbad, Sandstrand oder am Baggersee ... mit diesem weichen Strandtuch im attraktiven QUIKSILVER-Logo-Design liegst du überall richtig. Material: 100% Baumwolle Farbe: Blau Größe: L/180 x B/85 cm', '2783103', 'QUIKSILVER Handtuch', 'Strandtuch - Limited Edition Ob Schwimmbad, Sandstrand oder am Baggersee ... mit diesem weichen Strandtuch im attraktiven QUIKSILVER-Logo-Design liegst du überall richtig. Material: 100% Baumwolle Farbe: Blau Größe: L/180 x B/85 cm', NULL, '20', 'Sportscheck', NULL, NULL, 'Sport', NULL),
	(26, '5656349', 'UVEX Brille Snowsun', 'Uvex SNOWSUN. Perfekt sitzende Sportbrille mit gummierten Bügelenden für optimalen Halt, Innenseite komplett gummiert, schließt dadurch rundherum ab; 100% UV-Schutz, bruch- und kratzfest beschichtet, optisch absolut korrekt.', '5656349', 'UVEX Brille Snowsun', 'Uvex SNOWSUN. Perfekt sitzende Sportbrille mit gummierten Bügelenden für optimalen Halt, Innenseite komplett gummiert, schließt dadurch rundherum ab; 100% UV-Schutz, bruch- und kratzfest beschichtet, optisch absolut korrekt.', NULL, '20', 'Sportscheck', NULL, NULL, 'Sport', NULL);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;


# Dumping structure for table ebus.productcategory
CREATE TABLE IF NOT EXISTS `productcategory` (
  `shortdescription` char(64) NOT NULL DEFAULT '',
  `description` varchar(256) DEFAULT NULL,
  `parentcategory` char(64) DEFAULT NULL,
  PRIMARY KEY (`shortdescription`),
  KEY `prodcateg_prodcateg_fk` (`parentcategory`),
  CONSTRAINT `prodcateg_prodcateg_fk` FOREIGN KEY (`parentcategory`) REFERENCES `productcategory` (`shortdescription`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.productcategory: ~3 rows (approximately)
/*!40000 ALTER TABLE `productcategory` DISABLE KEYS */;
INSERT INTO `productcategory` (`shortdescription`, `description`, `parentcategory`) VALUES
	('Alle', 'Alle Produkte', NULL),
	('Merchandising', 'HTWG Merchandising Produkte', 'Alle'),
	('Sport', 'Sport Produkte', 'Alle');
/*!40000 ALTER TABLE `productcategory` ENABLE KEYS */;


# Dumping structure for table ebus.productreference
CREATE TABLE IF NOT EXISTS `productreference` (
  `product` int(11) NOT NULL DEFAULT '0',
  `referencedproduct` int(11) NOT NULL DEFAULT '0',
  `referencetype` char(64) DEFAULT 'accessory',
  `quantity` int(11) DEFAULT '1',
  `remark` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`product`,`referencedproduct`),
  KEY `prodref_product_fk2` (`referencedproduct`),
  CONSTRAINT `prodref_product_fk1` FOREIGN KEY (`product`) REFERENCES `product` (`materialnumber`) ON DELETE CASCADE,
  CONSTRAINT `prodref_product_fk2` FOREIGN KEY (`referencedproduct`) REFERENCES `product` (`materialnumber`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.productreference: ~0 rows (approximately)
/*!40000 ALTER TABLE `productreference` DISABLE KEYS */;
/*!40000 ALTER TABLE `productreference` ENABLE KEYS */;


# Dumping structure for table ebus.productstatus
CREATE TABLE IF NOT EXISTS `productstatus` (
  `code` varchar(64) NOT NULL DEFAULT '',
  `description` varchar(256) NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.productstatus: ~5 rows (approximately)
/*!40000 ALTER TABLE `productstatus` DISABLE KEYS */;
INSERT INTO `productstatus` (`code`, `description`) VALUES
	('bargain', 'Ein Sonderangebot kennzeichnet einen besonders günstigen, zeitlich begrenzten Preis.'),
	('core_product', 'Das Produkt gehört zu dem Kernsortiment'),
	('new', 'Das Produkt ist neu hergestellt, d.h. es ist nicht gebraucht.'),
	('old_product', 'Das Produkt kann nicht mehr bestellt werden, es wird aber noch angezeigt, um beispielsweise auf das Nachfolgeprodukt zu verweisen.'),
	('used', 'Das Produkt ist gebraucht, d.h. es ist nicht neu herstellt.');
/*!40000 ALTER TABLE `productstatus` ENABLE KEYS */;


# Dumping structure for table ebus.producttype
CREATE TABLE IF NOT EXISTS `producttype` (
  `code` varchar(64) NOT NULL DEFAULT '',
  `description` varchar(256) NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.producttype: ~3 rows (approximately)
/*!40000 ALTER TABLE `producttype` DISABLE KEYS */;
INSERT INTO `producttype` (`code`, `description`) VALUES
	('license ', 'Das Produkt ist eine Lizenz.'),
	('physical', 'Das Produkt ist physisch/materiell'),
	('service', 'Das Produkt ist eine Dienstleistung.');
/*!40000 ALTER TABLE `producttype` ENABLE KEYS */;


# Dumping structure for table ebus.purchaseprice
CREATE TABLE IF NOT EXISTS `purchaseprice` (
  `product` int(11) NOT NULL DEFAULT '0',
  `country` char(5) NOT NULL DEFAULT '',
  `lowerbound_scaledprice` int(11) NOT NULL DEFAULT '1',
  `priceunit` int(11) DEFAULT '1',
  `pricetype` char(16) NOT NULL,
  `taxrate` decimal(4,4) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `remark` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`country`,`product`,`lowerbound_scaledprice`),
  KEY `purchprice_product_fk` (`product`),
  CONSTRAINT `purchprice_country_fk` FOREIGN KEY (`country`) REFERENCES `country` (`isocode`) ON DELETE CASCADE,
  CONSTRAINT `purchprice_product_fk` FOREIGN KEY (`product`) REFERENCES `product` (`materialnumber`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.purchaseprice: ~17 rows (approximately)
/*!40000 ALTER TABLE `purchaseprice` DISABLE KEYS */;
INSERT INTO `purchaseprice` (`product`, `country`, `lowerbound_scaledprice`, `priceunit`, `pricetype`, `taxrate`, `amount`, `remark`) VALUES
	(1, 'DE', 1, 1, 'net_list', 0.1900, 5.88, 'HTWG0001'),
	(2, 'DE', 1, 1, 'net_list', 0.1900, 25.21, 'HTWG0001'),
	(3, 'DE', 1, 1, 'net_list', 0.1900, 25.21, 'HTWG0001'),
	(4, 'DE', 1, 1, 'net_list', 0.1900, 0.84, 'HTWG0001'),
	(5, 'DE', 1, 1, 'net_list', 0.1900, 0.84, 'HTWG0001'),
	(6, 'DE', 1, 1, 'net_list', 0.1900, 0.42, 'HTWG0001'),
	(7, 'DE', 1, 1, 'net_list', 0.1900, 0.42, 'HTWG0001'),
	(8, 'DE', 1, 1, 'net_list', 0.1900, 1.68, 'HTWG0001'),
	(9, 'DE', 1, 1, 'net_list', 0.1900, 21.01, 'HTWG0001'),
	(10, 'DE', 1, 1, 'net_list', 0.1900, 0.42, 'HTWG0001'),
	(20, 'DE', 1, 1, 'net_list', 0.1900, 34.95, 'Sportscheck 3198044'),
	(21, 'DE', 1, 1, 'net_list', 0.1900, 34.95, 'Sportscheck 3097266'),
	(22, 'DE', 1, 1, 'net_list', 0.1900, 14.95, 'Sportscheck 837472D'),
	(23, 'DE', 1, 1, 'net_list', 0.1900, 19.95, 'Sportscheck 1054746'),
	(24, 'DE', 1, 1, 'net_list', 0.1900, 42.95, 'Sportscheck 368972C'),
	(25, 'DE', 1, 1, 'net_list', 0.1900, 19.95, 'Sportscheck 2783103'),
	(26, 'DE', 1, 1, 'net_list', 0.1900, 24.95, 'Sportscheck 5656349');
/*!40000 ALTER TABLE `purchaseprice` ENABLE KEYS */;


# Dumping structure for table ebus.quotationitem_customer
CREATE TABLE IF NOT EXISTS `quotationitem_customer` (
  `quotation` char(40) NOT NULL DEFAULT '',
  `itemnumber` int(11) NOT NULL DEFAULT '0',
  `ordernumber_customer` char(40) NOT NULL,
  `productdescription` varchar(256) DEFAULT NULL,
  `orderamount` int(11) NOT NULL,
  `orderunit` char(16) NOT NULL,
  `contentunit` char(16) DEFAULT NULL,
  `no_cu_per_ou` int(11) DEFAULT '1',
  `unitprice` decimal(10,2) DEFAULT NULL,
  `itemprice` decimal(10,2) DEFAULT NULL,
  `pricetype` char(16) DEFAULT NULL,
  `pricequantity` int(11) DEFAULT NULL,
  `taxrate` decimal(4,2) DEFAULT NULL,
  `taxamount` decimal(10,2) DEFAULT NULL,
  `deliveryaddress` char(40) DEFAULT NULL,
  `partialshipment` int(11) DEFAULT NULL,
  `transport` varchar(256) DEFAULT NULL,
  `specialtreatment` varchar(256) DEFAULT NULL,
  `internationalrestrictions` varchar(256) DEFAULT NULL,
  `remark` varchar(256) DEFAULT NULL,
  `quotationtype` char(16) DEFAULT NULL,
  PRIMARY KEY (`quotation`,`itemnumber`),
  KEY `quotitemcust_deladdr_fk` (`deliveryaddress`),
  CONSTRAINT `quotitemcust_deladdr_fk` FOREIGN KEY (`deliveryaddress`) REFERENCES `address` (`id`),
  CONSTRAINT `quotitemcust_rfqcust_fk` FOREIGN KEY (`quotation`) REFERENCES `quotation_customer` (`quotationid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.quotationitem_customer: ~0 rows (approximately)
/*!40000 ALTER TABLE `quotationitem_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `quotationitem_customer` ENABLE KEYS */;


# Dumping structure for table ebus.quotationitem_purchase
CREATE TABLE IF NOT EXISTS `quotationitem_purchase` (
  `quotation` char(40) NOT NULL DEFAULT '',
  `itemnumber` int(11) NOT NULL DEFAULT '0',
  `ordernumber_supplier` char(40) NOT NULL,
  `productdescription` varchar(256) DEFAULT NULL,
  `orderamount` int(11) NOT NULL,
  `orderunit` char(16) NOT NULL,
  `contentunit` char(16) DEFAULT NULL,
  `no_cu_per_ou` int(11) DEFAULT '1',
  `unitprice` decimal(10,2) DEFAULT NULL,
  `itemprice` decimal(10,2) DEFAULT NULL,
  `pricetype` char(16) DEFAULT NULL,
  `pricequantity` int(11) DEFAULT NULL,
  `taxrate` decimal(4,2) DEFAULT NULL,
  `taxamount` decimal(10,2) DEFAULT NULL,
  `deliveryaddress` char(40) DEFAULT NULL,
  `partialshipment` int(11) DEFAULT NULL,
  `transport` varchar(256) DEFAULT NULL,
  `specialtreatment` varchar(256) DEFAULT NULL,
  `internationalrestrictions` varchar(256) DEFAULT NULL,
  `remark` varchar(256) DEFAULT NULL,
  `quotationtype` char(16) DEFAULT NULL,
  PRIMARY KEY (`quotation`,`itemnumber`),
  KEY `quotitempurc_deladdr_fk` (`deliveryaddress`),
  CONSTRAINT `quotitempurc_deladdr_fk` FOREIGN KEY (`deliveryaddress`) REFERENCES `address` (`id`),
  CONSTRAINT `quotitempurc_rfqcust_fk` FOREIGN KEY (`quotation`) REFERENCES `quotation_purchase` (`quotationid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.quotationitem_purchase: ~0 rows (approximately)
/*!40000 ALTER TABLE `quotationitem_purchase` DISABLE KEYS */;
/*!40000 ALTER TABLE `quotationitem_purchase` ENABLE KEYS */;


# Dumping structure for table ebus.quotationtype
CREATE TABLE IF NOT EXISTS `quotationtype` (
  `code` char(16) NOT NULL DEFAULT '',
  `description` varchar(256) NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.quotationtype: ~1 rows (approximately)
/*!40000 ALTER TABLE `quotationtype` DISABLE KEYS */;
INSERT INTO `quotationtype` (`code`, `description`) VALUES
	('standard', 'Standangebot');
/*!40000 ALTER TABLE `quotationtype` ENABLE KEYS */;


# Dumping structure for table ebus.quotation_customer
CREATE TABLE IF NOT EXISTS `quotation_customer` (
  `quotationid` char(40) NOT NULL DEFAULT '',
  `rfqref` char(40) DEFAULT NULL,
  `customer` char(40) NOT NULL,
  `quotationdate` date NOT NULL,
  `quotationtype` char(16) DEFAULT NULL,
  `quotationid_customer` char(40) DEFAULT NULL,
  `invoiceaddress` char(40) DEFAULT NULL,
  `deliveryaddress` char(40) DEFAULT NULL,
  `currency` char(3) DEFAULT NULL,
  `remark` varchar(2000) DEFAULT NULL,
  `partialshipment` int(11) DEFAULT NULL,
  `transport` varchar(256) DEFAULT NULL,
  `specialtreatment` varchar(256) DEFAULT NULL,
  `internationalrestrictions` varchar(256) DEFAULT NULL,
  `pricetotal_net` decimal(10,2) DEFAULT NULL,
  `pricetotal_gross` decimal(10,2) DEFAULT NULL,
  `taxtotal` decimal(10,2) DEFAULT NULL,
  `taxamount` decimal(10,2) DEFAULT NULL,
  `totallineitems` int(11) DEFAULT NULL,
  PRIMARY KEY (`quotationid`),
  UNIQUE KEY `quotcust_u1` (`quotationid_customer`,`customer`),
  KEY `quotcust_rfqcust_fk` (`rfqref`),
  KEY `quotcust_customer_fk` (`customer`),
  KEY `quotcust_currency_fk` (`currency`),
  KEY `quotcust_deladdr_fk` (`invoiceaddress`),
  CONSTRAINT `quotcust_currency_fk` FOREIGN KEY (`currency`) REFERENCES `currency` (`code`),
  CONSTRAINT `quotcust_customer_fk` FOREIGN KEY (`customer`) REFERENCES `customer` (`customerid`),
  CONSTRAINT `quotcust_deladdr_fk` FOREIGN KEY (`invoiceaddress`) REFERENCES `address` (`id`),
  CONSTRAINT `quotcust_invaddr_fk` FOREIGN KEY (`invoiceaddress`) REFERENCES `address` (`id`),
  CONSTRAINT `quotcust_rfqcust_fk` FOREIGN KEY (`rfqref`) REFERENCES `requestforquotation_customer` (`rfqid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.quotation_customer: ~0 rows (approximately)
/*!40000 ALTER TABLE `quotation_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `quotation_customer` ENABLE KEYS */;


# Dumping structure for table ebus.quotation_purchase
CREATE TABLE IF NOT EXISTS `quotation_purchase` (
  `quotationid` char(40) NOT NULL DEFAULT '',
  `rfqref` char(40) DEFAULT NULL,
  `supplier` char(40) NOT NULL,
  `quotationdate` date NOT NULL,
  `quotationtype` char(16) DEFAULT NULL,
  `quotationid_supplier` char(40) DEFAULT NULL,
  `invoiceaddress` char(40) DEFAULT NULL,
  `deliveryaddress` char(40) DEFAULT NULL,
  `currency` char(3) DEFAULT NULL,
  `remark` varchar(2000) DEFAULT NULL,
  `partialshipment` int(11) DEFAULT NULL,
  `transport` varchar(256) DEFAULT NULL,
  `specialtreatment` varchar(256) DEFAULT NULL,
  `internationalrestrictions` varchar(256) DEFAULT NULL,
  `pricetotal_net` decimal(10,2) DEFAULT NULL,
  `pricetotal_gross` decimal(10,2) DEFAULT NULL,
  `taxtotal` decimal(10,2) DEFAULT NULL,
  `taxamount` decimal(10,2) DEFAULT NULL,
  `totallineitems` int(11) DEFAULT NULL,
  PRIMARY KEY (`quotationid`),
  UNIQUE KEY `quotpurc_u1` (`quotationid_supplier`,`supplier`),
  KEY `quotpurc_rfqcust_fk` (`rfqref`),
  KEY `quotpurc_supplier_fk` (`supplier`),
  KEY `quotpurc_currency_fk` (`currency`),
  KEY `quotpurc_deladdr_fk` (`invoiceaddress`),
  CONSTRAINT `quotpurc_currency_fk` FOREIGN KEY (`currency`) REFERENCES `currency` (`code`),
  CONSTRAINT `quotpurc_deladdr_fk` FOREIGN KEY (`invoiceaddress`) REFERENCES `address` (`id`),
  CONSTRAINT `quotpurc_invaddr_fk` FOREIGN KEY (`invoiceaddress`) REFERENCES `address` (`id`),
  CONSTRAINT `quotpurc_rfqcust_fk` FOREIGN KEY (`rfqref`) REFERENCES `requestforquotation_purchase` (`rfqid`),
  CONSTRAINT `quotpurc_supplier_fk` FOREIGN KEY (`supplier`) REFERENCES `supplier` (`suppliernumber`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.quotation_purchase: ~0 rows (approximately)
/*!40000 ALTER TABLE `quotation_purchase` DISABLE KEYS */;
/*!40000 ALTER TABLE `quotation_purchase` ENABLE KEYS */;


# Dumping structure for table ebus.referencetype
CREATE TABLE IF NOT EXISTS `referencetype` (
  `code` varchar(64) NOT NULL DEFAULT '',
  `description` varchar(256) NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.referencetype: ~2 rows (approximately)
/*!40000 ALTER TABLE `referencetype` DISABLE KEYS */;
INSERT INTO `referencetype` (`code`, `description`) VALUES
	('accessories', 'Zubehör'),
	('base_product', 'Basisprodukt');
/*!40000 ALTER TABLE `referencetype` ENABLE KEYS */;


# Dumping structure for table ebus.requestforquotation_customer
CREATE TABLE IF NOT EXISTS `requestforquotation_customer` (
  `rfqid` char(40) NOT NULL DEFAULT '',
  `customer` char(40) NOT NULL,
  `rfqdate` date NOT NULL,
  `rfqtype` char(16) DEFAULT NULL,
  `rfqid_customer` char(40) DEFAULT NULL,
  `invoiceaddress` char(40) DEFAULT NULL,
  `deliveryaddress` char(40) DEFAULT NULL,
  `currency` char(3) DEFAULT NULL,
  `remark` varchar(2000) DEFAULT NULL,
  `partialshipment` int(11) DEFAULT NULL,
  `transport` varchar(256) DEFAULT NULL,
  `specialtreatment` varchar(256) DEFAULT NULL,
  `internationalrestrictions` varchar(256) DEFAULT NULL,
  `pricetotal_net` decimal(10,2) DEFAULT NULL,
  `pricetotal_gross` decimal(10,2) DEFAULT NULL,
  `taxtotal` decimal(10,2) DEFAULT NULL,
  `taxamount` decimal(10,2) DEFAULT NULL,
  `totallineitems` int(11) DEFAULT NULL,
  PRIMARY KEY (`rfqid`),
  UNIQUE KEY `rfqcust_u1` (`rfqid_customer`,`customer`),
  KEY `rfqcust_customer_fk` (`customer`),
  KEY `rfqcust_currency_fk` (`currency`),
  KEY `rfqcust_deladdr_fk` (`invoiceaddress`),
  CONSTRAINT `rfqcust_currency_fk` FOREIGN KEY (`currency`) REFERENCES `currency` (`code`),
  CONSTRAINT `rfqcust_customer_fk` FOREIGN KEY (`customer`) REFERENCES `customer` (`customerid`),
  CONSTRAINT `rfqcust_deladdr_fk` FOREIGN KEY (`invoiceaddress`) REFERENCES `address` (`id`),
  CONSTRAINT `rfqcust_invaddr_fk` FOREIGN KEY (`invoiceaddress`) REFERENCES `address` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.requestforquotation_customer: ~0 rows (approximately)
/*!40000 ALTER TABLE `requestforquotation_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `requestforquotation_customer` ENABLE KEYS */;


# Dumping structure for table ebus.requestforquotation_purchase
CREATE TABLE IF NOT EXISTS `requestforquotation_purchase` (
  `rfqid` char(40) NOT NULL DEFAULT '',
  `supplier` char(40) NOT NULL,
  `rfqdate` date NOT NULL,
  `rfqtype` char(16) DEFAULT NULL,
  `rfqid_supplier` char(40) DEFAULT NULL,
  `invoiceaddress` char(40) DEFAULT NULL,
  `deliveryaddress` char(40) DEFAULT NULL,
  `currency` char(3) DEFAULT NULL,
  `remark` varchar(2000) DEFAULT NULL,
  `partialshipment` int(11) DEFAULT NULL,
  `transport` varchar(256) DEFAULT NULL,
  `specialtreatment` varchar(256) DEFAULT NULL,
  `internationalrestrictions` varchar(256) DEFAULT NULL,
  `pricetotal_net` decimal(10,2) DEFAULT NULL,
  `pricetotal_gross` decimal(10,2) DEFAULT NULL,
  `taxtotal` decimal(10,2) DEFAULT NULL,
  `taxamount` decimal(10,2) DEFAULT NULL,
  `totallineitems` int(11) DEFAULT NULL,
  PRIMARY KEY (`rfqid`),
  UNIQUE KEY `rfqpurc_u1` (`rfqid_supplier`,`supplier`),
  KEY `rfqpurc_supplier_fk` (`supplier`),
  KEY `rfqpurc_currency_fk` (`currency`),
  KEY `rfqpurc_deladdr_fk` (`invoiceaddress`),
  CONSTRAINT `rfqpurc_currency_fk` FOREIGN KEY (`currency`) REFERENCES `currency` (`code`),
  CONSTRAINT `rfqpurc_deladdr_fk` FOREIGN KEY (`invoiceaddress`) REFERENCES `address` (`id`),
  CONSTRAINT `rfqpurc_invaddr_fk` FOREIGN KEY (`invoiceaddress`) REFERENCES `address` (`id`),
  CONSTRAINT `rfqpurc_supplier_fk` FOREIGN KEY (`supplier`) REFERENCES `supplier` (`suppliernumber`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.requestforquotation_purchase: ~0 rows (approximately)
/*!40000 ALTER TABLE `requestforquotation_purchase` DISABLE KEYS */;
/*!40000 ALTER TABLE `requestforquotation_purchase` ENABLE KEYS */;


# Dumping structure for table ebus.rfqitem_customer
CREATE TABLE IF NOT EXISTS `rfqitem_customer` (
  `rfq` char(40) NOT NULL DEFAULT '',
  `itemnumber` int(11) NOT NULL DEFAULT '0',
  `ordernumber_customer` char(40) NOT NULL,
  `productdescription` varchar(256) DEFAULT NULL,
  `orderamount` int(11) NOT NULL,
  `orderunit` char(16) NOT NULL,
  `contentunit` char(16) DEFAULT NULL,
  `no_cu_per_ou` int(11) DEFAULT '1',
  `unitprice` decimal(10,2) DEFAULT NULL,
  `itemprice` decimal(10,2) DEFAULT NULL,
  `pricetype` char(16) DEFAULT NULL,
  `pricequantity` int(11) DEFAULT NULL,
  `taxrate` decimal(4,2) DEFAULT NULL,
  `taxamount` decimal(10,2) DEFAULT NULL,
  `deliveryaddress` char(40) DEFAULT NULL,
  `partialshipment` int(11) DEFAULT NULL,
  `transport` varchar(256) DEFAULT NULL,
  `specialtreatment` varchar(256) DEFAULT NULL,
  `internationalrestrictions` varchar(256) DEFAULT NULL,
  `remark` varchar(256) DEFAULT NULL,
  `rfqtype` char(16) DEFAULT NULL,
  PRIMARY KEY (`rfq`,`itemnumber`),
  KEY `rfqitemcust_deladdr_fk` (`deliveryaddress`),
  CONSTRAINT `rfqitemcust_deladdr_fk` FOREIGN KEY (`deliveryaddress`) REFERENCES `address` (`id`),
  CONSTRAINT `rfqitemcust_rfqcust_fk` FOREIGN KEY (`rfq`) REFERENCES `requestforquotation_customer` (`rfqid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.rfqitem_customer: ~0 rows (approximately)
/*!40000 ALTER TABLE `rfqitem_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `rfqitem_customer` ENABLE KEYS */;


# Dumping structure for table ebus.rfqitem_purchase
CREATE TABLE IF NOT EXISTS `rfqitem_purchase` (
  `rfq` char(40) NOT NULL DEFAULT '',
  `itemnumber` int(11) NOT NULL DEFAULT '0',
  `ordernumber_supplier` char(40) NOT NULL,
  `productdescription` varchar(256) DEFAULT NULL,
  `orderamount` int(11) NOT NULL,
  `orderunit` char(16) NOT NULL,
  `contentunit` char(16) DEFAULT NULL,
  `no_cu_per_ou` int(11) DEFAULT '1',
  `unitprice` decimal(10,2) DEFAULT NULL,
  `itemprice` decimal(10,2) DEFAULT NULL,
  `pricetype` char(16) DEFAULT NULL,
  `pricequantity` int(11) DEFAULT NULL,
  `taxrate` decimal(4,2) DEFAULT NULL,
  `taxamount` decimal(10,2) DEFAULT NULL,
  `deliveryaddress` char(40) DEFAULT NULL,
  `partialshipment` int(11) DEFAULT NULL,
  `transport` varchar(256) DEFAULT NULL,
  `specialtreatment` varchar(256) DEFAULT NULL,
  `internationalrestrictions` varchar(256) DEFAULT NULL,
  `remark` varchar(256) DEFAULT NULL,
  `rfqtype` char(16) DEFAULT NULL,
  PRIMARY KEY (`rfq`,`itemnumber`),
  KEY `rfqitempurc_deladdr_fk` (`deliveryaddress`),
  CONSTRAINT `rfqitempurc_deladdr_fk` FOREIGN KEY (`deliveryaddress`) REFERENCES `address` (`id`),
  CONSTRAINT `rfqitempurc_rfqcust_fk` FOREIGN KEY (`rfq`) REFERENCES `requestforquotation_purchase` (`rfqid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.rfqitem_purchase: ~0 rows (approximately)
/*!40000 ALTER TABLE `rfqitem_purchase` DISABLE KEYS */;
/*!40000 ALTER TABLE `rfqitem_purchase` ENABLE KEYS */;


# Dumping structure for table ebus.rfqtype
CREATE TABLE IF NOT EXISTS `rfqtype` (
  `code` char(16) NOT NULL DEFAULT '',
  `description` varchar(256) NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.rfqtype: ~3 rows (approximately)
/*!40000 ALTER TABLE `rfqtype` DISABLE KEYS */;
INSERT INTO `rfqtype` (`code`, `description`) VALUES
	('express', 'Expresslieferung, Es wird eine Expresslieferung für diesen Auftrag angefordert.'),
	('release', 'Abruf, Die Angebotsanforderung ist ein Abruf aus einer Rahmenvereinbarung.'),
	('standard', 'Standardlieferung, Es wird eine Standardlieferung für diesen Auftrag angefordert.');
/*!40000 ALTER TABLE `rfqtype` ENABLE KEYS */;


# Dumping structure for table ebus.salesprice
CREATE TABLE IF NOT EXISTS `salesprice` (
  `product` int(11) NOT NULL DEFAULT '0',
  `country` char(5) NOT NULL DEFAULT '',
  `lowerbound_scaledprice` int(11) NOT NULL DEFAULT '1',
  `priceunit` int(11) DEFAULT '1',
  `pricetype` char(16) NOT NULL,
  `taxrate` decimal(4,4) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `remark` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`country`,`product`,`lowerbound_scaledprice`),
  KEY `salesprice_product_fk` (`product`),
  CONSTRAINT `salesprice_country_fk` FOREIGN KEY (`country`) REFERENCES `country` (`isocode`) ON DELETE CASCADE,
  CONSTRAINT `salesprice_product_fk` FOREIGN KEY (`product`) REFERENCES `product` (`materialnumber`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.salesprice: ~17 rows (approximately)
/*!40000 ALTER TABLE `salesprice` DISABLE KEYS */;
INSERT INTO `salesprice` (`product`, `country`, `lowerbound_scaledprice`, `priceunit`, `pricetype`, `taxrate`, `amount`, `remark`) VALUES
	(1, 'DE', 1, 1, 'net_list', 0.1900, 5.88, 'HTWG0001'),
	(2, 'DE', 1, 1, 'net_list', 0.1900, 25.21, 'HTWG0001'),
	(3, 'DE', 1, 1, 'net_list', 0.1900, 25.21, 'HTWG0001'),
	(4, 'DE', 1, 1, 'net_list', 0.1900, 0.84, 'HTWG0001'),
	(5, 'DE', 1, 1, 'net_list', 0.1900, 0.84, 'HTWG0001'),
	(6, 'DE', 1, 1, 'net_list', 0.1900, 0.42, 'HTWG0001'),
	(7, 'DE', 1, 1, 'net_list', 0.1900, 0.42, 'HTWG0001'),
	(8, 'DE', 1, 1, 'net_list', 0.1900, 1.68, 'HTWG0001'),
	(9, 'DE', 1, 1, 'net_list', 0.1900, 21.01, 'HTWG0001'),
	(10, 'DE', 1, 1, 'net_list', 0.1900, 0.42, 'HTWG0001'),
	(20, 'DE', 1, 1, 'net_list', 0.1900, 34.95, 'Sportscheck 3198044'),
	(21, 'DE', 1, 1, 'net_list', 0.1900, 34.95, 'Sportscheck 3097266'),
	(22, 'DE', 1, 1, 'net_list', 0.1900, 14.95, 'Sportscheck 837472D'),
	(23, 'DE', 1, 1, 'net_list', 0.1900, 19.95, 'Sportscheck 1054746'),
	(24, 'DE', 1, 1, 'net_list', 0.1900, 42.95, 'Sportscheck 368972C'),
	(25, 'DE', 1, 1, 'net_list', 0.1900, 19.95, 'Sportscheck 2783103'),
	(26, 'DE', 1, 1, 'net_list', 0.1900, 24.95, 'Sportscheck 5656349');
/*!40000 ALTER TABLE `salesprice` ENABLE KEYS */;


# Dumping structure for table ebus.shipmentitem_customer
CREATE TABLE IF NOT EXISTS `shipmentitem_customer` (
  `shipment` char(40) NOT NULL DEFAULT '',
  `itemnumber` int(11) NOT NULL DEFAULT '0',
  `ordernumber_customer` char(40) NOT NULL,
  `productdescription` varchar(256) DEFAULT NULL,
  `shipmentquantity` int(11) NOT NULL,
  `orderunit` char(16) NOT NULL,
  `contentunit` char(16) DEFAULT NULL,
  `no_cu_per_ou` int(11) DEFAULT '1',
  `deliveryaddress` char(40) DEFAULT NULL,
  `partialshipment` int(11) DEFAULT NULL,
  `transport` varchar(256) DEFAULT NULL,
  `specialtreatment` varchar(256) DEFAULT NULL,
  `internationalrestrictions` varchar(256) DEFAULT NULL,
  `remark` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`shipment`,`itemnumber`),
  KEY `shipitemcust_deladdr_fk` (`deliveryaddress`),
  CONSTRAINT `shipitemcust_deladdr_fk` FOREIGN KEY (`deliveryaddress`) REFERENCES `address` (`id`),
  CONSTRAINT `shipitemcust_ship_fk` FOREIGN KEY (`shipment`) REFERENCES `shipment_customer` (`shipmentid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.shipmentitem_customer: ~0 rows (approximately)
/*!40000 ALTER TABLE `shipmentitem_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `shipmentitem_customer` ENABLE KEYS */;


# Dumping structure for table ebus.shipmentitem_purchase
CREATE TABLE IF NOT EXISTS `shipmentitem_purchase` (
  `shipment` char(40) NOT NULL DEFAULT '',
  `itemnumber` int(11) NOT NULL DEFAULT '0',
  `ordernumber_supplier` char(40) NOT NULL,
  `productdescription` varchar(256) DEFAULT NULL,
  `shipmentquantity` int(11) NOT NULL,
  `orderunit` char(16) NOT NULL,
  `contentunit` char(16) DEFAULT NULL,
  `no_cu_per_ou` int(11) DEFAULT '1',
  `deliveryaddress` char(40) DEFAULT NULL,
  `partialshipment` int(11) DEFAULT NULL,
  `transport` varchar(256) DEFAULT NULL,
  `specialtreatment` varchar(256) DEFAULT NULL,
  `internationalrestrictions` varchar(256) DEFAULT NULL,
  `remark` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`shipment`,`itemnumber`),
  KEY `shipitempurc_deladdr_fk` (`deliveryaddress`),
  CONSTRAINT `shipitempurc_deladdr_fk` FOREIGN KEY (`deliveryaddress`) REFERENCES `address` (`id`),
  CONSTRAINT `shipitempurc_ship_fk` FOREIGN KEY (`shipment`) REFERENCES `shipment_purchase` (`shipmentid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.shipmentitem_purchase: ~0 rows (approximately)
/*!40000 ALTER TABLE `shipmentitem_purchase` DISABLE KEYS */;
/*!40000 ALTER TABLE `shipmentitem_purchase` ENABLE KEYS */;


# Dumping structure for table ebus.shipment_customer
CREATE TABLE IF NOT EXISTS `shipment_customer` (
  `shipmentid` char(40) NOT NULL DEFAULT '',
  `shipmentdate` date DEFAULT NULL,
  `deliverynotedate` date DEFAULT NULL,
  `dispatchnotificationdate` date DEFAULT NULL,
  `customer` char(40) DEFAULT NULL,
  `transport` varchar(256) DEFAULT NULL,
  `packageinfo` varchar(256) DEFAULT NULL,
  `specialtreatment` varchar(256) DEFAULT NULL,
  `internationalrestrictions` varchar(256) DEFAULT NULL,
  `remark` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`shipmentid`),
  KEY `shipmcust_customer_fk` (`customer`),
  CONSTRAINT `shipmcust_customer_fk` FOREIGN KEY (`customer`) REFERENCES `customer` (`customerid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.shipment_customer: ~0 rows (approximately)
/*!40000 ALTER TABLE `shipment_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `shipment_customer` ENABLE KEYS */;


# Dumping structure for table ebus.shipment_purchase
CREATE TABLE IF NOT EXISTS `shipment_purchase` (
  `shipmentid` char(40) NOT NULL DEFAULT '',
  `shipmentid_supplier` char(40) DEFAULT NULL,
  `shipmentdate` date DEFAULT NULL,
  `deliverynotedate` date DEFAULT NULL,
  `dispatchnotificationdate` date DEFAULT NULL,
  `supplier` char(40) DEFAULT NULL,
  `transport` varchar(256) DEFAULT NULL,
  `packageinfo` varchar(256) DEFAULT NULL,
  `specialtreatment` varchar(256) DEFAULT NULL,
  `internationalrestrictions` varchar(256) DEFAULT NULL,
  `remark` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`shipmentid`),
  UNIQUE KEY `shipmpurc_u1` (`shipmentid_supplier`,`supplier`),
  KEY `shipmpurc_supplier_fk` (`supplier`),
  CONSTRAINT `shipmpurc_supplier_fk` FOREIGN KEY (`supplier`) REFERENCES `supplier` (`suppliernumber`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.shipment_purchase: ~0 rows (approximately)
/*!40000 ALTER TABLE `shipment_purchase` DISABLE KEYS */;
/*!40000 ALTER TABLE `shipment_purchase` ENABLE KEYS */;


# Dumping structure for table ebus.supplier
CREATE TABLE IF NOT EXISTS `supplier` (
  `suppliernumber` char(40) NOT NULL DEFAULT '',
  `companyname` varchar(255) NOT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `address` char(40) NOT NULL,
  `ws_user_name` varchar(255) DEFAULT NULL,
  `ws_password` varchar(255) DEFAULT NULL,
  `ws_catalog_endpoint` varchar(255) DEFAULT NULL,
  `ws_order_endpoint` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`suppliernumber`),
  UNIQUE KEY `supplier_u1` (`address`),
  CONSTRAINT `supplier_address_fk` FOREIGN KEY (`address`) REFERENCES `address` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.supplier: ~2 rows (approximately)
/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
INSERT INTO `supplier` (`suppliernumber`, `companyname`, `firstname`, `lastname`, `remark`, `address`, `ws_user_name`, `ws_password`, `ws_catalog_endpoint`, `ws_order_endpoint`) VALUES
	('10', 'HTWG Konstanz', 'Lutz', 'Schmidtke', 'HTWG Shop', '10', 'htwg_user_1555', 'htwg_user_1', 'http://localhost:8080/ess/ProductCatalogService', 'http://localhost:8080/ess/OrderService'),
	('20', 'Sportscheck', 'Mr. Sporty', 'Sportsman', 'Sportscheck Shop', '90', 'sportscheck_wholesaler', 'sportscheck_wholesaler', 'http://localhost:8080/ess/ProductCatalogService', 'http://localhost:8080/ess/OrderService');
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;


# Dumping structure for table ebus.supplieridentification
CREATE TABLE IF NOT EXISTS `supplieridentification` (
  `companyidenttype` char(8) NOT NULL,
  `identification` char(40) NOT NULL,
  `supplier` char(40) DEFAULT NULL,
  PRIMARY KEY (`companyidenttype`,`identification`),
  UNIQUE KEY `suppid_u1` (`companyidenttype`,`supplier`),
  KEY `suppid_supplier_fk` (`supplier`),
  CONSTRAINT `suppid_compidtyp_fk` FOREIGN KEY (`companyidenttype`) REFERENCES `companyidenttype` (`companyidenttype`),
  CONSTRAINT `suppid_supplier_fk` FOREIGN KEY (`supplier`) REFERENCES `supplier` (`suppliernumber`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.supplieridentification: ~0 rows (approximately)
/*!40000 ALTER TABLE `supplieridentification` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplieridentification` ENABLE KEYS */;


# Dumping structure for table ebus.user_customer
CREATE TABLE IF NOT EXISTS `user_customer` (
  `id` int(11) NOT NULL DEFAULT '0',
  `customer` char(40) NOT NULL,
  `lastname` varchar(256) NOT NULL,
  `firstname` varchar(256) DEFAULT NULL,
  `title` varchar(64) DEFAULT NULL,
  `email` varchar(256) DEFAULT NULL,
  `phonenumber` varchar(256) DEFAULT NULL,
  `mobilenumber` varchar(256) DEFAULT NULL,
  `faxnumber` varchar(256) DEFAULT NULL,
  `address` char(40) DEFAULT NULL,
  `login` char(10) DEFAULT NULL,
  `passwd` char(16) DEFAULT NULL,
  `remark` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `usercust_u2` (`customer`,`login`),
  UNIQUE KEY `usercust_u1` (`address`),
  CONSTRAINT `usercust_address_fk` FOREIGN KEY (`address`) REFERENCES `address` (`id`),
  CONSTRAINT `usercust_customer_fk` FOREIGN KEY (`customer`) REFERENCES `customer` (`customerid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.user_customer: ~2 rows (approximately)
/*!40000 ALTER TABLE `user_customer` DISABLE KEYS */;
INSERT INTO `user_customer` (`id`, `customer`, `lastname`, `firstname`, `title`, `email`, `phonenumber`, `mobilenumber`, `faxnumber`, `address`, `login`, `passwd`, `remark`) VALUES
	(200000002, '10', 'Customer 1', 'User', 'Dr.', 'max.mustermann@htwg-konstanz.de', '206-502', NULL, '987654321', '30', 'customer1', 'customer1', NULL),
	(200000003, '11', 'Customer 2', 'User', 'Dr.', 'max.mustermann@htwg-konstanz.de', '206-502', NULL, '987654321', '100', 'customer2', 'customer2', NULL);
/*!40000 ALTER TABLE `user_customer` ENABLE KEYS */;


# Dumping structure for table ebus.user_internal
CREATE TABLE IF NOT EXISTS `user_internal` (
  `id` int(11) NOT NULL DEFAULT '0',
  `lastname` varchar(255) NOT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `title` varchar(64) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phonenumber` varchar(255) DEFAULT NULL,
  `mobilenumber` varchar(255) DEFAULT NULL,
  `faxnumber` varchar(255) DEFAULT NULL,
  `address` char(40) DEFAULT NULL,
  `login` char(10) DEFAULT NULL,
  `passwd` char(16) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `userint_u1` (`address`),
  UNIQUE KEY `userint_u2` (`login`),
  CONSTRAINT `userint_address_fk` FOREIGN KEY (`address`) REFERENCES `address` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.user_internal: ~1 rows (approximately)
/*!40000 ALTER TABLE `user_internal` DISABLE KEYS */;
INSERT INTO `user_internal` (`id`, `lastname`, `firstname`, `title`, `email`, `phonenumber`, `mobilenumber`, `faxnumber`, `address`, `login`, `passwd`, `remark`) VALUES
	(100000000, 'Wholesaler', 'Jürgen', 'Prof. Dr.', 'wholesaler@htwg-konstanz.de', '206502', '206502', '206502', '40', 'internal1', 'internal1', NULL);
/*!40000 ALTER TABLE `user_internal` ENABLE KEYS */;


# Dumping structure for table ebus.user_supplier
CREATE TABLE IF NOT EXISTS `user_supplier` (
  `id` int(11) NOT NULL DEFAULT '0',
  `supplier` char(40) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `title` varchar(64) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phonenumber` varchar(255) DEFAULT NULL,
  `mobilenumber` varchar(255) DEFAULT NULL,
  `faxnumber` varchar(255) DEFAULT NULL,
  `address` char(40) DEFAULT NULL,
  `login` char(10) DEFAULT NULL,
  `passwd` char(16) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `usersupp_u2` (`supplier`,`login`),
  UNIQUE KEY `usersupp_u1` (`address`),
  CONSTRAINT `usersupp_address_fk` FOREIGN KEY (`address`) REFERENCES `address` (`id`),
  CONSTRAINT `usersupp_customer_fk` FOREIGN KEY (`supplier`) REFERENCES `supplier` (`suppliernumber`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table ebus.user_supplier: ~2 rows (approximately)
/*!40000 ALTER TABLE `user_supplier` DISABLE KEYS */;
INSERT INTO `user_supplier` (`id`, `supplier`, `lastname`, `firstname`, `title`, `email`, `phonenumber`, `mobilenumber`, `faxnumber`, `address`, `login`, `passwd`, `remark`) VALUES
	(300000000, '10', 'Supplier 1', 'User', NULL, NULL, NULL, NULL, NULL, '50', 'supplier1', 'supplier1', NULL),
	(300000001, '20', 'Supplier 2', 'User', NULL, NULL, NULL, NULL, NULL, '110', 'supplier2', 'supplier2', NULL);
/*!40000 ALTER TABLE `user_supplier` ENABLE KEYS */;


# Create final VIEW structure
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `allusers_view` AS select `user_internal`.`id` AS `id`,`user_internal`.`lastname` AS `lastname`,`user_internal`.`firstname` AS `firstname`,`user_internal`.`title` AS `title`,`user_internal`.`email` AS `email`,`user_internal`.`phonenumber` AS `phonenumber`,`user_internal`.`mobilenumber` AS `mobilenumber`,`user_internal`.`faxnumber` AS `faxnumber`,`user_internal`.`address` AS `address`,`user_internal`.`login` AS `login`,`user_internal`.`passwd` AS `passwd`,`user_internal`.`remark` AS `remark`,'internal' AS `rolle` from `user_internal` union select `user_customer`.`id` AS `id`,`user_customer`.`lastname` AS `lastname`,`user_customer`.`firstname` AS `firstname`,`user_customer`.`title` AS `title`,`user_customer`.`email` AS `email`,`user_customer`.`phonenumber` AS `phonenumber`,`user_customer`.`mobilenumber` AS `mobilenumber`,`user_customer`.`faxnumber` AS `faxnumber`,`user_customer`.`address` AS `address`,`user_customer`.`login` AS `login`,`user_customer`.`passwd` AS `passwd`,`user_customer`.`remark` AS `remark`,'customer' AS `customer` from `user_customer` union select `user_supplier`.`id` AS `id`,`user_supplier`.`lastname` AS `lastname`,`user_supplier`.`firstname` AS `firstname`,`user_supplier`.`title` AS `title`,`user_supplier`.`email` AS `email`,`user_supplier`.`phonenumber` AS `phonenumber`,`user_supplier`.`mobilenumber` AS `mobilenumber`,`user_supplier`.`faxnumber` AS `faxnumber`,`user_supplier`.`address` AS `address`,`user_supplier`.`login` AS `login`,`user_supplier`.`passwd` AS `passwd`,`user_supplier`.`remark` AS `remark`,'supplier' AS `supplier` from `user_supplier`;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
